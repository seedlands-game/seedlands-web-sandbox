# PR41 储运 UI 有界只读审查

## Review identity 与范围

审查对象绑定冻结文件 `/workspace/pr41-recovery-20261008-root-01/storage-carrier-native-freeze-1218-01.json`：source SHA `e678f04eefe7edad8cebbf3c11d9bbf4927e72c8`，清单标记 `dirtySource: true`。本轮审的是冻结清单所列源文件的当前精确字节；未重建完整 PR diff 或比较 base/head。报告因此只对储运 UI 所覆盖代码给出结论。

范围包含 11 个生产文件：指定的 7 个优先文件、为追踪 Authority view 到 UI presentation 的 actor/inventory identity 额外读取的 `browser-gameplay-ui-source.ts`、`gameplay-ui-projector.ts`，以及追踪关闭按钮宽度来源所需的 `primitives/game-button.svelte`、`styles/start-screen.css`。没有读取其他生产文件、测试或后端实现。规则依据为仓库 `AGENTS.md`、`.agents/skills/seedlands-code-review/SKILL.md`、其 `references/review-workflow.md` 与 `references/project-rules.md`，并参照 `changes/2026-10-08-pr41-ci-recovery/spec.md` 中 1196–1214 储运 UI/native 验收边界。

冻结清单中 7 个优先文件的 SHA256 在审查前后均匹配；新增的 2 个生产文件审查前后 SHA256 也一致。审查期间未修改仓库，也未运行测试、构建或浏览器验收。

## 结论与风险热点

在上述有限 UI 路径内，发现一个有截图和 CSS 级联证据支持的 P2 呈现问题；未发现可证实的 P0/P1。其余检查重点包括 actor/载具引用和 revision 绑定、本地状态所有权、重复请求闸门、dispose/epoch/death 后的异步响应、面板关闭与 DOM 输入路径。静态代码检查不能证明真实浏览器输入、动作响应时序或保存重开体验。另依据主审查者提供的 fuel panel 原始 PNG 观察：标题已不换行，但约 670px 面板中的关闭按钮仍宽约 500px。

## 变更与调用路径

真实目标交互由 `transportTargetAction` 根据 Authority transport view 及 definition 的 body AABB 选择实体；use 命中实体后调用 `openStorage`，alternate/self 仍沿既有交互 action 路径。`BrowserGameplay.openTransportStorage` 打开本地面板并释放输入。

面板通过 `transportStorage-ui-projector.ts` 将 Authority storage site 投影成槽位、燃料和两个 revision；identity 由 actor identity、库存 revision、载具 reference 和载具 revision 组成。`transport-storage-panel.svelte` 只保存“哪侧哪个槽”的临时选择及选中数量，不保存或修改 cargo/fuel owner；提交时把当前投影的两侧 revision 与动作发给 UI action port。

`BrowserTransportStorage.send` 在提交边界重新读取当前 view，并校验请求携带的库存/载具 revision；动作携带当前 actor 与 transport reference，pending 标志阻止同一 client owner 并发请求。返回后按 Authority result 决定成功回调或错误反馈，并刷新 UI。`current()` 还要求玩家存活、cursor 为空且所选载具仍在当前 transportStorage view 中，否则清空本地选中 reference。

关闭按钮和 Escape 最终调用共享 `closeInventory`；关闭路径先等待既有 inventory pointer close action 成功，再关闭面板并清 selection。死亡时 BrowserGameplay 将 inventoryOpen 关闭；transportStorage.current 在面板投影阶段继续检查 player lifecycle 和 cursor。

## Diff codemap

| 路径 / 符号 | 角色与上游 | 下游/副作用 | 状态 owner 与审阅重点 |
| --- | --- | --- | --- |
| `gameplay/transport-target-interaction.ts:12` `transportTargetAction` | 真实鼠标射线输入 | 生成实体 use 或 alternate Authority action | Authority transport view；AABB 命中与 reference 传递 |
| `gameplay/browser-gameplay.ts:417` `openTransportStorage` | 目标交互回调 | 打开 inventory overlay、释放输入、刷新 | 本地 lifetime selection；死亡和关闭时清理 |
| `gameplay/browser-transport-storage.ts:16` `BrowserTransportStorage` | UI 请求 action | Authority action、refresh、save callback、feedback | Authority 持有 inventory/cargo/fuel；校验 actor/ref/revision/pending/dispose |
| `ui/transport-storage-ui-projector.ts:15` `projectTransportStorageUi` | 当前 Authority site 与 inventory | UI slots/fuel/identity/revisions | 只读派生 presentation；identity 要包含 revision/lifetime |
| `ui/transport-storage-panel.svelte:17` `selected` / `send` | DOM 槽按钮和关闭按钮 | 生成 transfer/refuel command | 仅临时选中槽；检查空槽、Shift 与异步交互 |
| `ui/inventory-crafting.svelte:154` `close` / `handleKey` | Escape、E、外层关闭动作 | 等待 gesture 后调用共享关闭端口 | 共用 overlay close 行为；检查输入焦点及面板可达性 |
| `gameplay/browser-gameplay-ui-source.ts:4` / `ui/gameplay-ui-projector.ts:273` | Authority view 到 ShellState | lifecycle、actor identity、storage identity | 只读 Authority-derived UI projection |
| `ui/ui-contracts.ts:147` `UiActionPort` | UI 与 BrowserGameplay 边界 | transportStorage 与 closeInventory 回调 | 类型合同；未在本轮检查实际 app wiring |

## 测试与证据边界

- 冻结身份：source SHA `e678f04eefe7edad8cebbf3c11d9bbf4927e72c8`；源文件由清单 SHA256 校验。冻结材料标记 dirty source，本报告不声称整个工作区状态等于单一 Git commit。
- 本轮实际执行：只读源码、仓库规则/spec 阅读及 SHA256 前后核对；关闭按钮宽度还对照了主审查者观察到的原始 PNG 与 `#ui button` 全局规则。
- 未运行：单元/集成测试、Svelte 检查、构建、native/browser journey、DOM 操作或保存重开。它们都不能从本轮静态阅读代替。
- 之前记录的储运测试/native证据只在 spec 中作为上下文阅读，未独立核验其日志或本轮绑定；不将其作为本次运行时结论。

## 待确认问题

- Authority action 已返回后、UI Promise continuation 运行前若同一 actor 进入 dead lifecycle，`send` 的完成分支只检查 disposed 和 actor identity，没有再次检查 lifecycle。若返回 success，仍会调用 changed/save callback 和 refresh；BrowserGameplay 的死亡 refresh 会关闭面板。静态代码显示可能出现死亡后迟到的成功回调，但缺少实际 Authority response / save queue 时序证据，无法证明会造成错误存档或错误操作结果，因此不列为 finding。建议后续以“动作在途时死亡且同 actor identity 保持不变”的定向时序验证其用户可见反馈与保存行为。

## 人类复核建议

1. `browser-transport-storage.ts:62-86`：用延迟 Authority response 覆盖 dispose、玩家死亡、actor epoch 更换，确认迟到结果不会污染新 session 的反馈或保存队列。
2. `browser-gameplay.ts:334-345` 与 `inventory-crafting.svelte:154-160,171-195`：真实验证 transport 面板的按钮关闭、Escape、pointer lock 释放及 cursor/close action 的组合路径。
3. `transport-target-interaction.ts:24-60`：浏览器真实射线命中货箱实体和普通车/alternate 的原交互路径，静态 AABB 逻辑不能证明最终 DOM 呈现与可达性。

## 独立审阅 Findings

### [P2] 全局按钮宽度规则覆盖了储运面板的关闭按钮宽度

- 位置：`apps/web/src/app/ui/transport-storage-panel.svelte:142-145`
- 触发：储运面板渲染关闭按钮。
- 可观察影响：按钮按全局规则占满面板行宽，挤压标题区并让关闭控件横跨面板；主审查者提供的 fuel panel 原始 PNG 观察到面板约 670px、按钮仍约 500px。
- 规则/合同：UI 控件应保持可用且布局清晰；这是低严重度呈现问题，不影响 Authority 储运状态正确性。
- 证据：局部 `header :global(.game-button) { width: auto; flex-shrink: 0; }` 在 [start-screen.css] 全局 `#ui button { width: 100%; }` 面前特异性较低；`GameButton` 渲染的确是带 `.game-button` class 的原生 button。截图观察与该级联结果相符。
- 建议：用包含 `#ui`/面板祖先的更高特异性选择器限定该按钮宽度，或为其提供专用 class 并以等效优先级覆盖；不改动全局按钮规则。
- 置信度：高。

覆盖：储运 UI 相关 11 个生产文件逐文件阅读，7 个优先源路径有冻结前后 SHA256 一致性；新增追踪的 4 个源码文件在读取期间亦保持不变；不包含完整 PR diff、后端 storage action、UI app wiring、测试与运行时验收。审阅范围部分，不构成 LGTM、合并建议或运行时通过结论。
