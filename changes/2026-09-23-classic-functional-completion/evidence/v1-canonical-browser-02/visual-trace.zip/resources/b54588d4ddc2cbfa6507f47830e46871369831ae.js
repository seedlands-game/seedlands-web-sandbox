// packages/stdlib/src/world/wool-colors.ts
var coloredWoolVoxels = {
  OrangeWool: 74,
  MagentaWool: 75,
  LightBlueWool: 76,
  YellowWool: 77,
  LimeWool: 78,
  PinkWool: 79,
  GrayWool: 80,
  LightGrayWool: 81,
  CyanWool: 82,
  PurpleWool: 83,
  BlueWool: 84,
  BrownWool: 85,
  GreenWool: 86,
  RedWool: 87,
  BlackWool: 88
};
var coloredWoolFaceMaterials = {
  OrangeWool: 78,
  MagentaWool: 79,
  LightBlueWool: 80,
  YellowWool: 81,
  LimeWool: 82,
  PinkWool: 83,
  GrayWool: 84,
  LightGrayWool: 85,
  CyanWool: 86,
  PurpleWool: 87,
  BlueWool: 88,
  BrownWool: 89,
  GreenWool: 90,
  RedWool: 91,
  BlackWool: 92
};
var woolVoxelColors = [
  ["white", "\u767D\u8272", 60, 63, "#e8e8df"],
  ["orange", "\u6A59\u8272", coloredWoolVoxels.OrangeWool, coloredWoolFaceMaterials.OrangeWool, "#d97819"],
  ["magenta", "\u54C1\u7EA2\u8272", coloredWoolVoxels.MagentaWool, coloredWoolFaceMaterials.MagentaWool, "#b24aac"],
  ["light-blue", "\u6DE1\u84DD\u8272", coloredWoolVoxels.LightBlueWool, coloredWoolFaceMaterials.LightBlueWool, "#6699d8"],
  ["yellow", "\u9EC4\u8272", coloredWoolVoxels.YellowWool, coloredWoolFaceMaterials.YellowWool, "#c9b51a"],
  ["lime", "\u9EC4\u7EFF\u8272", coloredWoolVoxels.LimeWool, coloredWoolFaceMaterials.LimeWool, "#74a82d"],
  ["pink", "\u7C89\u7EA2\u8272", coloredWoolVoxels.PinkWool, coloredWoolFaceMaterials.PinkWool, "#d98199"],
  ["gray", "\u7070\u8272", coloredWoolVoxels.GrayWool, coloredWoolFaceMaterials.GrayWool, "#4c5355"],
  ["light-gray", "\u6DE1\u7070\u8272", coloredWoolVoxels.LightGrayWool, coloredWoolFaceMaterials.LightGrayWool, "#9aa1a1"],
  ["cyan", "\u9752\u8272", coloredWoolVoxels.CyanWool, coloredWoolFaceMaterials.CyanWool, "#2f8b8d"],
  ["purple", "\u7D2B\u8272", coloredWoolVoxels.PurpleWool, coloredWoolFaceMaterials.PurpleWool, "#7043a3"],
  ["blue", "\u84DD\u8272", coloredWoolVoxels.BlueWool, coloredWoolFaceMaterials.BlueWool, "#334f9b"],
  ["brown", "\u68D5\u8272", coloredWoolVoxels.BrownWool, coloredWoolFaceMaterials.BrownWool, "#70462a"],
  ["green", "\u7EFF\u8272", coloredWoolVoxels.GreenWool, coloredWoolFaceMaterials.GreenWool, "#446b25"],
  ["red", "\u7EA2\u8272", coloredWoolVoxels.RedWool, coloredWoolFaceMaterials.RedWool, "#a83232"],
  ["black", "\u9ED1\u8272", coloredWoolVoxels.BlackWool, coloredWoolFaceMaterials.BlackWool, "#202428"]
];
var woolVoxelForColor = Object.freeze(
  Object.fromEntries(woolVoxelColors.map(([id2, , voxel2]) => [id2, voxel2]))
);
var woolFaceMaterialForVoxel = Object.freeze(
  Object.fromEntries(woolVoxelColors.map(([, , voxel2, material]) => [voxel2, material]))
);

// playbooks/classic/src/recipe-closure-items.ts
var woolColors = woolVoxelColors.map(([id2, name]) => [id2, name]);
var recipeClosureItems = [
  ...[
    ["slab", "\u534A\u7816", 49],
    ["wood-stairs", "\u6728\u697C\u68AF", 50],
    ["cobblestone-stairs", "\u5706\u77F3\u697C\u68AF", 51],
    ["ladder", "\u68AF\u5B50", 53],
    ["torch", "\u706B\u628A", 54],
    ["fence", "\u6805\u680F", 57]
  ].map(([id2, name, voxel2]) => ({
    id: id2,
    name,
    itemType: "block",
    stackLimit: 64,
    capabilities: [{ type: "place", voxel: voxel2 }]
  })),
  {
    id: "sandstone-slab",
    name: "\u7802\u5CA9\u534A\u7816",
    itemType: "block",
    stackLimit: 64,
    capabilities: [{ type: "place", voxel: 49 }]
  },
  { id: "wood-slab", name: "\u6728\u534A\u7816", itemType: "block", stackLimit: 64, capabilities: [{ type: "place", voxel: 49 }] },
  ...woolColors.map(([id2, name]) => ({
    id: `${id2}-wool`,
    name: `${name}\u7F8A\u6BDB`,
    itemType: "block",
    stackLimit: 64,
    capabilities: [{ type: "place", voxel: woolVoxelForColor[id2] }]
  }))
];

// playbooks/classic/src/recipes.ts
var dyeRecipes = [
  ["yellow", "flower"],
  ["red", "red-flower"],
  ["white", "bone"],
  ["black", "ink-sac"],
  ["brown", "cocoa-beans"]
].map(([color, source]) => ({
  id: `${color}-dye`,
  inputs: [{ itemId: source, count: 1 }],
  outputs: [{ itemId: `${color}-dye`, count: color === "white" ? 3 : 1 }]
}));
var mixes = [
  ["orange", "red-dye", "yellow-dye"],
  ["lime", "green-dye", "white-dye"],
  ["light-blue", "blue-dye", "white-dye"],
  ["cyan", "blue-dye", "green-dye"],
  ["purple", "blue-dye", "red-dye"],
  ["magenta", "purple-dye", "pink-dye"],
  ["pink", "red-dye", "white-dye"],
  ["gray", "black-dye", "white-dye"],
  ["light-gray", "gray-dye", "white-dye"]
];
var mixedDyes = mixes.map(([color, left, right]) => ({
  id: `${color}-dye`,
  inputs: [
    { itemId: left, count: 1 },
    { itemId: right, count: 1 }
  ],
  outputs: [{ itemId: `${color}-dye`, count: 2 }]
}));
var coloredWool = woolColors.map(([color]) => ({
  id: `${color}-wool`,
  inputs: [
    { itemId: "wool", count: 1 },
    { itemId: `${color}-dye`, count: 1 }
  ],
  outputs: [{ itemId: `${color}-wool`, count: 1 }]
}));
var resourceBlocks = [
  ["iron-ingot", "iron-block"],
  ["gold-ingot", "gold-block"],
  ["diamond", "diamond-block"]
].flatMap(([material, block]) => [
  { id: block, inputs: [{ itemId: material, count: 9 }], outputs: [{ itemId: block, count: 1 }] },
  { id: block + "-unpack", inputs: [{ itemId: block, count: 1 }], outputs: [{ itemId: material, count: 9 }] }
]);
var toolTiers = [
  ["stone", "cobblestone"],
  ["iron", "iron-ingot"],
  ["gold", "gold-ingot"],
  ["diamond", "diamond"]
];
var toolDurability = { stone: 132, iron: 250, gold: 32, diamond: 1561 };
var meleeTools = toolTiers.flatMap(([tier, material]) => [
  {
    id: tier + "-axe",
    inputs: [
      { itemId: material, count: 3 },
      { itemId: "stick", count: 2 }
    ],
    outputs: [{ itemId: tier + "-axe", count: 1, instance: { durability: toolDurability[tier] } }]
  },
  {
    id: tier + "-sword",
    inputs: [
      { itemId: material, count: 2 },
      { itemId: "stick", count: 1 }
    ],
    outputs: [{ itemId: tier + "-sword", count: 1, instance: { durability: toolDurability[tier] } }]
  }
]);
var shovelTiers = [
  ["wood", "plank", 60],
  ["stone", "cobblestone", 132],
  ["iron", "iron-ingot", 250],
  ["gold", "gold-ingot", 32],
  ["diamond", "diamond", 1561]
];
var shovelTools = shovelTiers.map(([tier, material, durability]) => ({
  id: tier + "-shovel",
  inputs: [
    { itemId: material, count: 1 },
    { itemId: "stick", count: 2 }
  ],
  outputs: [{ itemId: tier + "-shovel", count: 1, instance: { durability } }]
}));
var hoeTools = shovelTiers.map(([tier, material, durability]) => ({
  id: tier + "-hoe",
  inputs: [
    { itemId: material, count: 2 },
    { itemId: "stick", count: 2 }
  ],
  outputs: [{ itemId: tier + "-hoe", count: 1, instance: { durability } }]
}));
var armorTiers = [
  ["leather", "leather", 55],
  ["iron", "iron-ingot", 165],
  ["gold", "gold-ingot", 77],
  ["diamond", "diamond", 363]
];
var armorPieceCost = { helmet: 5, chestplate: 8, leggings: 7, boots: 4 };
var armorRecipes = armorTiers.flatMap(
  ([tier, material, durability]) => Object.entries(armorPieceCost).map(([slot, count]) => ({
    id: `${tier}-${slot}`,
    inputs: [{ itemId: material, count }],
    outputs: [{ itemId: `${tier}-${slot}`, count: 1, instance: { durability } }]
  }))
);
var overworldRecipes = [
  {
    id: "wood-pickaxe",
    inputs: [
      { itemId: "plank", count: 3 },
      { itemId: "stick", count: 2 }
    ],
    outputs: [{ itemId: "wood-pickaxe", count: 1, instance: { durability: 60 } }]
  },
  ...toolTiers.filter(([tier]) => tier !== "stone").map(([tier, material]) => ({
    id: `${tier}-pickaxe`,
    inputs: [
      { itemId: material, count: 3 },
      { itemId: "stick", count: 2 }
    ],
    outputs: [{ itemId: `${tier}-pickaxe`, count: 1, instance: { durability: toolDurability[tier] } }]
  })),
  { id: "chest", inputs: [{ itemId: "plank", count: 8 }], outputs: [{ itemId: "chest", count: 1 }] },
  { id: "furnace", inputs: [{ itemId: "cobblestone", count: 8 }], outputs: [{ itemId: "furnace", count: 1 }] },
  ...resourceBlocks,
  ...meleeTools,
  ...shovelTools,
  ...hoeTools,
  ...armorRecipes,
  ...dyeRecipes,
  ...mixedDyes,
  ...coloredWool,
  { id: "sandstone", inputs: [{ itemId: "sand-block", count: 4 }], outputs: [{ itemId: "sandstone", count: 1 }] },
  {
    id: "stone-bricks",
    inputs: [{ itemId: "stone-block", count: 4 }],
    outputs: [{ itemId: "stone-bricks", count: 4 }]
  },
  { id: "clay-block", inputs: [{ itemId: "clay", count: 4 }], outputs: [{ itemId: "clay-block", count: 1 }] },
  { id: "snow-block", inputs: [{ itemId: "snowball", count: 4 }], outputs: [{ itemId: "snow-block", count: 1 }] },
  { id: "lapis-block", inputs: [{ itemId: "blue-dye", count: 9 }], outputs: [{ itemId: "lapis-block", count: 1 }] },
  { id: "slab", inputs: [{ itemId: "stone-block", count: 3 }], outputs: [{ itemId: "slab", count: 6 }] },
  {
    id: "sandstone-slab",
    inputs: [{ itemId: "sandstone", count: 3 }],
    outputs: [{ itemId: "sandstone-slab", count: 6 }]
  },
  { id: "wood-slab", inputs: [{ itemId: "plank", count: 3 }], outputs: [{ itemId: "wood-slab", count: 6 }] },
  {
    id: "mushroom-stew",
    inputs: [
      { itemId: "mushroom", count: 1 },
      { itemId: "red-mushroom", count: 1 },
      { itemId: "bowl", count: 1 }
    ],
    outputs: [{ itemId: "mushroom-stew", count: 1 }]
  },
  { id: "wood-stairs", inputs: [{ itemId: "plank", count: 6 }], outputs: [{ itemId: "wood-stairs", count: 4 }] },
  {
    id: "cobblestone-stairs",
    inputs: [{ itemId: "cobblestone", count: 6 }],
    outputs: [{ itemId: "cobblestone-stairs", count: 4 }]
  },
  { id: "ladder", inputs: [{ itemId: "stick", count: 7 }], outputs: [{ itemId: "ladder", count: 3 }] },
  {
    id: "torch",
    inputs: [
      { itemId: "coal", count: 1 },
      { itemId: "stick", count: 1 }
    ],
    outputs: [{ itemId: "torch", count: 4 }]
  },
  { id: "fence", inputs: [{ itemId: "stick", count: 6 }], outputs: [{ itemId: "fence", count: 2 }] },
  { id: "bricks", inputs: [{ itemId: "brick", count: 4 }], outputs: [{ itemId: "bricks", count: 1 }] },
  {
    id: "bookshelf",
    inputs: [
      { itemId: "plank", count: 6 },
      { itemId: "book", count: 3 }
    ],
    outputs: [{ itemId: "bookshelf", count: 1 }]
  },
  {
    id: "note-block",
    inputs: [
      { itemId: "plank", count: 8 },
      { itemId: "redstone-dust", count: 1 }
    ],
    outputs: [{ itemId: "note-block", count: 1 }]
  },
  {
    id: "jukebox",
    inputs: [
      { itemId: "plank", count: 8 },
      { itemId: "diamond", count: 1 }
    ],
    outputs: [{ itemId: "jukebox", count: 1 }]
  },
  {
    id: "jack-o-lantern",
    inputs: [
      { itemId: "pumpkin", count: 1 },
      { itemId: "torch", count: 1 }
    ],
    outputs: [{ itemId: "jack-o-lantern", count: 1 }]
  },
  { id: "trapdoor", inputs: [{ itemId: "plank", count: 6 }], outputs: [{ itemId: "trapdoor", count: 2 }] },
  {
    id: "lapis-block-unpack",
    inputs: [{ itemId: "lapis-block", count: 1 }],
    outputs: [{ itemId: "blue-dye", count: 9 }]
  },
  { id: "planks", inputs: [{ itemId: "wood-block", count: 1 }], outputs: [{ itemId: "plank", count: 4 }] },
  { id: "bread", inputs: [{ itemId: "wheat", count: 3 }], outputs: [{ itemId: "bread", count: 1 }] },
  { id: "bowl", inputs: [{ itemId: "plank", count: 3 }], outputs: [{ itemId: "bowl", count: 4 }] },
  { id: "bucket", inputs: [{ itemId: "iron-ingot", count: 3 }], outputs: [{ itemId: "bucket", count: 1 }] },
  {
    id: "shears",
    inputs: [{ itemId: "iron-ingot", count: 2 }],
    outputs: [{ itemId: "shears", count: 1, instance: { durability: 238 } }]
  },
  { id: "minecart", inputs: [{ itemId: "iron-ingot", count: 5 }], outputs: [{ itemId: "minecart", count: 1 }] },
  {
    id: "rails",
    inputs: [
      { itemId: "iron-ingot", count: 6 },
      { itemId: "stick", count: 1 }
    ],
    outputs: [{ itemId: "rail", count: 16 }]
  },
  {
    id: "powered-rails",
    inputs: [
      { itemId: "gold-ingot", count: 6 },
      { itemId: "stick", count: 1 }
    ],
    outputs: [{ itemId: "powered-rail", count: 6 }]
  },
  {
    id: "detector-rails",
    inputs: [
      { itemId: "iron-ingot", count: 6 },
      { itemId: "stone-block", count: 1 }
    ],
    outputs: [{ itemId: "detector-rail", count: 6 }]
  },
  {
    id: "chest-minecart",
    inputs: [
      { itemId: "minecart", count: 1 },
      { itemId: "chest", count: 1 }
    ],
    outputs: [{ itemId: "chest-minecart", count: 1 }]
  },
  {
    id: "furnace-minecart",
    inputs: [
      { itemId: "minecart", count: 1 },
      { itemId: "furnace", count: 1 }
    ],
    outputs: [{ itemId: "furnace-minecart", count: 1 }]
  },
  { id: "boat", inputs: [{ itemId: "plank", count: 5 }], outputs: [{ itemId: "boat", count: 1 }] },
  { id: "paper", inputs: [{ itemId: "sugar-cane", count: 3 }], outputs: [{ itemId: "paper", count: 3 }] },
  { id: "book", inputs: [{ itemId: "paper", count: 3 }], outputs: [{ itemId: "book", count: 1 }] },
  { id: "wool", inputs: [{ itemId: "string", count: 4 }], outputs: [{ itemId: "wool", count: 1 }] },
  {
    id: "painting",
    inputs: [
      { itemId: "stick", count: 8 },
      { itemId: "wool", count: 1 }
    ],
    outputs: [{ itemId: "painting", count: 1 }]
  },
  {
    id: "golden-apple",
    inputs: [
      { itemId: "apple", count: 1 },
      { itemId: "gold-block", count: 8 }
    ],
    outputs: [{ itemId: "golden-apple", count: 1 }]
  },
  {
    id: "sign",
    inputs: [
      { itemId: "plank", count: 6 },
      { itemId: "stick", count: 1 }
    ],
    outputs: [{ itemId: "sign", count: 3 }]
  },
  { id: "wooden-door", inputs: [{ itemId: "plank", count: 6 }], outputs: [{ itemId: "wooden-door", count: 1 }] },
  { id: "sugar", inputs: [{ itemId: "sugar-cane", count: 1 }], outputs: [{ itemId: "sugar", count: 1 }] },
  {
    id: "cake",
    inputs: [
      { itemId: "milk-bucket", count: 3 },
      { itemId: "sugar", count: 2 },
      { itemId: "egg", count: 1 },
      { itemId: "wheat", count: 3 }
    ],
    outputs: [{ itemId: "cake", count: 1 }]
  },
  {
    id: "cookie",
    inputs: [
      { itemId: "wheat", count: 2 },
      { itemId: "cocoa-beans", count: 1 }
    ],
    outputs: [{ itemId: "cookie", count: 8 }]
  },
  {
    id: "flint-and-steel",
    inputs: [
      { itemId: "iron-ingot", count: 1 },
      { itemId: "flint", count: 1 }
    ],
    outputs: [{ itemId: "flint-and-steel", count: 1, instance: { durability: 65 } }]
  },
  {
    id: "compass",
    inputs: [
      { itemId: "iron-ingot", count: 4 },
      { itemId: "redstone-dust", count: 1 }
    ],
    outputs: [{ itemId: "compass", count: 1 }]
  },
  {
    id: "clock",
    inputs: [
      { itemId: "gold-ingot", count: 4 },
      { itemId: "redstone-dust", count: 1 }
    ],
    outputs: [{ itemId: "clock", count: 1 }]
  },
  {
    id: "map",
    inputs: [
      { itemId: "paper", count: 8 },
      { itemId: "compass", count: 1 }
    ],
    outputs: [{ itemId: "map", count: 1 }]
  },
  {
    id: "fishing-rod",
    inputs: [
      { itemId: "stick", count: 3 },
      { itemId: "string", count: 2 }
    ],
    outputs: [{ itemId: "fishing-rod", count: 1, instance: { durability: 65 } }]
  },
  {
    id: "bed",
    inputs: [
      { itemId: "plank", count: 3 },
      { itemId: "wool", count: 3 }
    ],
    outputs: [{ itemId: "bed", count: 1 }]
  },
  {
    id: "tnt",
    inputs: [
      { itemId: "gunpowder", count: 5 },
      { itemId: "sand-block", count: 4 }
    ],
    outputs: [{ itemId: "tnt", count: 1 }]
  },
  {
    id: "bow",
    inputs: [
      { itemId: "stick", count: 3 },
      { itemId: "string", count: 3 }
    ],
    outputs: [{ itemId: "bow", count: 1, instance: { durability: 384 } }]
  },
  {
    id: "arrows",
    inputs: [
      { itemId: "flint", count: 1 },
      { itemId: "stick", count: 1 },
      { itemId: "feather", count: 1 }
    ],
    outputs: [{ itemId: "arrow", count: 4 }]
  },
  { id: "sticks", inputs: [{ itemId: "plank", count: 2 }], outputs: [{ itemId: "stick", count: 4 }] },
  {
    id: "wood-axe",
    inputs: [
      { itemId: "plank", count: 3 },
      { itemId: "stick", count: 2 }
    ],
    outputs: [{ itemId: "wood-axe", count: 1, instance: { durability: 60 } }]
  },
  {
    id: "stone-pickaxe",
    inputs: [
      { itemId: "stick", count: 2 },
      { itemId: "cobblestone", count: 3 }
    ],
    outputs: [{ itemId: "stone-pickaxe", count: 1, instance: { durability: 132 } }]
  },
  {
    id: "wood-sword",
    inputs: [
      { itemId: "plank", count: 2 },
      { itemId: "stick", count: 1 }
    ],
    outputs: [{ itemId: "wood-sword", count: 1 }]
  },
  {
    id: "lantern",
    inputs: [
      { itemId: "plank", count: 2 },
      { itemId: "stone-block", count: 1 }
    ],
    outputs: [{ itemId: "lantern", count: 1 }]
  },
  { id: "workbench", inputs: [{ itemId: "plank", count: 4 }], outputs: [{ itemId: "workbench", count: 1 }] }
];

// playbooks/classic/src/stations.ts
var stack = (itemId, count = 1) => ({ itemId, count });
var pickaxe = (id2, material, durability) => ({
  kind: "shaped",
  id: id2,
  pattern: [stack(material), stack(material), stack(material), null, stack("stick"), null, null, stack("stick"), null],
  outputs: [{ itemId: id2, count: 1, instance: { durability } }]
});
var ring = (id2, material) => ({
  kind: "shaped",
  id: id2,
  pattern: [
    stack(material),
    stack(material),
    stack(material),
    stack(material),
    null,
    stack(material),
    stack(material),
    stack(material),
    stack(material)
  ],
  outputs: [stack(id2)]
});
var shapedRecipes = [
  pickaxe("wood-pickaxe", "plank", 60),
  pickaxe("stone-pickaxe", "cobblestone", 132),
  pickaxe("iron-pickaxe", "iron-ingot", 250),
  pickaxe("gold-pickaxe", "gold-ingot", 32),
  pickaxe("diamond-pickaxe", "diamond", 1561),
  ring("chest", "plank"),
  ring("furnace", "cobblestone")
];
var shapedIds = new Set(shapedRecipes.map((recipe) => recipe.id));
var overworldCraftingRecipes = [
  ...shapedRecipes,
  ...overworldRecipes.filter((recipe) => !shapedIds.has(recipe.id)).map((recipe) => ({
    kind: "shapeless",
    id: recipe.id,
    inputs: recipe.inputs.flatMap((input) => Array.from({ length: input.count }, () => ({ ...input, count: 1 }))),
    outputs: recipe.outputs
  }))
];
var overworldStations = {
  definitions: [
    { kind: "workbench", voxel: 11 },
    { kind: "chest", voxel: 12 },
    { kind: "furnace", voxel: 13 }
  ],
  recipes: overworldCraftingRecipes,
  furnaceRecipes: [
    { id: "smelt-gold", input: stack("gold-ore"), output: stack("gold-ingot"), durationSeconds: 10 },
    { id: "smelt-iron", input: stack("raw-iron"), output: stack("iron-ingot"), durationSeconds: 10 },
    { id: "smelt-stone", input: stack("cobblestone"), output: stack("stone-block"), durationSeconds: 10 },
    { id: "smelt-glass", input: stack("sand-block"), output: stack("glass"), durationSeconds: 10 },
    { id: "smelt-charcoal", input: stack("wood-block"), output: stack("charcoal"), durationSeconds: 10 },
    { id: "smelt-brick", input: stack("clay"), output: stack("brick"), durationSeconds: 10 },
    { id: "smelt-cactus", input: stack("cactus"), output: stack("green-dye"), durationSeconds: 10 },
    { id: "smelt-diamond", input: stack("diamond-ore"), output: stack("diamond"), durationSeconds: 10 },
    { id: "cook-porkchop", input: stack("raw-porkchop"), output: stack("cooked-porkchop"), durationSeconds: 10 },
    { id: "cook-fish", input: stack("raw-fish"), output: stack("cooked-fish"), durationSeconds: 10 }
  ],
  fuels: [
    { itemId: "coal", burnSeconds: 80 },
    { itemId: "charcoal", burnSeconds: 80 },
    { itemId: "wood-block", burnSeconds: 15 },
    { itemId: "plank", burnSeconds: 15 },
    { itemId: "stick", burnSeconds: 5 }
  ]
};

// packages/stdlib/src/server/gameplay/inventory-layout.ts
var DEFAULT_PLAYER_INVENTORY_LAYOUT = Object.freeze({ capacity: 24, hotbarSize: 8 });
var PLAYER_INVENTORY_LAYOUT_CAPABILITY = "seedlands:player-inventory-layout";
function freezePlayerInventoryLayout(layout = DEFAULT_PLAYER_INVENTORY_LAYOUT) {
  if (!layout || !Number.isSafeInteger(layout.capacity) || layout.capacity < 1 || layout.capacity > 64 || !Number.isSafeInteger(layout.hotbarSize) || layout.hotbarSize < 1 || layout.hotbarSize > Math.min(9, layout.capacity))
    throw new TypeError("Player inventory layout is invalid.");
  return Object.freeze({ capacity: layout.capacity, hotbarSize: layout.hotbarSize });
}

// ../../../Users/bytedance/.codex/worktrees/6dd1/seedlands-web-sandbox/node_modules/.pnpm/bitecs@0.4.0/node_modules/bitecs/dist/core/index.min.mjs
var A = (e, t, n) => Object.defineProperty(e, t, { value: n, enumerable: false, writable: true, configurable: true });
var k = /* @__PURE__ */ Symbol.for("bitecs-relation");
var T = /* @__PURE__ */ Symbol.for("bitecs-pairTarget");
var U = /* @__PURE__ */ Symbol.for("bitecs-isPairComponent");
var x = /* @__PURE__ */ Symbol.for("bitecs-relationData");
var Y = () => {
  let e = { pairsMap: /* @__PURE__ */ new Map(), initStore: void 0, exclusiveRelation: false, autoRemoveSubject: false, onTargetRemoved: void 0 }, t = (n) => {
    if (n === void 0) throw Error("Relation target is undefined");
    let o = n === "*" ? y : n;
    if (!e.pairsMap.has(o)) {
      let r = e.initStore ? e.initStore(n) : {};
      A(r, k, t), A(r, T, o), A(r, U, true), e.pairsMap.set(o, r);
    }
    return e.pairsMap.get(o);
  };
  return A(t, x, e), t;
};
var Re = /* @__PURE__ */ Symbol.for("bitecs-wildcard");
function rt() {
  let e = Y();
  return Object.defineProperty(e, Re, { value: true, enumerable: false, writable: false, configurable: false }), e;
}
function at() {
  let e = /* @__PURE__ */ Symbol.for("bitecs-global-wildcard");
  return globalThis[e] || (globalThis[e] = rt()), globalThis[e];
}
var y = at();
function st() {
  return Y();
}
function it() {
  let e = /* @__PURE__ */ Symbol.for("bitecs-global-isa");
  return globalThis[e] || (globalThis[e] = st()), globalThis[e];
}
var B = it();
var v = /* @__PURE__ */ Symbol.for("bitecs-opType");
var D = /* @__PURE__ */ Symbol.for("bitecs-opTerms");
var se = (e) => (...t) => ({ [v]: e, [D]: t });
var Ae = se("Or");
var ke = se("And");
var He = se("Not");
var F = /* @__PURE__ */ Symbol.for("bitecs-modifierType");
var Rt = { [F]: "buffer" };
var Pe = { [F]: "nested" };
var Ue = (e) => (...t) => ({ [v]: e, [D]: t });
var xt = Ue("add");
var gt = Ue("remove");

// packages/stdlib/src/world/macro-world.ts
var MACRO_REGION_SIZE = 256;
var RIVER_CELL = 768;
var LAKE_CELL = 1024;
var CURRENT_MACRO_GENERATOR_VERSION = 3;
var riverDescriptorCache = /* @__PURE__ */ new Map();
var clamp = (value, min, max) => Math.min(max, Math.max(min, value));
var floorDiv = (value, divisor) => Math.floor(value / divisor);
var smooth = (value) => value * value * (3 - 2 * value);
function hash(seed, x2, z) {
  let value = (seed ^ Math.imul(x2, 374761393) ^ Math.imul(z, 668265263)) >>> 0;
  value = Math.imul(value ^ value >>> 13, 1274126177) >>> 0;
  return ((value ^ value >>> 16) >>> 0) / 4294967296;
}
function valueNoise(seed, x2, z, scale2) {
  const sx = x2 / scale2, sz = z / scale2;
  const ix = Math.floor(sx), iz = Math.floor(sz);
  const tx = smooth(sx - ix), tz = smooth(sz - iz);
  const a = hash(seed, ix, iz), b = hash(seed, ix + 1, iz);
  const c = hash(seed, ix, iz + 1), d = hash(seed, ix + 1, iz + 1);
  return a + (b - a) * tx + (c + (d - c) * tx - (a + (b - a) * tx)) * tz;
}
function rawGeography(seed, x2, z) {
  const continentalness = valueNoise(seed ^ 5370206, x2, z, 1800) * 2 - 1;
  const baseElevation = 14 + continentalness * 6 + (valueNoise(seed ^ 72846, x2, z, 640) * 2 - 1) * 2;
  const relief = clamp(
    valueNoise(seed ^ 2135587861, x2, z, 440) * 0.72 + valueNoise(seed ^ 455385, x2, z, 920) * 0.28,
    0,
    1
  );
  const erosion = valueNoise(seed ^ 3373489, x2, z, 720);
  const ridge = Math.max(0, relief - 0.38) / 0.62;
  const terrainHeight = Math.round(
    baseElevation + ridge * (7 + (1 - erosion) * 12) + (valueNoise(seed ^ 270441, x2, z, 84) * 2 - 1) * (1 + relief * 2)
  );
  return { continentalness, baseElevation, relief, erosion, terrainHeight };
}
function distanceToSegment(x2, z, ax, az, bx, bz) {
  const dx = bx - ax, dz = bz - az;
  const lengthSq = dx * dx + dz * dz;
  const t = lengthSq === 0 ? 0 : clamp(((x2 - ax) * dx + (z - az) * dz) / lengthSq, 0, 1);
  const px = ax + dx * t, pz = az + dz * t;
  return { distance: Math.hypot(x2 - px, z - pz), tangent: [dx, dz] };
}
function riverDescriptor(seed, cellX, cellZ, generatorVersion) {
  const cacheKey = `${seed}:${generatorVersion}:${cellX},${cellZ}`;
  if (riverDescriptorCache.has(cacheKey)) return riverDescriptorCache.get(cacheKey) ?? null;
  const eligibility = hash(seed ^ 4479629, cellX, cellZ);
  if (eligibility < 0.76) {
    riverDescriptorCache.set(cacheKey, null);
    return null;
  }
  const source = [
    Math.round((cellX + 0.12 + hash(seed ^ 1979815, cellX, cellZ) * 0.76) * RIVER_CELL),
    Math.round((cellZ + 0.12 + hash(seed ^ 810657, cellX, cellZ) * 0.76) * RIVER_CELL)
  ];
  let direction = [1, 0];
  let lowest = Infinity;
  for (let step2 = 0; step2 < 8; step2 += 1) {
    const angle = step2 / 8 * Math.PI * 2;
    const candidateX = source[0] + Math.cos(angle) * 640;
    const candidateZ = source[1] + Math.sin(angle) * 640;
    const height = rawGeography(seed, candidateX, candidateZ).terrainHeight;
    if (height < lowest) {
      lowest = height;
      direction = [Math.cos(angle), Math.sin(angle)];
    }
  }
  const perpendicular = [-direction[1], direction[0]];
  const bend = (hash(seed ^ 1150299, cellX, cellZ) * 2 - 1) * 34;
  const path = [source];
  for (let step2 = 1; step2 <= 6; step2 += 1) {
    const forward = step2 * 112;
    const offset = Math.sin(step2 * 1.17 + hash(seed ^ 490004, cellX, cellZ) * Math.PI * 2) * bend;
    path.push([
      Math.round(source[0] + direction[0] * forward + perpendicular[0] * offset),
      Math.round(source[1] + direction[1] * forward + perpendicular[1] * offset)
    ]);
  }
  const width = 4 + Math.floor(hash(seed ^ 679649, cellX, cellZ) * 5);
  const endpoint = path.at(-1);
  let waterLevel = clamp(
    Math.round(
      Math.min(rawGeography(seed, ...source).terrainHeight, rawGeography(seed, ...endpoint).terrainHeight) + 1
    ),
    10,
    24
  );
  if (generatorVersion >= 3) {
    let lowestCorridor = Infinity;
    for (let index = 1; index < path.length; index += 1) {
      const previous = path[index - 1];
      const current2 = path[index];
      const dx = current2[0] - previous[0];
      const dz = current2[1] - previous[1];
      const length2 = Math.hypot(dx, dz) || 1;
      const normal = [-dz / length2, dx / length2];
      const sampleCount = Math.max(8, Math.ceil(length2 / 14));
      for (let sample = 0; sample <= sampleCount; sample += 1) {
        const amount = sample / sampleCount;
        const x2 = previous[0] + dx * amount;
        const z = previous[1] + dz * amount;
        for (const offset of [0, width + 1, -(width + 1), width + 4, -(width + 4)])
          lowestCorridor = Math.min(
            lowestCorridor,
            rawGeography(seed, Math.round(x2 + normal[0] * offset), Math.round(z + normal[1] * offset)).terrainHeight
          );
      }
    }
    waterLevel = clamp(Math.floor(lowestCorridor) - 1, 8, 24);
  }
  const descriptor = {
    id: `river:${cellX},${cellZ}`,
    source,
    path,
    width,
    waterLevel,
    direction
  };
  if (riverDescriptorCache.size >= 2048) riverDescriptorCache.clear();
  riverDescriptorCache.set(cacheKey, descriptor);
  return descriptor;
}
function riverDescriptorsNear(seed, x2, z, generatorVersion = CURRENT_MACRO_GENERATOR_VERSION) {
  const cellX = floorDiv(x2, RIVER_CELL), cellZ = floorDiv(z, RIVER_CELL);
  const descriptors = [];
  for (let dz = -1; dz <= 1; dz += 1)
    for (let dx = -1; dx <= 1; dx += 1) {
      const descriptor = riverDescriptor(seed, cellX + dx, cellZ + dz, generatorVersion);
      if (descriptor) descriptors.push(descriptor);
    }
  return descriptors;
}
function lakeAt(seed, x2, z) {
  const cellX = floorDiv(x2, LAKE_CELL), cellZ = floorDiv(z, LAKE_CELL);
  let closest = null;
  for (let dz = -1; dz <= 1; dz += 1)
    for (let dx = -1; dx <= 1; dx += 1) {
      const lx = cellX + dx, lz = cellZ + dz;
      if (hash(seed ^ 376493, lx, lz) < 0.84) continue;
      const centerX = Math.round((lx + 0.18 + hash(seed ^ 529314, lx, lz) * 0.64) * LAKE_CELL);
      const centerZ = Math.round((lz + 0.18 + hash(seed ^ 327066, lx, lz) * 0.64) * LAKE_CELL);
      const center = rawGeography(seed, centerX, centerZ);
      if (center.terrainHeight > 23 || center.continentalness > 0.42) continue;
      const radiusX = 28 + hash(seed ^ 66205, lx, lz) * 34;
      const radiusZ = 24 + hash(seed ^ 93985, lx, lz) * 30;
      const normalized = Math.hypot((x2 - centerX) / radiusX, (z - centerZ) / radiusZ);
      if (normalized > 1.15) continue;
      const distance = Math.max(0, normalized - 1) * Math.max(radiusX, radiusZ);
      if (!closest || distance < closest.distance) {
        closest = {
          kind: "lake",
          id: `lake:${lx},${lz}`,
          distance,
          water: normalized <= 1,
          waterLevel: clamp(center.terrainHeight + 1, 10, 23),
          direction: null,
          shoreDistance: (normalized - 1) * Math.max(radiusX, radiusZ)
        };
      }
    }
  return closest;
}
function hydrologyAt(seed, x2, z, generatorVersion) {
  const lake = lakeAt(seed, x2, z);
  if (lake?.water) return lake;
  let best = lake;
  for (const descriptor of riverDescriptorsNear(seed, x2, z, generatorVersion)) {
    let closestDistance = Infinity;
    let tangent = descriptor.direction;
    for (let index = 1; index < descriptor.path.length; index += 1) {
      const previous = descriptor.path[index - 1], current2 = descriptor.path[index];
      const sample = distanceToSegment(x2, z, previous[0], previous[1], current2[0], current2[1]);
      if (sample.distance < closestDistance) {
        closestDistance = sample.distance;
        tangent = sample.tangent;
      }
    }
    const bankWidth = descriptor.width + 4;
    if (closestDistance > bankWidth) continue;
    const length2 = Math.hypot(tangent[0], tangent[1]) || 1;
    const direction = [tangent[0] / length2, tangent[1] / length2];
    if (!best || closestDistance < best.distance) {
      best = {
        kind: "river",
        id: descriptor.id,
        distance: closestDistance,
        water: closestDistance <= descriptor.width,
        waterLevel: descriptor.waterLevel,
        direction,
        shoreDistance: closestDistance - descriptor.width
      };
    }
  }
  return best ?? {
    kind: "dry",
    id: null,
    distance: Infinity,
    water: false,
    waterLevel: null,
    direction: null,
    shoreDistance: Infinity
  };
}
function macroAt(seed, x2, z, generatorVersion = CURRENT_MACRO_GENERATOR_VERSION) {
  const geography = rawGeography(seed, x2, z);
  const hydrology = hydrologyAt(seed, x2, z, generatorVersion);
  let terrainHeight = geography.terrainHeight;
  if (hydrology.kind !== "dry" && hydrology.waterLevel !== null) {
    if (generatorVersion < 3)
      terrainHeight = Math.min(geography.terrainHeight, hydrology.waterLevel - (hydrology.water ? 2 : 1));
    else if (hydrology.water) terrainHeight = Math.min(geography.terrainHeight, hydrology.waterLevel - 2);
    else {
      const shoreDistance = Math.max(0, hydrology.shoreDistance);
      const transitionCap = hydrology.waterLevel + Math.floor(Math.min(3, shoreDistance) * 0.75);
      terrainHeight = Math.max(hydrology.waterLevel, Math.min(geography.terrainHeight, transitionCap));
    }
  }
  const latitude = Math.sin((z + (seed & 65535) * 0.17) / 2600) * 0.18;
  const temperature = clamp(
    0.62 + latitude + (valueNoise(seed ^ 183017, x2, z, 1300) * 2 - 1) * 0.24 - Math.max(0, terrainHeight - 18) * 0.018,
    0,
    1
  );
  const wetness = hydrology.kind === "dry" ? 0 : hydrology.water ? 0.26 : 0.12;
  const humidity = clamp(
    valueNoise(seed ^ 560291, x2, z, 960) * 0.72 + valueNoise(seed ^ 109015, x2, z, 300) * 0.28 + wetness,
    0,
    1
  );
  let biome = "plains";
  if (hydrology.water || hydrology.kind !== "dry" && humidity > 0.58) biome = "wet";
  else if (temperature < 0.27) biome = "cold";
  else if (humidity < 0.31) biome = "dry";
  else if (geography.relief > 0.66 || terrainHeight > 29) biome = "mountain";
  else if (humidity > 0.58) biome = "forest";
  return {
    region: [floorDiv(x2, MACRO_REGION_SIZE), floorDiv(z, MACRO_REGION_SIZE)],
    ...geography,
    terrainHeight,
    temperature,
    humidity,
    biome,
    hydrology
  };
}

// packages/stdlib/src/world/ore-generation.ts
var COAL_ORE_SALT = 1129267532;
var IRON_ORE_SALT = 1230131022;
var GOLD_ORE_SALT = 1196379204;
var DIAMOND_ORE_SALT = 1145651533;
var STONE_VOXEL = 3;
var COAL_ORE_VOXEL = 14;
var IRON_ORE_VOXEL = 15;
function oreHash(seed, groupX, groupY, groupZ, salt) {
  let hash3 = (seed ^ salt ^ Math.imul(groupX, 2654435761) ^ Math.imul(groupY, 2246822519) ^ Math.imul(groupZ, 3266489917)) >>> 0;
  hash3 = Math.imul(hash3 ^ hash3 >>> 16, 2146121005) >>> 0;
  hash3 = Math.imul(hash3 ^ hash3 >>> 15, 2221713035) >>> 0;
  return (hash3 ^ hash3 >>> 16) >>> 0;
}
function oreVoxel(seed, x2, y2, z, terrainHeight, baseVoxel2, generatorVersion) {
  if (generatorVersion < 4 || baseVoxel2 !== STONE_VOXEL) return baseVoxel2;
  const depth = terrainHeight - y2;
  const groupX = Math.floor(x2 / 2);
  const groupY = Math.floor(y2 / 2);
  const groupZ = Math.floor(z / 2);
  if (generatorVersion >= 5 && y2 >= 0) {
    if (y2 < 16 && depth >= 12 && oreHash(seed, groupX, groupY, groupZ, DIAMOND_ORE_SALT) % 997 < 8) return 20;
    if (y2 < 32 && depth >= 8 && oreHash(seed, groupX, groupY, groupZ, GOLD_ORE_SALT) % 997 < 24) return 19;
  }
  if (depth >= 8 && oreHash(seed, groupX, groupY, groupZ, IRON_ORE_SALT) % 97 < 6) return IRON_ORE_VOXEL;
  if (depth >= 4 && oreHash(seed, groupX, groupY, groupZ, COAL_ORE_SALT) % 97 < 10) return COAL_ORE_VOXEL;
  return baseVoxel2;
}

// packages/stdlib/src/world/cave-generation.ts
var CAVE_SALT = 1128355397;
function caveHash(seed, gx, gy, gz) {
  let hash3 = (seed ^ CAVE_SALT ^ Math.imul(gx, 2654435761) ^ Math.imul(gy, 2246822519) ^ Math.imul(gz, 3266489917)) >>> 0;
  hash3 = Math.imul(hash3 ^ hash3 >>> 16, 2146121005) >>> 0;
  hash3 = Math.imul(hash3 ^ hash3 >>> 15, 2221713035) >>> 0;
  return (hash3 ^ hash3 >>> 16) >>> 0;
}
function caveAir(seed, x2, y2, z, height, generatorVersion) {
  if (generatorVersion < 6) return false;
  if (y2 < 0) return false;
  const depth = height - y2;
  if (depth < 4) return false;
  const gx = Math.floor(x2 / 2);
  const gy = Math.floor(y2 / 2);
  const gz = Math.floor(z / 2);
  const primary = caveHash(seed, gx, gy, gz) % 1e3;
  const secondary = caveHash(seed ^ 1540483477, gx, gy, gz) % 1e3;
  return primary < 96 && secondary < 420;
}

// packages/stdlib/src/world/vegetation.ts
var IDs = {
  Air: 0,
  Grass: 1,
  Dirt: 2,
  Wood: 4,
  Leaves: 5,
  Sapling: 31,
  TallGrass: 32,
  Flower: 33,
  Mushroom: 34,
  SugarCane: 35,
  Cactus: 36
};
var hash2 = (seed, x2, z) => {
  let h = (seed ^ Math.imul(x2, 374761393) ^ Math.imul(z, 668265263)) >>> 0;
  h = Math.imul(h ^ h >>> 13, 1274126177) >>> 0;
  return ((h ^ h >>> 16) >>> 0) / 4294967296;
};
function vegetationAt(seed, x2, y2, z, context, generatorVersion = 10) {
  if (y2 !== context.terrainHeight + 1 || context.hydrology.water) return null;
  const roll = hash2(seed ^ 5653831, x2, z);
  if (context.biome === "dry") return roll > 0.992 ? IDs.Cactus : null;
  if (context.biome === "wet") return roll > 0.94 ? IDs.SugarCane : null;
  if (context.biome === "forest" && roll > 0.985) return IDs.Mushroom;
  if ((context.biome === "plains" || context.biome === "forest") && roll > 0.965) return IDs.Flower;
  const tallGrassThreshold = generatorVersion >= 11 && ["plains", "forest"].includes(context.biome) ? 0.88 : 0.82;
  if (context.biome !== "mountain" && context.biome !== "cold" && roll > tallGrassThreshold) return IDs.TallGrass;
  return null;
}

// packages/stdlib/src/world/dungeon-generation.ts
var mix = (seed, x2, z) => {
  let h = (seed ^ 1146441287 ^ Math.imul(x2, 2654435761) ^ Math.imul(z, 2246822519)) >>> 0;
  h = Math.imul(h ^ h >>> 16, 2146121005) >>> 0;
  return (h ^ h >>> 15) >>> 0;
};
function dungeonFor(seed, x2, z, version2) {
  if (version2 < 8) return null;
  const rx = Math.floor(x2 / 64), rz = Math.floor(z / 64), h = mix(seed, rx, rz);
  if (h % 7 !== 0) return null;
  const cx = rx * 64 + 16 + (h >>> 4) % 32, cz = rz * 64 + 16 + (h >>> 10) % 32, cy = 5 + (h >>> 16) % 18;
  return Object.freeze({
    id: "dungeon:" + rx + "," + rz,
    center: [cx, cy, cz],
    radiusX: 3 + (h & 1),
    radiusZ: 3 + (h >>> 1 & 1),
    entrance: ["north", "south", "west", "east"][h >>> 2 & 3]
  });
}
function dungeonVoxel(d, x2, y2, z) {
  const [cx, cy, cz] = d.center, dx = Math.abs(x2 - cx), dy = Math.abs(y2 - cy), dz = Math.abs(z - cz);
  if (dx > d.radiusX || dz > d.radiusZ || dy > 2) return null;
  const boundary = dx === d.radiusX || dz === d.radiusZ || dy === 2;
  const entrance = y2 === cy && (d.entrance === "north" && z === cz - d.radiusZ && dx === 0 || d.entrance === "south" && z === cz + d.radiusZ && dx === 0 || d.entrance === "west" && x2 === cx - d.radiusX && dz === 0 || d.entrance === "east" && x2 === cx + d.radiusX && dz === 0);
  if (entrance) return 0;
  if (x2 === cx && y2 === cy - 1 && z === cz) return 37;
  if (y2 === cy - 1 && dx === d.radiusX - 1 && dz === d.radiusZ - 1) return 38;
  return boundary ? 17 : 0;
}

// packages/stdlib/src/world/geology.ts
var GEOLOGY_SALT = 1195724601;
var REDSTONE_SALT = 1380271187;
var IDS = {
  Air: 0,
  Stone: 3,
  Water: 8,
  Bedrock: 42,
  Gravel: 43,
  LapisOre: 44,
  Clay: 45,
  Ice: 46,
  SnowBlock: 47
};
function geologyVoxel(seed, x2, y2, z, context, base, generatorVersion) {
  return geologyVoxelFromColumn(
    seed,
    x2,
    y2,
    z,
    context.terrainHeight,
    context.biome,
    context.hydrology.waterLevel,
    base,
    generatorVersion
  );
}
function geologyVoxelFromColumn(seed, x2, y2, z, terrainHeight, biome, waterLevel, base, generatorVersion) {
  if (generatorVersion < 9) return base;
  const hash3 = oreHash(seed, Math.floor(x2 / 2), Math.floor(y2 / 2), Math.floor(z / 2), GEOLOGY_SALT);
  if (y2 <= 0 || y2 < 5 && hash3 % 5 >= y2) return IDS.Bedrock;
  if (biome === "cold" && base === IDS.Water && y2 === waterLevel) return IDS.Ice;
  if (biome === "cold" && base !== IDS.Air && y2 === terrainHeight - 1) return IDS.SnowBlock;
  if (waterLevel !== null && base !== IDS.Air && y2 > terrainHeight - 3 && hash3 % 5 < 3) return IDS.Clay;
  if (base === IDS.Stone && y2 >= 0 && y2 < 32 && terrainHeight - y2 >= 8 && hash3 % 997 < 20)
    return IDS.LapisOre;
  if (generatorVersion >= 10 && base === IDS.Stone && y2 >= 0 && y2 < 24 && terrainHeight - y2 >= 10) {
    const redstone = oreHash(seed, Math.floor(x2 / 2), Math.floor(y2 / 2), Math.floor(z / 2), REDSTONE_SALT);
    if (redstone % 997 < 32) return 72;
  }
  if (base === IDS.Stone && terrainHeight - y2 >= 4 && (hash3 >>> 8) % 97 < 8) return IDS.Gravel;
  return base;
}

// packages/stdlib/src/world/remaining-voxel-presentation.ts
var remainingVoxelNames = Object.freeze({
  59: "\u67AF\u704C\u6728",
  60: "\u7F8A\u6BDB\u5757",
  61: "\u7EA2\u82B1",
  62: "\u7EA2\u8611\u83C7",
  63: "\u7816\u5757",
  64: "\u4E66\u67B6",
  65: "\u82D4\u77F3",
  66: "\u97F3\u7B26\u76D2",
  67: "\u5531\u7247\u673A",
  68: "\u5357\u74DC",
  69: "\u5357\u74DC\u706F",
  70: "\u6D3B\u677F\u95E8",
  71: "\u71C3\u70E7\u7194\u7089",
  72: "\u7EA2\u77F3\u77FF",
  73: "\u53D1\u5149\u7EA2\u77F3\u77FF"
});
var remainingVoxelColors = Object.freeze({
  59: [0.42, 0.28, 0.15],
  60: [0.85, 0.85, 0.82],
  61: [0.85, 0.12, 0.16],
  62: [0.72, 0.12, 0.12],
  63: [0.55, 0.2, 0.14],
  64: [0.5, 0.3, 0.15],
  65: [0.32, 0.42, 0.28],
  66: [0.4, 0.22, 0.12],
  67: [0.32, 0.18, 0.1],
  68: [0.9, 0.42, 0.08],
  69: [1, 0.52, 0.08],
  70: [0.55, 0.33, 0.16],
  71: [0.5, 0.3, 0.18],
  72: [0.55, 0.18, 0.18],
  73: [0.9, 0.1, 0.08]
});

// packages/stdlib/src/world/tree-generation.ts
var thresholds = { forest: 0.968, plains: 0.987, wet: 0.981, mountain: 0.995 };
var treeOriginThreshold = (biome, generatorVersion) => biome === "forest" && generatorVersion >= 11 ? 0.978 : thresholds[biome] ?? 1;
var isTreeOriginContext = (context, roll, generatorVersion) => !context.hydrology.water && context.terrainHeight >= 15 && roll > treeOriginThreshold(context.biome, generatorVersion);
var treeVoxelAtOffset = (dx, y2, dz, terrainHeight, generatorVersion) => {
  const crownY = y2 - terrainHeight;
  if (dx === 0 && dz === 0 && crownY > 0 && crownY <= (generatorVersion >= 11 ? 5 : 4)) return 4;
  if (generatorVersion < 11)
    return dx <= 2 && dz <= 2 && crownY >= 3 && crownY <= 6 && (dx + dz < 4 || crownY >= 5) ? 5 : null;
  return crownY >= 4 && crownY <= 5 && dx <= 2 && dz <= 2 && dx + dz < 4 || crownY === 6 && dx <= 1 && dz <= 1 || crownY === 7 && dx + dz <= 1 ? 5 : null;
};

// packages/stdlib/src/world/voxel.ts
var CHUNK_SIZE = 32;
var GENERATOR_VERSION = 11;
var SUPPORTED_GENERATOR_VERSIONS = Object.freeze([2, 3, 4, 5, 6, 7, 8, 9, 10, 11]);
var Voxel = {
  Air: 0,
  Grass: 1,
  Dirt: 2,
  Stone: 3,
  Wood: 4,
  Leaves: 5,
  Sand: 6,
  Snow: 7,
  Water: 8,
  Glowstone: 9,
  Lantern: 10,
  Workbench: 11,
  Chest: 12,
  Furnace: 13,
  CoalOre: 14,
  IronOre: 15,
  Planks: 16,
  Cobblestone: 17,
  Glass: 18,
  GoldOre: 19,
  DiamondOre: 20,
  IronBlock: 21,
  GoldBlock: 22,
  DiamondBlock: 23,
  Sandstone: 24,
  StoneBricks: 25,
  Farmland: 26,
  Lava: 27,
  Obsidian: 28,
  Fire: 29,
  Tnt: 30,
  Sapling: 31,
  TallGrass: 32,
  Flower: 33,
  Mushroom: 34,
  SugarCane: 35,
  Cactus: 36,
  Spawner: 37,
  DungeonChest: 38,
  Rail: 39,
  PoweredRail: 40,
  DetectorRail: 41,
  Bedrock: 42,
  Gravel: 43,
  LapisOre: 44,
  Clay: 45,
  Ice: 46,
  SnowBlock: 47,
  LapisBlock: 48,
  Slab: 49,
  WoodStairs: 50,
  CobblestoneStairs: 51,
  WoodenDoor: 52,
  Ladder: 53,
  Torch: 54,
  Bed: 55,
  Sign: 56,
  Fence: 57,
  Cake: 58,
  DeadBush: 59,
  Wool: 60,
  RedFlower: 61,
  RedMushroom: 62,
  Bricks: 63,
  Bookshelf: 64,
  MossyCobblestone: 65,
  NoteBlock: 66,
  Jukebox: 67,
  Pumpkin: 68,
  JackOLantern: 69,
  Trapdoor: 70,
  LitFurnace: 71,
  RedstoneOre: 72,
  LitRedstoneOre: 73,
  ...coloredWoolVoxels
};
var MAX_VOXEL_ID = Voxel.BlackWool;
var FaceMaterial = {
  GrassTop: 1,
  GrassSide: 2,
  Dirt: 3,
  Stone: 4,
  Sand: 5,
  WoodSide: 6,
  WoodEnd: 7,
  Leaves: 8,
  Snow: 9,
  Water: 10,
  Glowstone: 11,
  LanternFrame: 12,
  LanternGlow: 13,
  Workbench: 14,
  Chest: 15,
  Furnace: 16,
  CoalOre: 17,
  IronOre: 18,
  Planks: 19,
  Cobblestone: 20,
  Glass: 21,
  GoldOre: 22,
  DiamondOre: 23,
  IronBlock: 24,
  GoldBlock: 25,
  DiamondBlock: 26,
  Sandstone: 27,
  StoneBricks: 28,
  Farmland: 29,
  Lava: 30,
  Obsidian: 31,
  Fire: 32,
  Tnt: 33,
  Sapling: 34,
  TallGrass: 35,
  Flower: 36,
  Mushroom: 37,
  SugarCane: 38,
  Cactus: 39,
  Spawner: 40,
  DungeonChest: 41,
  Rail: 42,
  PoweredRail: 43,
  DetectorRail: 44,
  Bedrock: 45,
  Gravel: 46,
  LapisOre: 47,
  Clay: 48,
  Ice: 49,
  SnowBlock: 50,
  LapisBlock: 51,
  Slab: 52,
  WoodStairs: 53,
  CobblestoneStairs: 54,
  WoodenDoor: 55,
  Ladder: 56,
  Torch: 57,
  Bed: 58,
  Sign: 59,
  Fence: 60,
  Cake: 61,
  DeadBush: 62,
  Wool: 63,
  RedFlower: 64,
  RedMushroom: 65,
  Bricks: 66,
  Bookshelf: 67,
  MossyCobblestone: 68,
  NoteBlock: 69,
  Jukebox: 70,
  Pumpkin: 71,
  JackOLantern: 72,
  Trapdoor: 73,
  LitFurnace: 74,
  RedstoneOre: 75,
  LitRedstoneOre: 76,
  TorchFlame: 77,
  ...coloredWoolFaceMaterials
};
var voxelNames = {
  ...remainingVoxelNames,
  [Voxel.Grass]: "\u8349\u65B9\u5757",
  [Voxel.Dirt]: "\u6CE5\u571F",
  [Voxel.Stone]: "\u77F3\u5934",
  [Voxel.Wood]: "\u539F\u6728",
  [Voxel.Leaves]: "\u6811\u53F6",
  [Voxel.Sand]: "\u6C99\u783E",
  [Voxel.Snow]: "\u96EA",
  [Voxel.Water]: "\u6C34",
  [Voxel.Glowstone]: "\u8F89\u5149\u77F3",
  [Voxel.Lantern]: "\u706F\u7B3C",
  [Voxel.Workbench]: "\u5DE5\u4F5C\u53F0",
  [Voxel.Chest]: "\u7BB1\u5B50",
  [Voxel.Furnace]: "\u7194\u7089",
  [Voxel.CoalOre]: "\u7164\u77FF\u77F3",
  [Voxel.IronOre]: "\u94C1\u77FF\u77F3",
  [Voxel.Planks]: "\u6728\u677F",
  [Voxel.Cobblestone]: "\u5706\u77F3",
  [Voxel.Glass]: "\u73BB\u7483",
  [Voxel.DiamondBlock]: "\u94BB\u77F3\u5757",
  [Voxel.GoldBlock]: "\u91D1\u5757",
  [Voxel.IronBlock]: "\u94C1\u5757",
  [Voxel.DiamondOre]: "\u94BB\u77F3\u77FF\u77F3",
  [Voxel.GoldOre]: "\u91D1\u77FF\u77F3",
  [Voxel.Sandstone]: "\u7802\u5CA9",
  [Voxel.StoneBricks]: "\u77F3\u7816",
  [Voxel.Farmland]: "\u8015\u5730",
  [Voxel.Lava]: "\u7194\u5CA9",
  [Voxel.Obsidian]: "\u9ED1\u66DC\u77F3",
  [Voxel.Fire]: "\u706B",
  [Voxel.Tnt]: "TNT",
  [Voxel.Sapling]: "\u6811\u82D7",
  [Voxel.TallGrass]: "\u9AD8\u8349",
  [Voxel.Flower]: "\u82B1",
  [Voxel.Mushroom]: "\u8611\u83C7",
  [Voxel.SugarCane]: "\u7518\u8517",
  [Voxel.Cactus]: "\u4ED9\u4EBA\u638C",
  [Voxel.Spawner]: "\u5237\u602A\u7B3C",
  [Voxel.DungeonChest]: "\u5730\u7262\u6218\u5229\u54C1\u7BB1",
  [Voxel.Rail]: "\u94C1\u8F68",
  [Voxel.PoweredRail]: "\u52A8\u529B\u94C1\u8F68",
  [Voxel.DetectorRail]: "\u63A2\u6D4B\u94C1\u8F68",
  [Voxel.Bedrock]: "\u57FA\u5CA9",
  [Voxel.Gravel]: "\u7802\u783E",
  [Voxel.LapisOre]: "\u9752\u91D1\u77F3\u77FF",
  [Voxel.Clay]: "\u9ECF\u571F\u5757",
  [Voxel.Ice]: "\u51B0",
  [Voxel.SnowBlock]: "\u96EA\u5757",
  [Voxel.LapisBlock]: "\u9752\u91D1\u77F3\u5757",
  [Voxel.Slab]: "\u534A\u7816",
  [Voxel.WoodStairs]: "\u6728\u697C\u68AF",
  [Voxel.CobblestoneStairs]: "\u5706\u77F3\u697C\u68AF",
  [Voxel.WoodenDoor]: "\u6728\u95E8",
  [Voxel.Ladder]: "\u68AF\u5B50",
  [Voxel.Torch]: "\u706B\u628A",
  [Voxel.Bed]: "\u5E8A",
  [Voxel.Sign]: "\u544A\u793A\u724C",
  [Voxel.Fence]: "\u6805\u680F",
  [Voxel.Cake]: "\u86CB\u7CD5"
};
for (const [, name, voxel2] of woolVoxelColors) voxelNames[voxel2] = name + "\u7F8A\u6BDB\u5757";
var voxelColors = {
  ...remainingVoxelColors,
  [Voxel.Grass]: [0.25, 0.62, 0.25],
  [Voxel.Dirt]: [0.42, 0.25, 0.12],
  [Voxel.Stone]: [0.45, 0.48, 0.52],
  [Voxel.Wood]: [0.36, 0.2, 0.08],
  [Voxel.Leaves]: [0.12, 0.4, 0.14],
  [Voxel.Sand]: [0.76, 0.67, 0.43],
  [Voxel.Snow]: [0.9, 0.95, 1],
  [Voxel.Water]: [0.12, 0.4, 0.72],
  [Voxel.Glowstone]: [1, 0.58, 0.18],
  [Voxel.Lantern]: [0.86, 0.58, 0.22],
  [Voxel.Workbench]: [0.52, 0.31, 0.14],
  [Voxel.Chest]: [0.58, 0.36, 0.15],
  [Voxel.Furnace]: [0.34, 0.36, 0.37],
  [Voxel.CoalOre]: [0.2, 0.22, 0.22],
  [Voxel.IronOre]: [0.55, 0.43, 0.35],
  [Voxel.Planks]: [0.67, 0.47, 0.27],
  [Voxel.Cobblestone]: [0.42, 0.45, 0.45],
  [Voxel.Glass]: [0.72, 0.88, 0.9],
  [Voxel.DiamondBlock]: [0.28, 0.8, 0.81],
  [Voxel.GoldBlock]: [0.9, 0.72, 0.24],
  [Voxel.IronBlock]: [0.75, 0.8, 0.77],
  [Voxel.DiamondOre]: [0.3, 0.68, 0.7],
  [Voxel.GoldOre]: [0.6, 0.53, 0.25],
  [Voxel.Sandstone]: [0.83, 0.76, 0.55],
  [Voxel.StoneBricks]: [0.5, 0.52, 0.54],
  [Voxel.Farmland]: [0.3, 0.19, 0.11],
  [Voxel.Lava]: [0.95, 0.24, 0.04],
  [Voxel.Obsidian]: [0.12, 0.08, 0.18],
  [Voxel.Fire]: [1, 0.35, 0.04],
  [Voxel.Tnt]: [0.72, 0.12, 0.08],
  [Voxel.Sapling]: [0.2, 0.55, 0.16],
  [Voxel.TallGrass]: [0.28, 0.65, 0.22],
  [Voxel.Flower]: [0.85, 0.25, 0.3],
  [Voxel.Mushroom]: [0.45, 0.2, 0.15],
  [Voxel.SugarCane]: [0.45, 0.75, 0.3],
  [Voxel.Cactus]: [0.18, 0.55, 0.28],
  [Voxel.Spawner]: [0.18, 0.2, 0.22],
  [Voxel.DungeonChest]: [0.36, 0.24, 0.12],
  [Voxel.Rail]: [0.5, 0.45, 0.34],
  [Voxel.PoweredRail]: [0.72, 0.48, 0.12],
  [Voxel.DetectorRail]: [0.62, 0.35, 0.16],
  [Voxel.Bedrock]: [0.15, 0.16, 0.17],
  [Voxel.Gravel]: [0.48, 0.46, 0.44],
  [Voxel.LapisOre]: [0.18, 0.28, 0.64],
  [Voxel.Clay]: [0.55, 0.6, 0.63],
  [Voxel.Ice]: [0.55, 0.78, 0.9],
  [Voxel.SnowBlock]: [0.92, 0.96, 1],
  [Voxel.LapisBlock]: [0.12, 0.24, 0.72],
  [Voxel.Slab]: [0.46, 0.48, 0.5],
  [Voxel.WoodStairs]: [0.62, 0.42, 0.23],
  [Voxel.CobblestoneStairs]: [0.4, 0.43, 0.43],
  [Voxel.WoodenDoor]: [0.55, 0.34, 0.16],
  [Voxel.Ladder]: [0.64, 0.43, 0.2],
  [Voxel.Torch]: [0.95, 0.62, 0.18],
  [Voxel.Bed]: [0.72, 0.15, 0.12],
  [Voxel.Sign]: [0.68, 0.48, 0.25],
  [Voxel.Fence]: [0.55, 0.35, 0.17],
  [Voxel.Cake]: [0.9, 0.82, 0.72]
};
for (const [, , voxel2, , hex] of woolVoxelColors)
  voxelColors[voxel2] = [0, 2, 4].map((offset) => parseInt(hex.slice(offset + 1, offset + 3), 16) / 255);
var nonSolid = /* @__PURE__ */ new Set([
  Voxel.Air,
  Voxel.Water,
  Voxel.Lava,
  Voxel.Fire,
  Voxel.Sapling,
  Voxel.TallGrass,
  Voxel.Flower,
  Voxel.Mushroom,
  Voxel.SugarCane,
  Voxel.Rail,
  Voxel.PoweredRail,
  Voxel.DetectorRail,
  Voxel.Ladder,
  Voxel.Torch,
  Voxel.Sign,
  Voxel.DeadBush,
  Voxel.RedFlower,
  Voxel.RedMushroom
]);
var isSolid = (id2) => !nonSolid.has(id2);
var isTargetable = (id2) => id2 !== Voxel.Air && id2 !== Voxel.Water && id2 !== Voxel.Lava && id2 !== Voxel.Fire;
var isRenderable = (id2) => id2 !== Voxel.Air;
var floorDiv2 = (n, d) => Math.floor(n / d);
var chunkKey = (x2, y2, z) => `${x2},${y2},${z}`;
var voxelIndex = (x2, y2, z) => x2 + CHUNK_SIZE * (z + CHUNK_SIZE * y2);
function faceMaterialFor(id2, axis, positive) {
  if (id2 === Voxel.Grass)
    return axis === 1 ? positive ? FaceMaterial.GrassTop : FaceMaterial.Dirt : FaceMaterial.GrassSide;
  if (id2 === Voxel.Wood) return axis === 1 ? FaceMaterial.WoodEnd : FaceMaterial.WoodSide;
  const woolMaterial = woolFaceMaterialForVoxel[id2];
  if (woolMaterial !== void 0) return woolMaterial;
  return {
    [Voxel.Dirt]: FaceMaterial.Dirt,
    [Voxel.Stone]: FaceMaterial.Stone,
    [Voxel.Leaves]: FaceMaterial.Leaves,
    [Voxel.Sand]: FaceMaterial.Sand,
    [Voxel.Snow]: FaceMaterial.Snow,
    [Voxel.Water]: FaceMaterial.Water,
    [Voxel.Glowstone]: FaceMaterial.Glowstone,
    [Voxel.Lantern]: FaceMaterial.LanternFrame,
    [Voxel.Workbench]: FaceMaterial.Workbench,
    [Voxel.Chest]: FaceMaterial.Chest,
    [Voxel.Furnace]: FaceMaterial.Furnace,
    [Voxel.CoalOre]: FaceMaterial.CoalOre,
    [Voxel.IronOre]: FaceMaterial.IronOre,
    [Voxel.Planks]: FaceMaterial.Planks,
    [Voxel.Cobblestone]: FaceMaterial.Cobblestone,
    [Voxel.Glass]: FaceMaterial.Glass,
    [Voxel.DiamondBlock]: FaceMaterial.DiamondBlock,
    [Voxel.GoldBlock]: FaceMaterial.GoldBlock,
    [Voxel.IronBlock]: FaceMaterial.IronBlock,
    [Voxel.DiamondOre]: FaceMaterial.DiamondOre,
    [Voxel.GoldOre]: FaceMaterial.GoldOre,
    [Voxel.Sandstone]: FaceMaterial.Sandstone,
    [Voxel.StoneBricks]: FaceMaterial.StoneBricks,
    [Voxel.Farmland]: FaceMaterial.Farmland,
    [Voxel.Lava]: FaceMaterial.Lava,
    [Voxel.Obsidian]: FaceMaterial.Obsidian,
    [Voxel.Fire]: FaceMaterial.Fire,
    [Voxel.Tnt]: FaceMaterial.Tnt,
    [Voxel.Sapling]: FaceMaterial.Sapling,
    [Voxel.TallGrass]: FaceMaterial.TallGrass,
    [Voxel.Flower]: FaceMaterial.Flower,
    [Voxel.Mushroom]: FaceMaterial.Mushroom,
    [Voxel.SugarCane]: FaceMaterial.SugarCane,
    [Voxel.Cactus]: FaceMaterial.Cactus,
    [Voxel.Spawner]: FaceMaterial.Spawner,
    [Voxel.DungeonChest]: FaceMaterial.DungeonChest,
    [Voxel.Rail]: FaceMaterial.Rail,
    [Voxel.PoweredRail]: FaceMaterial.PoweredRail,
    [Voxel.DetectorRail]: FaceMaterial.DetectorRail,
    [Voxel.Bedrock]: FaceMaterial.Bedrock,
    [Voxel.Gravel]: FaceMaterial.Gravel,
    [Voxel.LapisOre]: FaceMaterial.LapisOre,
    [Voxel.Clay]: FaceMaterial.Clay,
    [Voxel.Ice]: FaceMaterial.Ice,
    [Voxel.SnowBlock]: FaceMaterial.SnowBlock,
    [Voxel.LapisBlock]: FaceMaterial.LapisBlock,
    [Voxel.Slab]: FaceMaterial.Slab,
    [Voxel.WoodStairs]: FaceMaterial.WoodStairs,
    [Voxel.CobblestoneStairs]: FaceMaterial.CobblestoneStairs,
    [Voxel.WoodenDoor]: FaceMaterial.WoodenDoor,
    [Voxel.Ladder]: FaceMaterial.Ladder,
    [Voxel.Torch]: FaceMaterial.Torch,
    [Voxel.Bed]: FaceMaterial.Bed,
    [Voxel.Sign]: FaceMaterial.Sign,
    [Voxel.Fence]: FaceMaterial.Fence,
    [Voxel.Cake]: FaceMaterial.Cake,
    [Voxel.DeadBush]: FaceMaterial.DeadBush,
    [Voxel.Wool]: FaceMaterial.Wool,
    [Voxel.RedFlower]: FaceMaterial.RedFlower,
    [Voxel.RedMushroom]: FaceMaterial.RedMushroom,
    [Voxel.Bricks]: FaceMaterial.Bricks,
    [Voxel.Bookshelf]: FaceMaterial.Bookshelf,
    [Voxel.MossyCobblestone]: FaceMaterial.MossyCobblestone,
    [Voxel.NoteBlock]: FaceMaterial.NoteBlock,
    [Voxel.Jukebox]: FaceMaterial.Jukebox,
    [Voxel.Pumpkin]: FaceMaterial.Pumpkin,
    [Voxel.JackOLantern]: FaceMaterial.JackOLantern,
    [Voxel.Trapdoor]: FaceMaterial.Trapdoor,
    [Voxel.LitFurnace]: FaceMaterial.LitFurnace,
    [Voxel.RedstoneOre]: FaceMaterial.RedstoneOre,
    [Voxel.LitRedstoneOre]: FaceMaterial.LitRedstoneOre
  }[id2];
}
function hash22(seed, x2, z) {
  let h = (seed ^ Math.imul(x2, 374761393) ^ Math.imul(z, 668265263)) >>> 0;
  h = Math.imul(h ^ h >>> 13, 1274126177) >>> 0;
  return ((h ^ h >>> 16) >>> 0) / 4294967296;
}
function baseVoxel(seed, x2, y2, z, context = macroAt(seed, x2, z, GENERATOR_VERSION), queryMacro = (qx, qz) => macroAt(seed, qx, qz, GENERATOR_VERSION), generatorVersion = GENERATOR_VERSION) {
  const h = context.terrainHeight;
  const kind = context.biome;
  const dungeon = dungeonFor(seed, x2, z, generatorVersion);
  if (dungeon) {
    const generated = dungeonVoxel(dungeon, x2, y2, z);
    if (generated !== null) return geologyVoxel(seed, x2, y2, z, context, generated, generatorVersion);
  }
  if (context.hydrology.water && context.hydrology.waterLevel !== null && y2 > h && y2 <= context.hydrology.waterLevel)
    return geologyVoxel(seed, x2, y2, z, context, Voxel.Water, generatorVersion);
  if (y2 <= h) {
    if (y2 === h) {
      const surface = kind === "dry" ? Voxel.Sand : kind === "cold" ? Voxel.Snow : kind === "mountain" ? Voxel.Stone : Voxel.Grass;
      return geologyVoxel(
        seed,
        x2,
        y2,
        z,
        context,
        oreVoxel(seed, x2, y2, z, h, surface, generatorVersion),
        generatorVersion
      );
    }
    const underground = y2 > h - 4 ? kind === "dry" ? Voxel.Sand : kind === "mountain" ? Voxel.Stone : Voxel.Dirt : Voxel.Stone;
    const generated = caveAir(seed, x2, y2, z, h, generatorVersion) ? Voxel.Air : oreVoxel(seed, x2, y2, z, h, underground, generatorVersion);
    return geologyVoxel(seed, x2, y2, z, context, generated, generatorVersion);
  }
  for (let tx = x2 - 3; tx <= x2 + 3; tx += 1)
    for (let tz = z - 3; tz <= z + 3; tz += 1) {
      const treeContext = queryMacro(tx, tz);
      if (!isTreeOriginContext(treeContext, hash22(seed ^ 17583, tx, tz), generatorVersion)) continue;
      const th = treeContext.terrainHeight;
      const dx = Math.abs(x2 - tx), dz = Math.abs(z - tz);
      const treeVoxel = treeVoxelAtOffset(dx, y2, dz, th, generatorVersion);
      if (treeVoxel !== null) return treeVoxel;
    }
  if (generatorVersion >= 7) {
    const vegetation = vegetationAt(seed, x2, y2, z, context, generatorVersion);
    if (vegetation !== null) return vegetation;
  }
  return Voxel.Air;
}

// packages/stdlib/src/server/gameplay/item-instance.ts
var isRecord = (value) => typeof value === "object" && value !== null && !Array.isArray(value);
var hasOnlyKeys = (value, allowed) => {
  const allowedKeys = new Set(allowed);
  return Object.keys(value).every((key2) => allowedKeys.has(key2));
};
var cloneInstance = (instance) => Object.freeze({ durability: instance.durability });
function cloneItemStack(stack2) {
  return {
    itemId: stack2.itemId,
    count: stack2.count,
    ...stack2.instance ? { instance: cloneInstance(stack2.instance) } : {}
  };
}
function sameItemStackIdentity(left, right) {
  if (left.itemId !== right.itemId) return false;
  if (!left.instance || !right.instance) return left.instance === right.instance;
  return left.instance.durability === right.instance.durability;
}
function normalizeItemStack(items, value, options = {}) {
  if (!isRecord(value) || !hasOnlyKeys(value, ["itemId", "count", "instance"]))
    throw new TypeError("Item stack shape is invalid.");
  if (typeof value.itemId !== "string") throw new TypeError("Item stack identity is invalid.");
  const definition2 = items.require(value.itemId);
  if (!Number.isSafeInteger(value.count) || value.count <= 0)
    throw new TypeError("Item stack count must be a positive safe integer.");
  const count = value.count;
  if (!definition2.durability) {
    if (value.instance !== void 0) throw new TypeError(`Item ${definition2.id} does not accept instance state.`);
    return { itemId: definition2.id, count };
  }
  if (count !== 1) throw new TypeError(`Durable item stack count must be one: ${definition2.id}`);
  if (value.instance === void 0) {
    if (options.migrateLegacyDurability !== "initialize-at-max")
      throw new TypeError(`Item ${definition2.id} requires durability instance state.`);
    return {
      itemId: definition2.id,
      count,
      instance: cloneInstance({ durability: definition2.durability.max })
    };
  }
  if (!isRecord(value.instance) || !hasOnlyKeys(value.instance, ["durability"]))
    throw new TypeError(`Item durability instance state is invalid: ${definition2.id}`);
  if (!Number.isSafeInteger(value.instance.durability) || value.instance.durability <= 0 || value.instance.durability > definition2.durability.max)
    throw new TypeError(`Item durability is invalid: ${definition2.id}`);
  return {
    itemId: definition2.id,
    count,
    instance: cloneInstance({ durability: value.instance.durability })
  };
}

// packages/stdlib/src/server/gameplay/item-registry.ts
var ItemIds = Object.freeze({
  DirtBlock: "dirt-block",
  StoneBlock: "stone-block",
  WoodBlock: "wood-block",
  SandBlock: "sand-block",
  Berry: "berry",
  Plank: "plank",
  Workbench: "workbench",
  Chest: "chest",
  Furnace: "furnace",
  Coal: "coal",
  RawIron: "raw-iron",
  IronIngot: "iron-ingot",
  WoodPickaxe: "wood-pickaxe",
  IronPickaxe: "iron-pickaxe",
  WoodAxe: "wood-axe",
  StonePickaxe: "stone-pickaxe",
  GlowstoneBlock: "glowstone-block",
  Lantern: "lantern",
  WoodSword: "wood-sword"
});
var ITEM_IDENTITY = /^[a-z0-9][a-z0-9._-]*(?::[a-z0-9][a-z0-9._/-]*)?$/;
var isItemId = (value) => typeof value === "string" && ITEM_IDENTITY.test(value);
var defineItem = (input) => {
  if (!isItemId(input.id) || !input.name.trim()) throw new TypeError(`Item identity is invalid: ${String(input.id)}`);
  if (!["block", "resource", "food", "tool", "armor"].includes(input.itemType))
    throw new TypeError(`Item type is invalid: ${input.id}`);
  if (!Number.isSafeInteger(input.stackLimit) || input.stackLimit <= 0)
    throw new TypeError(`Item stack limit is invalid: ${input.id}`);
  if (input.durability !== void 0) {
    if (typeof input.durability !== "object" || input.durability === null || Array.isArray(input.durability) || Object.keys(input.durability).length !== 1 || !Object.hasOwn(input.durability, "max") || input.itemType !== "tool" && input.itemType !== "armor" || input.stackLimit !== 1 || !Number.isSafeInteger(input.durability.max) || input.durability.max <= 0)
      throw new TypeError(`Item durability definition is invalid: ${input.id}`);
  }
  const seen = /* @__PURE__ */ new Set();
  const capabilities = input.capabilities.map((source) => {
    if (!["place", "consume", "mine", "melee", "till", "armor", "ranged", "fluid-container"].includes(source.type))
      throw new TypeError(`Item capability is invalid: ${input.id}`);
    if (seen.has(source.type)) throw new TypeError(`Duplicate ${source.type} capability: ${input.id}`);
    seen.add(source.type);
    if (source.type === "place" && (!Number.isSafeInteger(source.voxel) || source.voxel <= Voxel.Air))
      throw new TypeError(`Place capability is invalid: ${input.id}`);
    if (source.type === "consume") {
      const amounts = [source.hungerRestore, source.healthRestore].filter((value) => value !== void 0);
      if (!amounts.length || amounts.some((value) => !Number.isFinite(value) || value <= 0))
        throw new TypeError(`Consume capability is invalid: ${input.id}`);
    }
    if (source.type === "mine" && source.tool !== "axe" && source.tool !== "pickaxe" && source.tool !== "shovel")
      throw new TypeError(`Mine capability is invalid: ${input.id}`);
    if (source.type === "mine" && (!Number.isFinite(source.multiplier) || source.multiplier <= 1 || source.tier !== void 0 && (!Number.isSafeInteger(source.tier) || source.tier < 0)))
      throw new TypeError(`Mine capability is invalid: ${input.id}`);
    if (source.type === "melee" && !source.definitionId.trim())
      throw new TypeError(`Melee capability is invalid: ${input.id}`);
    if (source.type === "armor" && (!["helmet", "chestplate", "leggings", "boots"].includes(source.slot) || !Number.isSafeInteger(source.points) || source.points <= 0))
      throw new TypeError(`Armor capability is invalid: ${input.id}`);
    if (source.type === "ranged" && (!isItemId(source.ammunitionItemId) || !Number.isFinite(source.damage) || source.damage <= 0 || !Number.isFinite(source.speed) || source.speed <= 0 || !Number.isFinite(source.lifetimeSeconds) || source.lifetimeSeconds <= 0))
      throw new TypeError("Ranged capability is invalid: " + input.id);
    if (source.type === "fluid-container" && !["empty", "water", "lava"].includes(source.fluid))
      throw new TypeError("Fluid container capability is invalid: " + input.id);
    return Object.freeze({ ...source });
  });
  const place = capabilities.find((value) => value.type === "place");
  const consume = capabilities.find((value) => value.type === "consume");
  const mine = capabilities.find((value) => value.type === "mine");
  return Object.freeze({
    ...input,
    ...input.durability ? { durability: Object.freeze({ max: input.durability.max }) } : {},
    capabilities: Object.freeze(capabilities),
    ...place ? { placesVoxel: place.voxel } : {},
    ...consume ? { hungerRestore: consume.hungerRestore } : {},
    ...mine ? { toolKind: mine.tool } : {}
  });
};
function createItemDefinitionRegistry(inputs, meleeDefinitionExists) {
  const registered = /* @__PURE__ */ new Map();
  for (const input of inputs) {
    if (registered.has(input.id)) throw new TypeError(`Duplicate item definition: ${input.id}`);
    const definition2 = defineItem(input);
    const melee = definition2.capabilities.find(
      (capability2) => capability2.type === "melee"
    );
    if (melee && (!meleeDefinitionExists || !meleeDefinitionExists(melee.definitionId)))
      throw new TypeError(`Item ${input.id} references unknown melee definition: ${melee.definitionId}`);
    registered.set(input.id, definition2);
  }
  for (const definition2 of registered.values()) {
    const ranged = definition2.capabilities.find(
      (candidate2) => candidate2.type === "ranged"
    );
    if (ranged && !registered.has(ranged.ammunitionItemId))
      throw new TypeError("Item " + definition2.id + " references unknown ammunition: " + ranged.ammunitionItemId);
  }
  const values = Object.freeze([...registered.values()]);
  const require2 = (id2) => {
    const definition2 = registered.get(id2);
    if (!definition2) throw new RangeError(`Unknown item: ${String(id2)}`);
    return definition2;
  };
  const capability = (id2, type) => require2(id2).capabilities.find((candidate2) => candidate2.type === type);
  const registry = Object.freeze({
    get: (id2) => registered.get(id2),
    require: require2,
    has: (id2) => registered.has(id2),
    list: () => values,
    capability,
    normalizeStack: (value, options) => normalizeItemStack(registry, value, options),
    assertStack: (stack2) => {
      normalizeItemStack(registry, stack2);
    }
  });
  return registry;
}
var defaultItemDefinitionRegistry = createItemDefinitionRegistry([]);

// packages/stdlib/src/server/gameplay/inventory.ts
var cloneSlot = (slot) => slot ? cloneItemStack(slot) : null;
var Inventory = class {
  constructor(capacity3, initial, items = defaultItemDefinitionRegistry) {
    this.capacity = capacity3;
    this.items = items;
    if (!Number.isInteger(capacity3) || capacity3 <= 0)
      throw new TypeError("Inventory capacity must be a positive integer.");
    if (initial && initial.length !== capacity3) throw new TypeError("Inventory snapshot capacity does not match.");
    this.slots = initial ? initial.map((slot) => this.validateSlot(slot)) : Array.from({ length: capacity3 }, () => null);
  }
  capacity;
  items;
  slots;
  snapshot() {
    return this.slots.map(cloneSlot);
  }
  slot(index) {
    return cloneSlot(this.slots[index] ?? null);
  }
  contains(stack2) {
    const normalized = normalizeItemStack(this.items, stack2);
    return this.slots.reduce(
      (count, slot) => count + (slot && sameItemStackIdentity(slot, normalized) ? slot.count : 0),
      0
    ) >= normalized.count;
  }
  containsAmount(itemId, count) {
    this.items.require(itemId);
    if (!Number.isSafeInteger(count) || count <= 0)
      throw new TypeError("Item amount count must be a positive safe integer.");
    return this.slots.reduce((total, slot) => total + (slot?.itemId === itemId ? slot.count : 0), 0) >= count;
  }
  canAdd(stack2) {
    const candidate2 = this.snapshot();
    return this.addTo(candidate2, stack2);
  }
  add(stack2) {
    const candidate2 = this.snapshot();
    if (!this.addTo(candidate2, stack2)) return false;
    this.slots = candidate2;
    return true;
  }
  remove(stack2) {
    const normalized = normalizeItemStack(this.items, stack2);
    if (!this.contains(normalized)) return false;
    const candidate2 = this.snapshot();
    let remaining = normalized.count;
    for (let index = 0; index < candidate2.length && remaining > 0; index += 1) {
      const slot = candidate2[index];
      if (!slot || !sameItemStackIdentity(slot, normalized)) continue;
      const removed = Math.min(slot.count, remaining);
      slot.count -= removed;
      remaining -= removed;
      if (slot.count === 0) candidate2[index] = null;
    }
    this.slots = candidate2;
    return true;
  }
  split(sourceIndex, count, targetIndex) {
    if (!this.validIndex(sourceIndex) || !this.validIndex(targetIndex) || sourceIndex === targetIndex) return false;
    if (!Number.isInteger(count) || count <= 0) return false;
    const candidate2 = this.snapshot();
    const source = candidate2[sourceIndex];
    if (!source || source.count <= count) return false;
    const target = candidate2[targetIndex];
    const limit = this.items.require(source.itemId).stackLimit;
    if (target && (!sameItemStackIdentity(target, source) || target.count + count > limit)) return false;
    source.count -= count;
    candidate2[targetIndex] = target ? { ...cloneItemStack(target), count: target.count + count } : { ...cloneItemStack(source), count };
    this.slots = candidate2;
    return true;
  }
  moveStack(sourceIndex, targetIndex) {
    if (!this.validIndex(sourceIndex) || !this.validIndex(targetIndex) || sourceIndex === targetIndex) return false;
    const candidate2 = this.snapshot();
    const source = candidate2[sourceIndex];
    const target = candidate2[targetIndex];
    if (!source) return false;
    if (target && sameItemStackIdentity(target, source)) {
      const moved = Math.min(source.count, this.items.require(source.itemId).stackLimit - target.count);
      if (moved <= 0) return false;
      target.count += moved;
      source.count -= moved;
      if (!source.count) candidate2[sourceIndex] = null;
    } else {
      candidate2[targetIndex] = source;
      candidate2[sourceIndex] = target;
    }
    this.slots = candidate2;
    return true;
  }
  removeFromSlot(index, count) {
    if (!this.validIndex(index) || !Number.isInteger(count) || count <= 0) return false;
    const source = this.slots[index];
    if (!source || source.count < count) return false;
    const candidate2 = this.snapshot();
    candidate2[index] = source.count === count ? null : { ...cloneItemStack(source), count: source.count - count };
    this.slots = candidate2;
    return true;
  }
  replace(snapshot) {
    if (snapshot.length !== this.capacity) throw new TypeError("Inventory snapshot capacity does not match.");
    this.slots = snapshot.map((slot) => this.validateSlot(slot));
  }
  clear() {
    const stacks = this.slots.filter((slot) => slot !== null).map(cloneItemStack);
    this.slots = Array.from({ length: this.capacity }, () => null);
    return stacks;
  }
  addTo(candidate2, stack2) {
    const normalized = normalizeItemStack(this.items, stack2);
    const limit = this.items.require(normalized.itemId).stackLimit;
    let remaining = normalized.count;
    for (const slot of candidate2) {
      if (!slot || !sameItemStackIdentity(slot, normalized) || slot.count >= limit) continue;
      const added = Math.min(limit - slot.count, remaining);
      slot.count += added;
      remaining -= added;
      if (remaining === 0) return true;
    }
    for (let index = 0; index < candidate2.length && remaining > 0; index += 1) {
      if (candidate2[index]) continue;
      const added = Math.min(limit, remaining);
      candidate2[index] = { ...cloneItemStack(normalized), count: added };
      remaining -= added;
    }
    return remaining === 0;
  }
  validateSlot(slot) {
    if (slot === null) return null;
    const normalized = normalizeItemStack(this.items, slot);
    if (normalized.count > this.items.require(normalized.itemId).stackLimit)
      throw new TypeError(`Item stack exceeds its limit: ${normalized.itemId}`);
    return normalized;
  }
  validIndex(index) {
    return Number.isInteger(index) && index >= 0 && index < this.capacity;
  }
};

// packages/stdlib/src/server/composition/execution-origin.ts
var MAX_IDENTITY_LENGTH = 256;
var isPlainRecord = (value) => {
  if (typeof value !== "object" || value === null || Array.isArray(value)) return false;
  const prototype = Object.getPrototypeOf(value);
  return prototype === Object.prototype || prototype === null;
};
var hasExactKeys = (value, keys) => {
  if (Reflect.ownKeys(value).length !== keys.length) return false;
  return keys.every((key2) => {
    const descriptor = Object.getOwnPropertyDescriptor(value, key2);
    return Boolean(descriptor?.enumerable && "value" in descriptor);
  });
};
var boundedIdentity = (value, label) => {
  if (typeof value !== "string" || value.length === 0 || value.length > MAX_IDENTITY_LENGTH || value.trim() !== value)
    throw new TypeError(`${label} is invalid.`);
  return value;
};
function validateDurableExecutionOrigin(value) {
  if (!isPlainRecord(value) || !hasExactKeys(value, ["version", "principalSubject", "provenance", "originalActor"]))
    throw new TypeError("Durable execution origin shape is invalid.");
  if (value.version !== 1) throw new TypeError("Durable execution origin version is invalid.");
  const principalSubject = boundedIdentity(value.principalSubject, "Durable execution principal subject");
  if (!isPlainRecord(value.provenance) || !hasExactKeys(value.provenance, ["packId", "moduleId"]))
    throw new TypeError("Durable execution provenance is invalid.");
  const packId = boundedIdentity(value.provenance.packId, "Durable execution pack identity");
  const moduleId = boundedIdentity(value.provenance.moduleId, "Durable execution module identity");
  if (!isPlainRecord(value.originalActor) || !hasExactKeys(value.originalActor, ["entityId", "lifetime"]))
    throw new TypeError("Durable execution original actor is invalid.");
  const entityId = boundedIdentity(value.originalActor.entityId, "Durable execution actor identity");
  if (!Number.isSafeInteger(value.originalActor.lifetime) || value.originalActor.lifetime < 0)
    throw new TypeError("Durable execution actor lifetime is invalid.");
  return Object.freeze({
    version: 1,
    principalSubject,
    provenance: Object.freeze({ packId, moduleId }),
    originalActor: Object.freeze({ entityId, lifetime: value.originalActor.lifetime })
  });
}

// packages/stdlib/src/server/gameplay/modules/inventory-pointer-contract.ts
var MAX_SLOT = 63;
var MAX_TARGETS = 64;
var isRecord2 = (value) => !!value && typeof value === "object" && !Array.isArray(value) && [Object.prototype, null].includes(Object.getPrototypeOf(value));
var integer = (value, minimum = 0, maximum = Number.MAX_SAFE_INTEGER) => typeof value === "number" && Number.isSafeInteger(value) && value >= minimum && value <= maximum;
function reference(raw, label) {
  if (!isRecord2(raw) || Object.keys(raw).some((key2) => !["entityId", "epoch", "lifetime"].includes(key2)))
    throw new TypeError(`${label} reference is invalid.`);
  if (typeof raw.entityId !== "string" || !raw.entityId.trim() || raw.entityId !== raw.entityId.trim() || raw.entityId.length > 256 || !integer(raw.epoch, 1) || !integer(raw.lifetime, 1))
    throw new TypeError(`${label} reference is invalid.`);
  return Object.freeze({ entityId: raw.entityId, epoch: raw.epoch, lifetime: raw.lifetime });
}
function frozenStack(stack2) {
  return stack2 ? Object.freeze({
    ...stack2,
    ...stack2.instance ? { instance: Object.freeze({ ...stack2.instance }) } : {}
  }) : null;
}
function emptyInventoryCursor() {
  return Object.freeze({
    version: 1,
    revision: 0,
    stack: null,
    origin: null,
    craftingGrid: Object.freeze([null, null, null, null])
  });
}
function validateInventoryCursor(raw, items) {
  if (raw === void 0) return emptyInventoryCursor();
  if (!isRecord2(raw) || Object.keys(raw).some((key2) => !["version", "revision", "stack", "origin", "craftingGrid"].includes(key2)) || Object.keys(raw).length !== 4 && Object.keys(raw).length !== 5 || raw.version !== 1 || !integer(raw.revision))
    throw new TypeError("Actor inventory cursor snapshot is invalid.");
  const stack2 = raw.stack === null ? null : frozenStack(items.normalizeStack(raw.stack));
  if (stack2 && stack2.count > items.require(stack2.itemId).stackLimit)
    throw new TypeError("Actor inventory cursor exceeds its stack limit.");
  let origin;
  if (raw.origin === null) origin = null;
  else {
    if (!isRecord2(raw.origin) || !integer(raw.origin.slot, 0, MAX_SLOT))
      throw new TypeError("Actor inventory cursor origin is invalid.");
    if ((raw.origin.kind === "inventory" || raw.origin.kind === "crafting") && Object.keys(raw.origin).every((key2) => ["kind", "slot"].includes(key2)))
      origin = Object.freeze({ kind: raw.origin.kind, slot: raw.origin.slot });
    else if (raw.origin.kind === "station" && Object.keys(raw.origin).every((key2) => ["kind", "reference", "slot"].includes(key2)))
      origin = Object.freeze({
        kind: "station",
        reference: reference(raw.origin.reference, "Cursor station"),
        slot: raw.origin.slot
      });
    else throw new TypeError("Actor inventory cursor origin is invalid.");
  }
  if (stack2 === null && origin !== null) throw new TypeError("An empty inventory cursor cannot retain an origin.");
  if (raw.craftingGrid !== void 0 && !Array.isArray(raw.craftingGrid))
    throw new TypeError("Actor personal crafting grid is invalid.");
  const craftingGrid = new Inventory(
    4,
    raw.craftingGrid === void 0 ? void 0 : raw.craftingGrid,
    items
  ).snapshot().map(frozenStack);
  if (origin?.kind === "crafting" && origin.slot >= craftingGrid.length)
    throw new TypeError("Actor inventory cursor origin is invalid.");
  return Object.freeze({
    version: 1,
    revision: raw.revision,
    stack: stack2,
    origin,
    craftingGrid: Object.freeze(craftingGrid)
  });
}
function slotRef(raw) {
  if (!isRecord2(raw) || Object.keys(raw).some((key2) => !["kind", "slot"].includes(key2)) || raw.kind !== "inventory" && raw.kind !== "crafting" && raw.kind !== "station" || !integer(raw.slot, 0, MAX_SLOT))
    throw new TypeError("Inventory pointer slot reference is invalid.");
  return Object.freeze({ kind: raw.kind, slot: raw.slot });
}
function button(value) {
  if (value !== 0 && value !== 2) throw new TypeError("Inventory pointer button is invalid.");
  return value;
}
function validateInventoryPointerInput(raw) {
  if (!isRecord2(raw)) throw new TypeError("Inventory pointer input is invalid.");
  if (Object.keys(raw).some((key2) => !["actor", "expectedInventoryRevision", "station", "command"].includes(key2)))
    throw new TypeError("Inventory pointer input contains unknown fields.");
  const actor = reference(raw.actor, "Inventory pointer actor");
  if (!integer(raw.expectedInventoryRevision)) throw new TypeError("Inventory pointer revision is invalid.");
  let station;
  if (raw.station !== void 0) {
    if (!isRecord2(raw.station) || Object.keys(raw.station).some((key2) => !["reference", "expectedRevision"].includes(key2)) || !integer(raw.station.expectedRevision))
      throw new TypeError("Inventory pointer station is invalid.");
    station = Object.freeze({
      reference: reference(raw.station.reference, "Inventory pointer station"),
      expectedRevision: raw.station.expectedRevision
    });
  }
  if (!isRecord2(raw.command) || typeof raw.command.kind !== "string")
    throw new TypeError("Inventory pointer command is invalid.");
  const source = raw.command;
  let command;
  switch (source.kind) {
    case "click":
      if (Object.keys(source).some((key2) => !["kind", "slot", "button"].includes(key2)))
        throw new TypeError("Inventory pointer click is invalid.");
      command = Object.freeze({ kind: source.kind, slot: slotRef(source.slot), button: button(source.button) });
      break;
    case "distribute":
      if (Object.keys(source).some((key2) => !["kind", "targets", "button"].includes(key2)) || !Array.isArray(source.targets) || source.targets.length < 1 || source.targets.length > MAX_TARGETS)
        throw new TypeError("Inventory pointer distribution is invalid.");
      command = Object.freeze({
        kind: source.kind,
        targets: Object.freeze(source.targets.map(slotRef)),
        button: button(source.button)
      });
      break;
    case "quick-move":
    case "collect":
      if (Object.keys(source).some((key2) => !["kind", "slot"].includes(key2)))
        throw new TypeError("Inventory pointer slot command is invalid.");
      command = Object.freeze({ kind: source.kind, slot: slotRef(source.slot) });
      break;
    case "hotbar":
      if (Object.keys(source).some((key2) => !["kind", "slot", "hotbarSlot"].includes(key2)) || !integer(source.hotbarSlot, 0, 8))
        throw new TypeError("Inventory pointer hotbar command is invalid.");
      command = Object.freeze({ kind: source.kind, slot: slotRef(source.slot), hotbarSlot: source.hotbarSlot });
      break;
    case "craft":
      if (Object.keys(source).some((key2) => !["kind", "batch"].includes(key2)) || typeof source.batch !== "boolean")
        throw new TypeError("Inventory pointer craft command is invalid.");
      command = Object.freeze({ kind: source.kind, batch: source.batch });
      break;
    case "close":
      if (Object.keys(source).length !== 1) throw new TypeError("Inventory pointer close command is invalid.");
      command = Object.freeze({ kind: source.kind });
      break;
    case "drop":
      if (Object.keys(source).some((key2) => !["kind", "button"].includes(key2)))
        throw new TypeError("Inventory pointer drop command is invalid.");
      command = Object.freeze({ kind: source.kind, button: button(source.button) });
      break;
    default:
      throw new TypeError("Inventory pointer command kind is invalid.");
  }
  return Object.freeze({
    actor,
    expectedInventoryRevision: raw.expectedInventoryRevision,
    ...station ? { station } : {},
    command
  });
}

// packages/stdlib/src/runtime/behavior-control-protocol.ts
var BEHAVIOR_SCHEMA_VERSION = 1;
var BEHAVIOR_MAX_NODES = 64;
var BEHAVIOR_MAX_DEPTH = 12;
var BEHAVIOR_MAX_BYTES = 32 * 1024;
var BEHAVIOR_MAX_CAPABILITIES = 256;
var BEHAVIOR_MAX_CAPABILITY_STATE_BYTES = 8 * 1024;
var BEHAVIOR_MAX_REQUIRED_OPERATIONS = 16;
var BEHAVIOR_MAX_DESCRIPTOR_TEXT_LENGTH = 160;
var BEHAVIOR_MAX_OPERATION_ID_LENGTH = BEHAVIOR_MAX_DESCRIPTOR_TEXT_LENGTH;
var BEHAVIOR_MAX_ARGUMENT_VALUES = 128;
var BEHAVIOR_MAX_CATALOG_BYTES = 32 * 1024;

// packages/stdlib/src/runtime/behavior-json.ts
var behaviorUtf8Bytes = (text) => {
  let total = 0;
  for (const character2 of text) {
    const code = character2.codePointAt(0);
    total += code <= 127 ? 1 : code <= 2047 ? 2 : code <= 65535 ? 3 : 4;
  }
  return total;
};
var behaviorJsonBytes = (value) => behaviorUtf8Bytes(JSON.stringify(value));
function boundedBehaviorJsonArrayBytes(values, maximum) {
  let total = 2;
  for (let index = 0; index < values.length; index++) {
    total += (index === 0 ? 0 : 1) + behaviorJsonBytes(values[index]);
    if (total > maximum) return total;
  }
  return total;
}

// packages/stdlib/src/runtime/behavior-capability-descriptor.ts
var IDENTIFIER = /^[a-zA-Z0-9][a-zA-Z0-9._:-]{0,127}$/;
var NAMESPACE_ID = /^[a-z0-9][a-z0-9._-]*:[a-z0-9][a-z0-9._/-]*$/;
var EXACT_VERSION = /^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:-[0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*)?(?:\+[0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*)?$/;
var object = (value) => value !== null && typeof value === "object" && !Array.isArray(value);
var onlyKeys = (value, keys) => Object.keys(value).every((key2) => keys.includes(key2));
var boundedText = (value) => typeof value === "string" && value.length > 0 && value.length <= BEHAVIOR_MAX_DESCRIPTOR_TEXT_LENGTH;
var exactVersion = (value) => boundedText(value) && EXACT_VERSION.test(value);
function behaviorArgumentRuleIssue(value) {
  if (!object(value) || !onlyKeys(value, ["type", "required", "minimum", "maximum", "integer", "values"]) || typeof value.type !== "string" || !["number", "string", "boolean", "position", "entity-reference"].includes(value.type) || value.required !== void 0 && typeof value.required !== "boolean" || value.integer !== void 0 && typeof value.integer !== "boolean")
    return "schema";
  if (value.minimum !== void 0 && (!Number.isFinite(value.minimum) || value.type === "boolean")) return "minimum";
  if (value.maximum !== void 0 && (!Number.isFinite(value.maximum) || value.type === "boolean")) return "maximum";
  if (value.minimum !== void 0 && value.maximum !== void 0 && Number(value.minimum) > Number(value.maximum))
    return "bounds";
  if (value.values !== void 0 && (value.type !== "string" || !Array.isArray(value.values) || value.values.length === 0 || value.values.length > BEHAVIOR_MAX_ARGUMENT_VALUES || value.values.some((entry) => !boundedText(entry))))
    return "values";
  return null;
}
var isBehaviorArgumentRuleDescriptor = (value) => behaviorArgumentRuleIssue(value) === null;
var validRequiredOperations = (value) => {
  if (!Array.isArray(value) || value.length > BEHAVIOR_MAX_REQUIRED_OPERATIONS) return false;
  const ids = /* @__PURE__ */ new Set();
  return value.every((entry) => {
    if (!object(entry) || !onlyKeys(entry, ["operationId", "authorization"]) || typeof entry.operationId !== "string" || entry.operationId.length > BEHAVIOR_MAX_OPERATION_ID_LENGTH || !NAMESPACE_ID.test(entry.operationId) || entry.authorization !== "self" && entry.authorization !== "any" || ids.has(entry.operationId))
      return false;
    ids.add(entry.operationId);
    return true;
  });
};
function isBehaviorCapabilityDescriptor(value) {
  if (!object(value) || !onlyKeys(value, [
    "id",
    "name",
    "version",
    "provider",
    "kind",
    "description",
    "arguments",
    "requiredOperations",
    "state"
  ]) || typeof value.id !== "string" || !IDENTIFIER.test(value.id) || value.name !== value.id || !exactVersion(value.version) || !object(value.provider) || !onlyKeys(value.provider, ["moduleId", "version"]) || !boundedText(value.provider.moduleId) || !NAMESPACE_ID.test(value.provider.moduleId) || !exactVersion(value.provider.version) || value.kind !== "condition" && value.kind !== "skill" || typeof value.description !== "string" || !value.description.trim() || value.description.length > 512 || !object(value.arguments) || Object.keys(value.arguments).length > 24 || !Object.entries(value.arguments).every(
    ([name, rule]) => IDENTIFIER.test(name) && isBehaviorArgumentRuleDescriptor(rule)
  ) || !validRequiredOperations(value.requiredOperations))
    return false;
  if (value.kind === "condition") return value.requiredOperations.length === 0 && !Object.hasOwn(value, "state");
  return object(value.state) && onlyKeys(value.state, ["version", "maximumBytes"]) && exactVersion(value.state.version) && Number.isSafeInteger(value.state.maximumBytes) && Number(value.state.maximumBytes) >= 2 && Number(value.state.maximumBytes) <= BEHAVIOR_MAX_CAPABILITY_STATE_BYTES;
}
function isBehaviorCapabilityCatalog(value) {
  if (!Array.isArray(value) || value.length > BEHAVIOR_MAX_CAPABILITIES) return false;
  const ids = /* @__PURE__ */ new Set();
  if (!value.every((entry) => {
    if (!isBehaviorCapabilityDescriptor(entry) || ids.has(entry.id)) return false;
    ids.add(entry.id);
    return true;
  }))
    return false;
  try {
    return boundedBehaviorJsonArrayBytes(value, BEHAVIOR_MAX_CATALOG_BYTES) <= BEHAVIOR_MAX_CATALOG_BYTES;
  } catch {
    return false;
  }
}
function assertBehaviorCapabilityDescriptor(value) {
  if (!isBehaviorCapabilityDescriptor(value)) throw new TypeError("Behavior capability descriptor is invalid.");
}

// packages/stdlib/src/server/composition/behavior-capability-validation.ts
var MAX_JSON_DEPTH = 16;
var MAX_JSON_NODES = 2048;
var behaviorObject = (value) => Boolean(value && typeof value === "object" && !Array.isArray(value));
var cloneBehaviorValue = (value) => JSON.parse(JSON.stringify(value));
var freezeBehaviorValue = (value) => {
  if (!value || typeof value !== "object" || Object.isFrozen(value)) return;
  for (const child of Object.values(value)) freezeBehaviorValue(child);
  Object.freeze(value);
};
var frozenBehaviorValue = (value) => {
  const clone = cloneBehaviorValue(value);
  freezeBehaviorValue(clone);
  return clone;
};
function assertBehaviorJson(value, label) {
  const seen = /* @__PURE__ */ new Set();
  let nodes = 0;
  const visit = (entry, depth) => {
    if (++nodes > MAX_JSON_NODES || depth > MAX_JSON_DEPTH)
      throw new TypeError(`${label} must contain bounded JSON data.`);
    if (entry === null || typeof entry === "string" || typeof entry === "boolean") return;
    if (typeof entry === "number") {
      if (!Number.isFinite(entry)) throw new TypeError(`${label} must contain finite JSON numbers.`);
      return;
    }
    if (typeof entry !== "object" || seen.has(entry)) throw new TypeError(`${label} must contain bounded JSON data.`);
    seen.add(entry);
    if (Array.isArray(entry)) entry.forEach((item) => visit(item, depth + 1));
    else if (behaviorObject(entry))
      for (const [key2, item] of Object.entries(entry)) {
        if (!key2 || item === void 0) throw new TypeError(`${label} must contain bounded JSON data.`);
        visit(item, depth + 1);
      }
    else throw new TypeError(`${label} must contain bounded JSON data.`);
    seen.delete(entry);
  };
  visit(value, 0);
}
function validateBehaviorArgumentRule(rule, label) {
  const issue = behaviorArgumentRuleIssue(rule);
  if (!issue) return;
  if (issue === "minimum") throw new TypeError(`${label} minimum is invalid.`);
  if (issue === "maximum") throw new TypeError(`${label} maximum is invalid.`);
  if (issue === "bounds") throw new TypeError(`${label} bounds are invalid.`);
  if (issue === "values") throw new TypeError(`${label} values are invalid.`);
  throw new TypeError(`${label} argument schema is invalid.`);
}
function validateBehaviorArguments(capability, raw) {
  const args = raw === void 0 ? {} : raw;
  if (!behaviorObject(args) || Object.keys(args).length > 24)
    throw new TypeError(`Behavior ${capability.id} arguments are invalid.`);
  for (const key2 of Object.keys(args))
    if (!(key2 in capability.arguments))
      throw new TypeError(`Behavior ${capability.id} argument ${key2} is unsupported.`);
  for (const [key2, rule] of Object.entries(capability.arguments)) {
    const value = args[key2];
    if (value === void 0) {
      if (rule.required) throw new TypeError(`Behavior ${capability.id} argument ${key2} is required.`);
      continue;
    }
    const isPosition = Array.isArray(value) && value.length >= 3 && value.length % 3 === 0 && value.length <= 192 && value.every((entry) => typeof entry === "number" && Number.isFinite(entry));
    const valid = rule.type === "position" ? isPosition : (rule.type === "entity-reference" ? typeof value === "string" : typeof value === rule.type) && (rule.type !== "number" || Number.isFinite(value)) && (!Array.isArray(rule.values) || typeof value === "string" && rule.values.includes(value));
    if (!valid) throw new TypeError(`Behavior ${capability.id} argument ${key2} is invalid.`);
    if (typeof value === "number" && (rule.minimum !== void 0 && value < rule.minimum || rule.maximum !== void 0 && value > rule.maximum || rule.integer === true && !Number.isSafeInteger(value)))
      throw new TypeError(`Behavior ${capability.id} argument ${key2} is out of range.`);
    if (typeof value === "string" && (value.length > 2e3 || rule.minimum !== void 0 && value.length < rule.minimum || rule.maximum !== void 0 && value.length > rule.maximum))
      throw new TypeError(`Behavior ${capability.id} argument ${key2} is out of range.`);
  }
  return frozenBehaviorValue(args);
}

// packages/stdlib/src/server/composition/behavior-capability-admission.ts
function validateBehaviorOperationRequirements(value, capabilityId) {
  if (!Array.isArray(value) || value.length > BEHAVIOR_MAX_REQUIRED_OPERATIONS)
    throw new TypeError(`Behavior ${capabilityId} required operations are invalid.`);
  const ids = /* @__PURE__ */ new Set();
  for (const requirement of value) {
    if (!requirement || typeof requirement !== "object" || typeof requirement.operationId !== "string" || requirement.operationId.length > BEHAVIOR_MAX_OPERATION_ID_LENGTH || !/^[a-z0-9][a-z0-9._-]*:[a-z0-9][a-z0-9._/-]*$/.test(requirement.operationId) || !["self", "any"].includes(requirement.authorization))
      throw new TypeError(`Behavior ${capabilityId} required operation is invalid.`);
    const id2 = requirement.operationId;
    if (ids.has(id2)) throw new TypeError(`Behavior ${capabilityId} required operation is duplicated: ${id2}`);
    ids.add(id2);
  }
}
function snapshotBehaviorOperationRequirements(requirements) {
  return Object.freeze(requirements.map((entry) => Object.freeze({ ...entry })));
}
function assertBehaviorProviderAdmission(definitions3, identity5, capability) {
  const provider = definitions3.module(identity5.moduleId);
  if (!provider) throw new TypeError(`Behavior provider module is missing: ${identity5.moduleId}`);
  for (const requirement of capability.requiredOperations) {
    const operation = definitions3.operation(requirement.operationId);
    if (!operation)
      throw new TypeError(`Behavior ${capability.id} required operation is missing: ${requirement.operationId}`);
    if (operation.executionKind !== "actor")
      throw new TypeError(
        `Behavior ${capability.id} required operation is not actor-executable: ${requirement.operationId}`
      );
    const owner = definitions3.module(operation.moduleId);
    if (!owner?.permissions.some(
      (permission) => permission.resource === operation.resource && permission.operations.includes("execute")
    ))
      throw new TypeError(
        `Behavior ${capability.id} required operation owner has no execute permission: ${requirement.operationId}`
      );
    if (!provider.permissions.some(
      (permission) => permission.resource === operation.resource && permission.operations.includes("execute")
    ))
      throw new TypeError(
        `Behavior ${capability.id} provider has no execute permission for required operation: ${requirement.operationId}`
      );
  }
}

// packages/stdlib/src/server/composition/behavior-capability-dispatch.ts
var BEHAVIOR_PROVIDER_CALLBACK_INVOKE_BUDGET = 128;
var snapshotBehaviorProvider = (definition2) => {
  const base = {
    id: definition2.id,
    version: definition2.version,
    description: definition2.description,
    arguments: frozenBehaviorValue(definition2.arguments)
  };
  if (definition2.kind === "condition")
    return Object.freeze({ ...base, kind: definition2.kind, evaluate: definition2.evaluate });
  return Object.freeze({
    ...base,
    kind: definition2.kind,
    requiredOperations: snapshotBehaviorOperationRequirements(definition2.requiredOperations),
    state: Object.freeze({ ...definition2.state }),
    start: definition2.start,
    continue: definition2.continue,
    ...definition2.cancel ? { cancel: definition2.cancel } : {}
  });
};
function assertBehaviorProviderContext(context) {
  if (!behaviorObject(context) || !behaviorObject(context.actor) || !context.actor.entityId || !Number.isSafeInteger(context.actor.epoch) || !Number.isSafeInteger(context.actor.lifetime) || !Number.isSafeInteger(context.actor.behaviorRevision) || !Number.isSafeInteger(context.actor.activation) || !behaviorObject(context.actorState) || context.actorState.reference.entityId !== context.actor.entityId || context.actorState.reference.epoch !== context.actor.epoch || context.actorState.reference.lifetime !== context.actor.lifetime || !Number.isFinite(context.deltaSeconds) || context.deltaSeconds < 0 || !Number.isFinite(context.elapsedSeconds) || context.elapsedSeconds < 0 || typeof context.invoke !== "function" || typeof context.resolveTarget !== "function" || typeof context.allows !== "function" || !behaviorObject(context.standard))
    throw new TypeError("Behavior provider context is invalid.");
}
function withBehaviorProviderContext(provider, context, standardProviderModuleId, callback) {
  const origin = Object.freeze({
    moduleId: provider.identity.moduleId,
    providerId: provider.descriptor.id,
    providerVersion: provider.descriptor.version
  });
  const permittedTargets = /* @__PURE__ */ new Set();
  let active = true;
  let invokeCount = 0;
  const resolveTarget = (reference3) => {
    if (!active) return null;
    const resolved = context.resolveTarget(reference3);
    if (resolved) permittedTargets.add(resolved.entityId);
    return resolved ? Object.freeze({ ...resolved }) : null;
  };
  const providerContext = Object.freeze({
    actor: context.actor,
    actorState: context.actorState,
    deltaSeconds: context.deltaSeconds,
    elapsedSeconds: context.elapsedSeconds,
    resolveTarget,
    invoke: (request) => {
      if (!active)
        return Object.freeze({
          ok: false,
          code: "BEHAVIOR_CONTEXT_EXPIRED",
          message: "Behavior provider callback context has expired."
        });
      if (invokeCount >= BEHAVIOR_PROVIDER_CALLBACK_INVOKE_BUDGET)
        return Object.freeze({
          ok: false,
          code: "BEHAVIOR_OPERATION_BUDGET_EXHAUSTED",
          message: "Behavior provider callback operation budget is exhausted."
        });
      invokeCount += 1;
      const requirement = provider.definition.kind === "skill" ? provider.definition.requiredOperations.find(({ operationId }) => operationId === request.operationId) : void 0;
      const authorized = requirement?.authorization === "any" || requirement?.authorization === "self" && request.target.kind === "entity" && request.target.entityId === context.actor.entityId;
      if (!authorized)
        return Object.freeze({
          ok: false,
          code: "BEHAVIOR_OPERATION_UNDECLARED",
          message: "Behavior provider did not declare this operation and target scope."
        });
      if (request.target.kind === "entity" && request.target.entityId !== context.actor.entityId && provider.identity.moduleId !== standardProviderModuleId && !permittedTargets.has(request.target.entityId))
        return Object.freeze({
          ok: false,
          code: "BEHAVIOR_TARGET_UNRESOLVED",
          message: "Behavior target is not a current authorized reference."
        });
      return context.invoke(origin, request);
    },
    ...provider.identity.moduleId === standardProviderModuleId ? { __standard: context.standard } : {}
  });
  try {
    return callback(providerContext);
  } finally {
    active = false;
  }
}
function validateBehaviorProviderState(provider, state) {
  if (provider.definition.kind !== "skill") throw new TypeError("Behavior condition has no restorable state.");
  assertBehaviorJson(state, "Behavior state");
  if (behaviorJsonBytes(state) > provider.definition.state.maximumBytes)
    throw new RangeError("Behavior state is too large.");
  if (provider.definition.state.validate?.(state) === false)
    throw new TypeError(`Behavior ${provider.descriptor.id} state is incompatible.`);
}
function normalizeBehaviorProviderResult(provider, raw) {
  if (!behaviorObject(raw) || !["running", "succeeded", "failed", "cancelled"].includes(String(raw.status)))
    throw new TypeError(`Behavior ${provider.descriptor.id} returned an invalid result.`);
  if ("phase" in raw && (typeof raw.phase !== "string" || !raw.phase || raw.phase.length > 128))
    throw new TypeError(`Behavior ${provider.descriptor.id} returned an invalid phase.`);
  if (raw.status === "failed" && (typeof raw.reason !== "string" || !raw.reason || raw.reason.length > 512))
    throw new TypeError(`Behavior ${provider.descriptor.id} returned an invalid failure.`);
  if (raw.status === "running") validateBehaviorProviderState(provider, raw.state);
  else if (raw.status === "succeeded" && raw.result !== void 0) {
    assertBehaviorJson(raw.result, "Behavior result");
    if (behaviorJsonBytes(raw.result) > BEHAVIOR_MAX_CAPABILITY_STATE_BYTES)
      throw new RangeError("Behavior result is too large.");
  }
  return frozenBehaviorValue(raw);
}

// packages/stdlib/src/server/composition/behavior-capability-registry.ts
var BEHAVIOR_REGISTRY_CAPABILITY = "seedlands:behavior-registry";
var STANDARD_BEHAVIOR_PROVIDER_MODULE_ID = "seedlands:behavior-registry-module";
var IDENTIFIER2 = /^[a-zA-Z0-9][a-zA-Z0-9._:-]{0,127}$/;
var NAMESPACE_ID2 = /^[a-z0-9][a-z0-9._-]*:[a-z0-9][a-z0-9._/-]*$/;
var EXACT_VERSION2 = /^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:-[0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*)?(?:\+[0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*)?$/;
var providerKey = (kind, id2) => `${kind}:${id2}`;
function createBehaviorCapabilityRegistry() {
  const providers = /* @__PURE__ */ new Map();
  const capabilityIds = /* @__PURE__ */ new Set();
  let frozen = false;
  let catalog = Object.freeze([]);
  const requireProvider = (kind, id2) => {
    if (!frozen) throw new TypeError("Behavior capability registry is not frozen.");
    const provider = providers.get(providerKey(kind, id2));
    if (!provider) throw new TypeError(`Behavior ${kind} is not registered: ${id2}`);
    return provider;
  };
  const assertAvailable = (provider, allowed) => {
    if (allowed && !allowed(provider.descriptor))
      throw new TypeError(`Behavior capability is unavailable for this actor: ${provider.descriptor.id}`);
  };
  const validateCondition = (condition, depth, count, allowed) => {
    if (!behaviorObject(condition) || depth > BEHAVIOR_MAX_DEPTH || ++count.value > BEHAVIOR_MAX_NODES)
      throw new TypeError("Behavior condition is invalid or too deep.");
    if ("name" in condition) {
      const provider = requireProvider("condition", String(condition.name));
      assertAvailable(provider, allowed);
      validateBehaviorArguments(provider.descriptor, condition.args);
      return;
    }
    const entries = "all" in condition ? condition.all : "any" in condition ? condition.any : "not" in condition ? [condition.not] : null;
    if (!entries || !Array.isArray(entries) || entries.length === 0)
      throw new TypeError("Behavior condition expression is invalid.");
    entries.forEach((entry) => validateCondition(entry, depth + 1, count, allowed));
  };
  const validateNode = (node, depth, count, ids, allowed) => {
    if (!behaviorObject(node) || depth > BEHAVIOR_MAX_DEPTH || ++count.value > BEHAVIOR_MAX_NODES)
      throw new TypeError("Behavior tree is invalid or too large.");
    if (typeof node.id !== "string" || !IDENTIFIER2.test(node.id)) throw new TypeError("Behavior node id is invalid.");
    if (ids.has(node.id)) throw new TypeError("Behavior node ids must be unique.");
    ids.add(node.id);
    if ("guard" in node && node.guard) validateCondition(node.guard, depth + 1, count, allowed);
    if (node.type === "selector" || node.type === "sequence") {
      if (!Array.isArray(node.children) || !node.children.length)
        throw new TypeError("Behavior composite must have children.");
      node.children.forEach((child) => validateNode(child, depth + 1, count, ids, allowed));
    } else if (node.type === "condition") validateCondition(node.condition, depth + 1, count, allowed);
    else if (node.type === "action") {
      const provider = requireProvider("skill", String(node.skill));
      assertAvailable(provider, allowed);
      validateBehaviorArguments(provider.descriptor, node.args);
    } else throw new TypeError("Behavior node type is invalid.");
  };
  const validateDefinition = (definition2, allowed) => {
    if (!behaviorObject(definition2) || definition2.version !== BEHAVIOR_SCHEMA_VERSION || behaviorJsonBytes(definition2) > BEHAVIOR_MAX_BYTES)
      throw new TypeError("Behavior definition header is invalid or too large.");
    const ids = /* @__PURE__ */ new Set();
    const count = { value: 0 };
    validateNode(definition2.root, 1, count, ids, allowed);
    for (const monitor of definition2.monitors ?? []) {
      if (!IDENTIFIER2.test(monitor.id) || ids.has(monitor.id) || !monitor.reason.trim() || monitor.reason.length > 256)
        throw new TypeError("Behavior monitor is invalid or duplicated.");
      ids.add(monitor.id);
      validateCondition(monitor.condition, 1, count, allowed);
    }
  };
  const registry = Object.freeze({
    register(identity5, definition2) {
      if (frozen) throw new TypeError("Behavior capability registry is frozen.");
      if (providers.size >= BEHAVIOR_MAX_CAPABILITIES) throw new RangeError("Behavior capability limit exceeded.");
      if (!behaviorObject(identity5) || !NAMESPACE_ID2.test(identity5.moduleId) || !EXACT_VERSION2.test(identity5.moduleVersion))
        throw new TypeError("Behavior provider identity is invalid.");
      const legacy = identity5.moduleId === STANDARD_BEHAVIOR_PROVIDER_MODULE_ID && !definition2.id.includes(":");
      if (!legacy && !NAMESPACE_ID2.test(definition2.id) || !IDENTIFIER2.test(definition2.id))
        throw new TypeError(`Behavior capability id is invalid: ${definition2.id || "<empty>"}`);
      if (!EXACT_VERSION2.test(definition2.version)) throw new TypeError("Behavior capability version is invalid.");
      if (!definition2.description.trim() || definition2.description.length > 512)
        throw new TypeError("Behavior capability description is invalid.");
      if (!behaviorObject(definition2.arguments) || Object.keys(definition2.arguments).length > 24)
        throw new TypeError("Behavior capability arguments are invalid.");
      for (const [name, rule] of Object.entries(definition2.arguments)) {
        if (!IDENTIFIER2.test(name)) throw new TypeError("Behavior argument name is invalid.");
        validateBehaviorArgumentRule(rule, `${definition2.id}.${name}`);
      }
      if (definition2.kind === "condition" && typeof definition2.evaluate !== "function")
        throw new TypeError("Behavior condition evaluator is required.");
      if (definition2.kind === "skill") {
        validateBehaviorOperationRequirements(definition2.requiredOperations, definition2.id);
        if (typeof definition2.start !== "function" || typeof definition2.continue !== "function" || !EXACT_VERSION2.test(definition2.state.version) || !Number.isSafeInteger(definition2.state.maximumBytes) || definition2.state.maximumBytes < 2 || definition2.state.maximumBytes > BEHAVIOR_MAX_CAPABILITY_STATE_BYTES)
          throw new TypeError("Behavior skill state contract is invalid.");
      }
      const key2 = providerKey(definition2.kind, definition2.id);
      if (providers.has(key2) || capabilityIds.has(definition2.id))
        throw new TypeError(`Duplicate behavior capability: ${definition2.id}`);
      const descriptor = Object.freeze({
        id: definition2.id,
        name: definition2.id,
        kind: definition2.kind,
        version: definition2.version,
        provider: Object.freeze({ moduleId: identity5.moduleId, version: identity5.moduleVersion }),
        description: definition2.description,
        arguments: frozenBehaviorValue(definition2.arguments),
        requiredOperations: definition2.kind === "skill" ? snapshotBehaviorOperationRequirements(definition2.requiredOperations) : Object.freeze([]),
        ...definition2.kind === "skill" ? { state: Object.freeze({ version: definition2.state.version, maximumBytes: definition2.state.maximumBytes }) } : {}
      });
      assertBehaviorCapabilityDescriptor(descriptor);
      providers.set(
        key2,
        Object.freeze({
          identity: Object.freeze({ ...identity5 }),
          definition: snapshotBehaviorProvider(definition2),
          descriptor
        })
      );
      capabilityIds.add(definition2.id);
    },
    freeze(definitions3) {
      if (frozen) throw new TypeError("Behavior capability registry is already frozen.");
      for (const provider of providers.values())
        assertBehaviorProviderAdmission(definitions3, provider.identity, provider.descriptor);
      const candidate2 = Object.freeze(
        [...providers.values()].map((entry) => frozenBehaviorValue(entry.descriptor)).sort(
          (left, right) => left.kind === right.kind ? left.id.localeCompare(right.id) : left.kind.localeCompare(right.kind)
        )
      );
      if (!isBehaviorCapabilityCatalog(candidate2)) throw new RangeError("Behavior capability catalog is invalid.");
      catalog = candidate2;
      frozen = true;
    },
    catalog() {
      if (!frozen) throw new TypeError("Behavior capability registry is not frozen.");
      return catalog;
    },
    catalogForActor(binding, actorState, allowed) {
      if (!frozen) throw new TypeError("Behavior capability registry is not frozen.");
      if (!actorState || actorState.lifecycle !== "alive" || actorState.controlSource !== "behavior" || actorState.reference.entityId !== binding.entityId || actorState.reference.epoch !== binding.epoch || actorState.reference.lifetime !== binding.lifetime)
        return Object.freeze([]);
      return Object.freeze(catalog.filter(allowed));
    },
    validateDefinition(definition2) {
      validateDefinition(definition2);
    },
    validateDefinitionForActor(definition2, allowed) {
      if (typeof allowed !== "function") throw new TypeError("Behavior actor capability gate is required.");
      validateDefinition(definition2, allowed);
    },
    evaluate(id2, context, args) {
      const provider = requireProvider("condition", id2);
      if (provider.definition.kind !== "condition") throw new TypeError(`Behavior condition is not registered: ${id2}`);
      assertBehaviorProviderContext(context);
      assertAvailable(provider, context.allows);
      const readonlyContext = Object.freeze({
        actor: context.actor,
        actorState: context.actorState,
        deltaSeconds: context.deltaSeconds,
        elapsedSeconds: context.elapsedSeconds,
        ...provider.identity.moduleId === STANDARD_BEHAVIOR_PROVIDER_MODULE_ID ? { __standard: context.standard } : {}
      });
      const result = provider.definition.evaluate(
        readonlyContext,
        validateBehaviorArguments(provider.descriptor, args)
      );
      if (typeof result !== "boolean")
        throw new TypeError(`Behavior condition ${provider.descriptor.id} returned a non-boolean result.`);
      return result;
    },
    start(id2, context, args) {
      const provider = requireProvider("skill", id2);
      const definition2 = provider.definition;
      if (definition2.kind !== "skill") throw new TypeError(`Behavior skill is not registered: ${id2}`);
      assertBehaviorProviderContext(context);
      assertAvailable(provider, context.allows);
      return normalizeBehaviorProviderResult(
        provider,
        withBehaviorProviderContext(
          provider,
          context,
          STANDARD_BEHAVIOR_PROVIDER_MODULE_ID,
          (providerContext) => definition2.start(providerContext, validateBehaviorArguments(provider.descriptor, args))
        )
      );
    },
    continue(id2, context, args, state) {
      const provider = requireProvider("skill", id2);
      const definition2 = provider.definition;
      if (definition2.kind !== "skill") throw new TypeError(`Behavior skill is not registered: ${id2}`);
      assertBehaviorProviderContext(context);
      assertAvailable(provider, context.allows);
      validateBehaviorProviderState(provider, state);
      return normalizeBehaviorProviderResult(
        provider,
        withBehaviorProviderContext(
          provider,
          context,
          STANDARD_BEHAVIOR_PROVIDER_MODULE_ID,
          (providerContext) => definition2.continue(
            providerContext,
            validateBehaviorArguments(provider.descriptor, args),
            frozenBehaviorValue(state)
          )
        )
      );
    },
    cancel(id2, context, args, state, reason) {
      const provider = requireProvider("skill", id2);
      const definition2 = provider.definition;
      if (definition2.kind !== "skill") throw new TypeError(`Behavior skill is not registered: ${id2}`);
      assertBehaviorProviderContext(context);
      assertAvailable(provider, context.allows);
      validateBehaviorProviderState(provider, state);
      if (!definition2.cancel) return Object.freeze({ status: "cancelled", phase: "cancelled" });
      return normalizeBehaviorProviderResult(
        provider,
        withBehaviorProviderContext(
          provider,
          context,
          STANDARD_BEHAVIOR_PROVIDER_MODULE_ID,
          (providerContext) => definition2.cancel(
            providerContext,
            validateBehaviorArguments(provider.descriptor, args),
            frozenBehaviorValue(state),
            reason
          )
        )
      );
    },
    checkpoint(id2, state) {
      const provider = requireProvider("skill", id2);
      validateBehaviorProviderState(provider, state);
      return Object.freeze({
        capabilityId: id2,
        provider: frozenBehaviorValue(provider.descriptor.provider),
        state: Object.freeze({ version: provider.descriptor.state.version, value: frozenBehaviorValue(state) })
      });
    },
    assertRestorable(checkpoint) {
      if (!behaviorObject(checkpoint) || !behaviorObject(checkpoint.provider) || !behaviorObject(checkpoint.state))
        throw new TypeError("Behavior checkpoint is invalid.");
      const provider = requireProvider("skill", String(checkpoint.capabilityId));
      if (checkpoint.provider.moduleId !== provider.descriptor.provider.moduleId || checkpoint.provider.version !== provider.descriptor.provider.version)
        throw new TypeError("Behavior checkpoint provider version is incompatible.");
      if (checkpoint.state.version !== provider.descriptor.state?.version)
        throw new TypeError("Behavior checkpoint state version is incompatible.");
      validateBehaviorProviderState(provider, checkpoint.state.value);
    }
  });
  return registry;
}

// packages/stdlib/src/server/gameplay/ecs-actor-mode-state.ts
var CREATIVE_HOTBAR_SIZE = 8;
var defaultActorModeFacets = (hotbarSize = CREATIVE_HOTBAR_SIZE) => ({
  mode: { version: 1, value: "survival", revision: 0 },
  creativeCatalog: {
    version: 1,
    hotbar: Object.freeze(Array.from({ length: hotbarSize }, () => null)),
    selectedSlot: 0,
    revision: 0
  },
  flight: { version: 1, enabled: false, revision: 0 }
});
var validRevision = (value) => Number.isSafeInteger(value) && value >= 0;
function validateActorModeFacets(facets, items, defaultHotbarSize = CREATIVE_HOTBAR_SIZE) {
  const supplied = [facets.mode, facets.creativeCatalog, facets.flight].filter((value) => value !== void 0).length;
  if (supplied === 0) return defaultActorModeFacets(defaultHotbarSize);
  if (supplied !== 3) throw new TypeError("Actor mode component snapshots must be supplied together.");
  const mode = facets.mode;
  const catalog = facets.creativeCatalog;
  const flight = facets.flight;
  if (mode.version !== 1 || !["survival", "creative"].includes(mode.value) || !validRevision(mode.revision))
    throw new TypeError("Actor mode component snapshot is invalid.");
  if (catalog.version !== 1 || !Array.isArray(catalog.hotbar) || catalog.hotbar.length < 1 || catalog.hotbar.length > 9 || !Number.isSafeInteger(catalog.selectedSlot) || catalog.selectedSlot < 0 || catalog.selectedSlot >= catalog.hotbar.length || !validRevision(catalog.revision) || [...catalog.hotbar].some((itemId) => itemId !== null && (typeof itemId !== "string" || !items.has(itemId))))
    throw new TypeError("Creative catalog component snapshot is invalid.");
  if (flight.version !== 1 || typeof flight.enabled !== "boolean" || !validRevision(flight.revision))
    throw new TypeError("Actor flight component snapshot is invalid.");
  if (mode.value === "survival" && flight.enabled)
    throw new TypeError("Survival actor cannot have creative flight enabled.");
  return {
    mode: { ...mode },
    creativeCatalog: { ...catalog, hotbar: Object.freeze([...catalog.hotbar]) },
    flight: { ...flight }
  };
}

// packages/stdlib/src/server/gameplay/modules/furnace-candidates.ts
function createFurnaceDefinitions(input) {
  const recipes = /* @__PURE__ */ new Map();
  const recipesByInput = /* @__PURE__ */ new Map();
  for (const source of input.recipes) {
    if (!source.id?.trim() || recipes.has(source.id))
      throw new TypeError(`Duplicate or empty furnace recipe: ${source.id}`);
    validateSingleSlotStack(source.input, input.items, "Furnace recipe input");
    validateSingleSlotStack(source.output, input.items, "Furnace recipe output");
    const durationSeconds = logicalDuration(source.durationSeconds, "Furnace recipe duration");
    if (recipesByInput.has(source.input.itemId))
      throw new TypeError(`Duplicate furnace recipe input: ${source.input.itemId}`);
    const recipe = Object.freeze({
      id: source.id,
      input: Object.freeze(input.items.normalizeStack(source.input)),
      output: Object.freeze(input.items.normalizeStack(source.output)),
      durationSeconds
    });
    recipes.set(recipe.id, recipe);
    recipesByInput.set(recipe.input.itemId, recipe);
  }
  const fuels = /* @__PURE__ */ new Map();
  for (const source of input.fuels) {
    input.items.require(source.itemId);
    if (fuels.has(source.itemId)) throw new TypeError(`Duplicate furnace fuel: ${source.itemId}`);
    fuels.set(
      source.itemId,
      Object.freeze({
        itemId: source.itemId,
        burnSeconds: logicalDuration(source.burnSeconds, "Furnace fuel duration")
      })
    );
  }
  const recipeValues = Object.freeze([...recipes.values()]);
  const fuelValues = Object.freeze([...fuels.values()]);
  return Object.freeze({
    items: input.items,
    recipe: (id2) => recipes.get(id2),
    recipeForInput: (itemId) => recipesByInput.get(itemId),
    fuel: (itemId) => fuels.get(itemId),
    listRecipes: () => recipeValues,
    listFuels: () => fuelValues
  });
}
function validateFurnaceSnapshot(raw, definitions3) {
  const source = raw;
  if (!source || source.version !== 1) throw new TypeError("Furnace snapshot version is invalid.");
  const input = validateSlot(source.input, definitions3.items, "input");
  const fuel = validateSlot(source.fuel, definitions3.items, "fuel");
  const output = validateSlot(source.output, definitions3.items, "output");
  if (fuel && !definitions3.fuel(fuel.itemId)) throw new TypeError(`Unknown furnace fuel: ${fuel.itemId}`);
  if (!finiteNonNegative(source.remainingFuelSeconds) || !finiteNonNegative(source.progressSeconds))
    throw new TypeError("Furnace snapshot time is invalid.");
  if (source.activeRecipeId !== null && typeof source.activeRecipeId !== "string")
    throw new TypeError("Furnace active recipe identity is invalid.");
  const active = source.activeRecipeId === null ? null : definitions3.recipe(source.activeRecipeId);
  if (source.activeRecipeId !== null && !active)
    throw new TypeError(`Unknown furnace active recipe: ${source.activeRecipeId}`);
  if (active && (!input || !sameItemStackIdentity(input, active.input) || input.count < active.input.count))
    throw new TypeError("Furnace active recipe does not match its input.");
  if (active && round(source.progressSeconds) >= active.durationSeconds)
    throw new TypeError("Furnace progress exceeds its active recipe duration.");
  if (!active && source.progressSeconds !== 0) throw new TypeError("Furnace progress requires an active recipe.");
  return {
    version: 1,
    input,
    fuel,
    output,
    activeRecipeId: active?.id ?? null,
    remainingFuelSeconds: round(source.remainingFuelSeconds),
    progressSeconds: round(source.progressSeconds)
  };
}
function advanceFurnaceCandidate(raw, logicalSeconds, definitions3) {
  if (!finiteNonNegative(logicalSeconds))
    throw new TypeError("Furnace logical seconds must be non-negative and finite.");
  const decoded = validateFurnaceSnapshot(raw, definitions3);
  const state = { ...decoded };
  const completed = [];
  let remaining = round(logicalSeconds);
  let transitions = 0;
  while (transitions++ < 512) {
    const recipe = state.input ? definitions3.recipeForInput(state.input.itemId) : void 0;
    if (!recipe || !sameItemStackIdentity(state.input, recipe.input) || state.input.count < recipe.input.count) {
      state.activeRecipeId = null;
      state.progressSeconds = 0;
      break;
    }
    if (!canAcceptOutput(state.output, recipe.output, definitions3.items)) break;
    if (remaining === 0) break;
    if (state.remainingFuelSeconds === 0) {
      const fuel = state.fuel ? definitions3.fuel(state.fuel.itemId) : void 0;
      if (!fuel) break;
      state.fuel = decrement(state.fuel, 1);
      state.remainingFuelSeconds = fuel.burnSeconds;
    }
    state.activeRecipeId = recipe.id;
    const advanced = Math.min(remaining, state.remainingFuelSeconds, recipe.durationSeconds - state.progressSeconds);
    if (advanced <= 0) break;
    remaining = round(remaining - advanced);
    state.remainingFuelSeconds = round(state.remainingFuelSeconds - advanced);
    state.progressSeconds = round(state.progressSeconds + advanced);
    if (state.progressSeconds < recipe.durationSeconds) continue;
    state.input = decrement(state.input, recipe.input.count);
    state.output = increment(state.output, recipe.output);
    state.activeRecipeId = null;
    state.progressSeconds = 0;
    completed.push(recipe.id);
  }
  if (transitions >= 512) throw new Error("Furnace candidate transition limit exceeded.");
  return { snapshot: validateFurnaceSnapshot(state, definitions3), completedRecipeIds: Object.freeze(completed) };
}
function validateSlot(value, items, label) {
  if (value === null) return null;
  if (!value || typeof value !== "object") throw new TypeError(`Furnace ${label} slot is invalid.`);
  try {
    return new Inventory(1, [value], items).slot(0);
  } catch (error) {
    throw new TypeError(`Furnace ${label} slot is invalid: ${error instanceof Error ? error.message : String(error)}`, {
      cause: error
    });
  }
}
function validateSingleSlotStack(stack2, items, label) {
  try {
    new Inventory(1, [stack2], items);
  } catch (error) {
    throw new TypeError(`${label} is invalid: ${error instanceof Error ? error.message : String(error)}`, {
      cause: error
    });
  }
}
function logicalDuration(value, label) {
  if (!finiteNonNegative(value) || value <= 0) throw new TypeError(`${label} must be positive and finite.`);
  const duration = round(value);
  if (duration === 0) throw new TypeError(`${label} is below logical time precision.`);
  return duration;
}
var finiteNonNegative = (value) => typeof value === "number" && Number.isFinite(value) && value >= 0 && value <= Number.MAX_SAFE_INTEGER / 1e6;
var round = (value) => Math.round(value * 1e6) / 1e6;
function canAcceptOutput(output, added, items) {
  return output === null || sameItemStackIdentity(output, added) && output.count + added.count <= items.require(added.itemId).stackLimit;
}
function decrement(stack2, count) {
  return stack2.count === count ? null : { ...stack2, count: stack2.count - count };
}
function increment(output, added) {
  return output ? { ...output, count: output.count + added.count } : cloneItemStack(added);
}

// packages/stdlib/src/server/gameplay/ecs-station-state.ts
function createStationStateCodec(input) {
  if (!input || typeof input !== "object" || input.furnace?.items !== input.items)
    throw new TypeError("Station and furnace item registries must be the same world registry.");
  if (!Array.isArray(input.definitions) || input.definitions.length === 0)
    throw new TypeError("Station definitions must be an explicit non-empty array.");
  const byKind = /* @__PURE__ */ new Map();
  const byVoxel = /* @__PURE__ */ new Map();
  for (const source of input.definitions) {
    if (!source || !isStationKind(source.kind)) throw new TypeError("Station definition kind is invalid.");
    if (!Number.isSafeInteger(source.voxel) || source.voxel <= 0)
      throw new TypeError(`Station voxel is invalid: ${String(source.voxel)}`);
    if (byKind.has(source.kind)) throw new TypeError(`Duplicate station kind definition: ${source.kind}`);
    if (byVoxel.has(source.voxel)) throw new TypeError(`Duplicate station voxel definition: ${source.voxel}`);
    const definition2 = Object.freeze({ kind: source.kind, voxel: source.voxel });
    byKind.set(definition2.kind, definition2);
    byVoxel.set(definition2.voxel, definition2.kind);
  }
  const definitions3 = Object.freeze([...byKind.values()]);
  const codec = Object.freeze({
    items: input.items,
    furnace: input.furnace,
    definitions: definitions3,
    definition: (kind) => byKind.get(kind),
    kindForVoxel: (voxel2) => byVoxel.get(voxel2),
    create: (entityId, kind) => {
      assertEntityId(entityId);
      const definition2 = byKind.get(kind);
      if (!definition2) throw new TypeError(`Unknown station kind: ${String(kind)}`);
      const base = { version: 1, entityId, revision: 0, kind, voxel: definition2.voxel };
      if (kind === "workbench") return freezeStation({ ...base, kind, grid: emptySlots(9) });
      if (kind === "chest") return freezeStation({ ...base, kind, slots: emptySlots(24) });
      return freezeStation({
        ...base,
        kind,
        furnace: validateFurnaceSnapshot(
          {
            version: 1,
            input: null,
            fuel: null,
            output: null,
            activeRecipeId: null,
            remainingFuelSeconds: 0,
            progressSeconds: 0
          },
          input.furnace
        )
      });
    },
    decode: (raw, expectedEntityId) => decodeStation(raw, expectedEntityId, byKind, input)
  });
  return codec;
}
function decodeStation(raw, expectedEntityId, byKind, input) {
  const source = raw;
  if (!source || typeof source !== "object" || Array.isArray(source) || source.version !== 1)
    throw new TypeError("Station component version is invalid.");
  assertEntityId(source.entityId);
  if (expectedEntityId !== void 0 && source.entityId !== expectedEntityId)
    throw new TypeError("Station component identity does not match its entity.");
  const revision2 = source.revision;
  if (typeof revision2 !== "number" || !Number.isSafeInteger(revision2) || revision2 < 0)
    throw new TypeError("Station component revision is invalid.");
  if (!isStationKind(source.kind)) throw new TypeError("Station component kind is invalid.");
  const definition2 = byKind.get(source.kind);
  if (!definition2 || source.voxel !== definition2.voxel)
    throw new TypeError("Station component voxel does not match its kind definition.");
  const base = {
    version: 1,
    entityId: source.entityId,
    revision: revision2,
    kind: source.kind,
    voxel: definition2.voxel
  };
  if (source.kind === "workbench") {
    assertExactKeys(source, ["version", "entityId", "revision", "kind", "voxel", "grid"]);
    return freezeStation({
      ...base,
      kind: "workbench",
      grid: validateSlots(source.grid, 9, input.items, "grid")
    });
  }
  if (source.kind === "chest") {
    assertExactKeys(source, ["version", "entityId", "revision", "kind", "voxel", "slots"]);
    return freezeStation({
      ...base,
      kind: "chest",
      slots: validateSlots(source.slots, 24, input.items, "slots")
    });
  }
  assertExactKeys(source, ["version", "entityId", "revision", "kind", "voxel", "furnace"]);
  return freezeStation({
    ...base,
    kind: "furnace",
    furnace: validateFurnaceSnapshot(source.furnace, input.furnace)
  });
}
function validateSlots(raw, capacity3, items, label) {
  if (!Array.isArray(raw) || raw.length !== capacity3)
    throw new TypeError(`Station ${label} must contain ${capacity3} slots.`);
  assertDense(raw, `Station ${label}`);
  try {
    return freezeSlots(new Inventory(capacity3, raw, items).snapshot());
  } catch (error) {
    throw new TypeError(`Station ${label} is invalid: ${error instanceof Error ? error.message : String(error)}`, {
      cause: error
    });
  }
}
function freezeStation(snapshot) {
  if (snapshot.kind === "workbench") return Object.freeze({ ...snapshot, grid: freezeSlots(snapshot.grid) });
  if (snapshot.kind === "chest") return Object.freeze({ ...snapshot, slots: freezeSlots(snapshot.slots) });
  const furnace = snapshot.furnace;
  return Object.freeze({
    ...snapshot,
    furnace: Object.freeze({
      ...furnace,
      input: freezeSlot(furnace.input),
      fuel: freezeSlot(furnace.fuel),
      output: freezeSlot(furnace.output)
    })
  });
}
var emptySlots = (capacity3) => Object.freeze(Array.from({ length: capacity3 }, () => null));
var freezeSlots = (slots) => Object.freeze(slots.map((slot) => freezeSlot(slot)));
var freezeSlot = (slot) => {
  if (slot === null) return null;
  const copy = cloneItemStack(slot);
  if (copy.instance) Object.freeze(copy.instance);
  return Object.freeze(copy);
};
var isStationKind = (value) => value === "workbench" || value === "chest" || value === "furnace";
function assertEntityId(value) {
  if (typeof value !== "string" || !value.trim()) throw new TypeError("Station entity identity is invalid.");
}
function assertDense(entries, label) {
  for (let index = 0; index < entries.length; index++) {
    const descriptor = Object.getOwnPropertyDescriptor(entries, index);
    if (!descriptor || !("value" in descriptor)) throw new TypeError(`${label} must be dense data.`);
  }
}
function assertExactKeys(value, expected) {
  const keys = Object.keys(value).sort();
  const allowed = [...expected].sort();
  if (keys.length !== allowed.length || keys.some((key2, index) => key2 !== allowed[index]))
    throw new TypeError("Station component shape is invalid for its kind.");
}

// packages/stdlib/src/server/gameplay/actor-archetype.ts
var LEGACY_ACTOR_ARCHETYPES = [
  "grazer",
  "night-stalker",
  "settler",
  "chicken",
  "cow",
  "pig",
  "pig-zombie",
  "sheep",
  "squid",
  "wolf",
  "zombie",
  "skeleton",
  "spider",
  "creeper",
  "slime"
];
var ACTOR_ARCHETYPE_MAX_LENGTH = 96;
var NAMESPACED_ACTOR_ARCHETYPE = /^[a-z0-9][a-z0-9._-]*:[a-z0-9][a-z0-9._/-]*$/;
var LEGACY_ACTOR_ARCHETYPE_SET = new Set(LEGACY_ACTOR_ARCHETYPES);
var isActorArchetype = (value) => typeof value === "string" && value.length <= ACTOR_ARCHETYPE_MAX_LENGTH && (LEGACY_ACTOR_ARCHETYPE_SET.has(value) || NAMESPACED_ACTOR_ARCHETYPE.test(value));

// packages/stdlib/src/world/voxel-semantics.ts
var MAX_VOXEL_STORAGE_ID = 4095;
var MAX_VOXEL_FACE_MATERIAL_ID = 92;
var NAMESPACE_ID3 = /^[a-z0-9][a-z0-9._-]*:[a-z0-9][a-z0-9._/-]*$/;
var freezeDefinition = (definition2) => {
  if (!NAMESPACE_ID3.test(definition2.id)) throw new TypeError(`Voxel id must be namespace-qualified: ${definition2.id}`);
  if (!Number.isSafeInteger(definition2.storageId) || definition2.storageId < 0 || definition2.storageId > MAX_VOXEL_STORAGE_ID)
    throw new RangeError(`Voxel storage ID is outside the supported 0..4095 range: ${String(definition2.storageId)}`);
  if (typeof definition2.solid !== "boolean" || typeof definition2.targetable !== "boolean" || typeof definition2.renderable !== "boolean")
    throw new TypeError(`Voxel flags are invalid: ${definition2.id}`);
  if (!["cube", "model", "water", "glass", "ice"].includes(definition2.meshKind))
    throw new TypeError(`Voxel mesh kind is invalid: ${definition2.id}`);
  if (!Number.isInteger(definition2.emission) || definition2.emission < 0 || definition2.emission > 15)
    throw new RangeError(`Voxel emission is outside 0..15: ${definition2.id}`);
  if (!Number.isInteger(definition2.lightCost) || definition2.lightCost < 1 || definition2.lightCost > 16)
    throw new RangeError(`Voxel light cost is outside 1..16: ${definition2.id}`);
  if (definition2.faceMaterials.length !== 6 || definition2.faceMaterials.some(
    (material) => !Number.isSafeInteger(material) || material < 1 || material > MAX_VOXEL_FACE_MATERIAL_ID
  ))
    throw new TypeError(`Voxel face material mapping is invalid: ${definition2.id}`);
  const materialCategories = definition2.materialCategories ?? [];
  if (new Set(materialCategories.map(([material]) => material)).size !== materialCategories.length || materialCategories.some(
    ([material, category]) => !definition2.faceMaterials.includes(material) || !["opaque", "cutout", "emissive", "transparent"].includes(category)
  ))
    throw new TypeError(`Voxel material category mapping is invalid: ${definition2.id}`);
  if (definition2.meshKind === "model" && definition2.storageId > 88)
    throw new TypeError(`Pack voxel model geometry is not registered: ${definition2.id}`);
  return Object.freeze({
    ...definition2,
    faceMaterials: Object.freeze([...definition2.faceMaterials]),
    ...materialCategories.length ? {
      materialCategories: Object.freeze(
        materialCategories.map(([material, category]) => Object.freeze([material, category]))
      )
    } : {}
  });
};
function createVoxelSemanticsRegistry(definitions3 = []) {
  const byStorageId = /* @__PURE__ */ new Map();
  const byId = /* @__PURE__ */ new Map();
  for (const raw of definitions3) {
    const definition2 = freezeDefinition(raw);
    if (byStorageId.has(definition2.storageId))
      throw new TypeError(`Duplicate voxel storage ID: ${definition2.storageId}`);
    if (byId.has(definition2.id)) throw new TypeError(`Duplicate voxel definition: ${definition2.id}`);
    byStorageId.set(definition2.storageId, definition2);
    byId.set(definition2.id, definition2);
  }
  const values = Object.freeze([...byStorageId.values()].sort((left, right) => left.storageId - right.storageId));
  return Object.freeze({
    get: (storageId) => byStorageId.get(storageId),
    require: (storageId) => {
      const definition2 = byStorageId.get(storageId);
      if (!definition2) throw new RangeError(`No voxel semantics are registered for storage ID: ${storageId}`);
      return definition2;
    },
    getById: (id2) => byId.get(id2),
    list: () => values
  });
}

// packages/stdlib/src/server/harness/world-authorization.ts
var BUILTIN_WORLD_RESOURCES = Object.freeze([
  "world.identity",
  "world.voxel",
  "world.chunk",
  "world.entity",
  "world.actor",
  "world.character",
  "world.prepare",
  "world.command",
  "world.clock",
  "world.logic",
  "world.action",
  "world.interaction",
  "world.input",
  "world.fluid",
  "world.barrier",
  "world.trace",
  "world.checkpoint"
]);
var ALL_WORLD_OPERATIONS = Object.freeze([
  "read",
  "execute",
  "write",
  "control",
  "export",
  "restore"
]);

// packages/stdlib/src/server/composition/pack-definition.ts
var freezeArray = (values) => Object.freeze([...values]);
function definePackDefinition(input) {
  const modules = freezeArray(input.modules ?? []);
  const manifest = Object.freeze({
    schemaVersion: 1,
    id: input.id,
    version: input.version,
    kind: input.kind,
    entry: input.entry ?? `./${input.id.replace(":", "-")}.mjs`,
    modules: Object.freeze(modules.map((entry) => entry.descriptor)),
    ...input.dependencies ? { dependencies: freezeArray(input.dependencies) } : {},
    ...input.resources ? { resources: freezeArray(input.resources) } : {},
    ...input.presentation ? { presentation: Object.freeze({ ...input.presentation }) } : {},
    ...input.providerSelections ? { providerSelections: freezeArray(input.providerSelections) } : {}
  });
  return Object.freeze({ manifest, modules });
}

// packages/stdlib/src/server/composition/assembly.ts
function definePack(input) {
  return definePackDefinition(input);
}

// packages/stdlib/src/server/gameplay/modules/combat-model.ts
var COMBAT_CAPABILITY = "seedlands:combat";
var COMBAT_ACTOR_COMPONENT = "seedlands:combat-actor";
var COMBAT_WORLD_COMPONENT = "seedlands:combat-world";
var COMBAT_RESOURCE = "seedlands.combat";
var COMBAT_CLOCK_RESOURCE = "seedlands.combat-clock";
var COMBAT_REQUEST_OPERATION = "seedlands:request-combat";
var COMBAT_RESOLVE_OPERATION = "seedlands:resolve-combat";
var COMBAT_ADVANCE_OPERATION = "seedlands:advance-combat";
var COMBAT_SYSTEM = "seedlands:combat-system";
var COMBAT_PARTITIONS = 5;
var COMBAT_PARTITION_SIZE = 128;
var combatActorAddress = (entityId) => ({
  componentId: COMBAT_ACTOR_COMPONENT,
  target: { kind: "entity", entityId }
});
var combatWorldAddress = (partition) => ({
  componentId: COMBAT_WORLD_COMPONENT,
  target: { kind: "world" },
  partition
});
function combatData(raw, allowed, label = "Combat data") {
  if (!raw || typeof raw !== "object" || Array.isArray(raw) || ![Object.prototype, null].includes(Object.getPrototypeOf(raw)))
    throw new TypeError(`${label} must be an object.`);
  const descriptors = Object.getOwnPropertyDescriptors(raw);
  for (const key2 of Reflect.ownKeys(descriptors))
    if (typeof key2 !== "string" || !allowed.includes(key2) || !descriptors[key2].enumerable || !("value" in descriptors[key2]))
      throw new TypeError(`${label} has invalid fields.`);
  if (Object.keys(descriptors).length !== allowed.length || allowed.some((key2) => !descriptors[key2]))
    throw new TypeError(`${label} has missing fields.`);
  return raw;
}
var finite = (value, min = 0, max = Number.MAX_SAFE_INTEGER) => typeof value === "number" && Number.isFinite(value) && value >= min && value <= max;
var identity = (value) => typeof value === "string" && value.length > 0 && value.length <= 256 && value.trim() === value;
var pendingToken = (value) => typeof value === "string" && value.length > 0 && value.length <= 8192 && value.trim() === value;
var safeRevision = (value) => Number.isSafeInteger(value) && finite(value);
function validateReference(raw) {
  const value = combatData(raw, ["entityId", "epoch", "lifetime"], "Combat entity reference");
  if (!identity(value.entityId) || !safeRevision(value.epoch) || value.epoch === 0 || !safeRevision(value.lifetime) || value.lifetime === 0)
    throw new TypeError("Combat entity reference is invalid.");
  return Object.freeze({ entityId: value.entityId, epoch: value.epoch, lifetime: value.lifetime });
}
function validatePublicCombat(raw) {
  const value = combatData(raw, ["active", "cooldownRemainingSeconds", "lastResult"], "Combat public snapshot");
  if (!finite(value.cooldownRemainingSeconds)) throw new TypeError("Combat cooldown is invalid.");
  let active = null;
  if (value.active !== null) {
    const current2 = combatData(
      value.active,
      [
        "actionId",
        "definitionId",
        "targetId",
        "comboStep",
        "comboLength",
        "phase",
        "phaseElapsedSeconds",
        "phaseDurationSeconds",
        "canBuffer",
        "buffered"
      ],
      "Combat active projection"
    );
    if (!identity(current2.actionId) || !identity(current2.definitionId) || !identity(current2.targetId) || !safeRevision(current2.comboStep) || !Number.isSafeInteger(current2.comboLength) || !finite(current2.comboLength, 1) || !["windup", "hit", "recovery"].includes(String(current2.phase)) || !finite(current2.phaseElapsedSeconds) || !finite(current2.phaseDurationSeconds) || current2.phaseElapsedSeconds > current2.phaseDurationSeconds || typeof current2.canBuffer !== "boolean" || typeof current2.buffered !== "boolean")
      throw new TypeError("Combat active projection is invalid.");
    active = Object.freeze(current2);
  }
  let lastResult = null;
  if (value.lastResult !== null) {
    const allowed = ["sequence", "actionId", "definitionId", "targetId", "comboStep", "outcome", "damage"];
    const hasReason = Object.hasOwn(value.lastResult, "reason");
    const result = combatData(
      value.lastResult,
      hasReason ? [...allowed, "reason"] : allowed,
      "Combat result projection"
    );
    if (!safeRevision(result.sequence) || !identity(result.actionId) || !identity(result.definitionId) || !identity(result.targetId) || !safeRevision(result.comboStep) || !["hit", "miss", "cancelled"].includes(String(result.outcome)) || !finite(result.damage) || result.reason !== void 0 && (typeof result.reason !== "string" || !result.reason.trim() || result.reason.length > 256))
      throw new TypeError("Combat result projection is invalid.");
    lastResult = Object.freeze(result);
  }
  return Object.freeze({ active, cooldownRemainingSeconds: value.cooldownRemainingSeconds, lastResult });
}
function validateCombatActorProjection(raw) {
  const value = combatData(
    raw,
    [
      "version",
      "reference",
      "kind",
      "health",
      "maxHealth",
      "lifecycle",
      "mode",
      "meleeDefinitionId",
      "combat",
      "pending"
    ],
    "Combat actor projection"
  );
  const reference3 = validateReference(value.reference);
  const mode = combatData(value.mode, ["value", "revision"], "Combat mode projection");
  if (value.version !== 1 || !["player", "creature", "npc"].includes(String(value.kind)) || !finite(value.maxHealth, Number.EPSILON) || !finite(value.health, 0, value.maxHealth) || !["alive", "dead"].includes(String(value.lifecycle)) || value.health === 0 !== (value.lifecycle === "dead") || !["survival", "creative"].includes(String(mode.value)) || !safeRevision(mode.revision) || value.meleeDefinitionId !== null && !identity(value.meleeDefinitionId))
    throw new TypeError("Combat actor projection is invalid.");
  let pending = null;
  if (value.pending !== null) {
    const hit = combatData(value.pending, ["token", "targetId", "baseDamage"], "Combat pending projection");
    if (!pendingToken(hit.token) || !identity(hit.targetId) || !finite(hit.baseDamage, 0, 1e6))
      throw new TypeError("Combat pending projection is invalid.");
    pending = Object.freeze({ token: hit.token, targetId: hit.targetId, baseDamage: hit.baseDamage });
  }
  const combat = validatePublicCombat(value.combat);
  if (pending && (combat.active?.targetId !== pending.targetId || combat.active.phase !== "windup" || combat.active.phaseElapsedSeconds !== combat.active.phaseDurationSeconds))
    throw new TypeError("Combat pending projection does not match the public frontier.");
  return Object.freeze({
    version: 1,
    reference: reference3,
    kind: value.kind,
    health: value.health,
    maxHealth: value.maxHealth,
    lifecycle: value.lifecycle,
    mode: Object.freeze({ value: mode.value, revision: mode.revision }),
    meleeDefinitionId: value.meleeDefinitionId,
    combat,
    pending
  });
}
function validateCombatWorldPartition(raw) {
  const value = combatData(raw, ["version", "partition", "entries"], "Combat world partition");
  if (value.version !== 1 || !safeRevision(value.partition) || value.partition >= COMBAT_PARTITIONS || !Array.isArray(value.entries) || value.entries.length > COMBAT_PARTITION_SIZE)
    throw new TypeError("Combat world partition is invalid.");
  const entries = [];
  let previous = "";
  for (const rawEntry of value.entries) {
    const entry = combatData(rawEntry, ["reference", "active", "pending"], "Combat world entry");
    const reference3 = validateReference(entry.reference);
    if (reference3.entityId <= previous || typeof entry.active !== "boolean" || typeof entry.pending !== "boolean")
      throw new TypeError("Combat world entries are invalid or unsorted.");
    previous = reference3.entityId;
    entries.push(Object.freeze({ reference: reference3, active: entry.active, pending: entry.pending }));
  }
  return Object.freeze({ version: 1, partition: value.partition, entries: Object.freeze(entries) });
}
var combatCapability = () => Object.freeze({
  actorComponentId: COMBAT_ACTOR_COMPONENT,
  worldComponentId: COMBAT_WORLD_COMPONENT,
  requestOperationId: COMBAT_REQUEST_OPERATION,
  resolveOperationId: COMBAT_RESOLVE_OPERATION,
  advanceOperationId: COMBAT_ADVANCE_OPERATION,
  partitions: COMBAT_PARTITIONS
});
function validateCombatRequestInput(raw) {
  const value = combatData(raw, ["targetId"], "Combat request input");
  if (!identity(value.targetId)) throw new TypeError("Combat request target is invalid.");
  return Object.freeze({ targetId: value.targetId });
}
function validateCombatResolveInput(raw) {
  const value = combatData(raw, ["token"], "Combat resolve input");
  if (!pendingToken(value.token)) throw new TypeError("Combat resolve token is invalid.");
  return Object.freeze({ token: value.token });
}
function validateCombatRequestEffectiveInput(raw) {
  const value = combatData(raw, ["targetId", "rulesetRevision"], "Combat request effective input");
  if (!identity(value.targetId) || !safeRevision(value.rulesetRevision))
    throw new TypeError("Combat request policy is invalid.");
  return Object.freeze({ targetId: value.targetId, rulesetRevision: value.rulesetRevision });
}
function validateCombatResolveEffectiveInput(raw) {
  const value = combatData(raw, ["token", "damage", "rulesetRevision"], "Combat resolve effective input");
  if (!pendingToken(value.token) || !finite(value.damage, 0, 1e6) || !safeRevision(value.rulesetRevision))
    throw new TypeError("Combat resolve policy is invalid.");
  return Object.freeze({ token: value.token, damage: value.damage, rulesetRevision: value.rulesetRevision });
}
function validateCombatAdvanceInput(raw) {
  const hasCancelTokens = Boolean(raw) && typeof raw === "object" && Object.hasOwn(raw, "cancelTokens");
  const value = combatData(raw, hasCancelTokens ? ["seconds", "cancelTokens"] : ["seconds"], "Combat advance input");
  if (!finite(value.seconds, 0, 1)) throw new TypeError("Combat advance must be between 0 and 1 second.");
  if (!hasCancelTokens) return Object.freeze({ seconds: value.seconds });
  if (!Array.isArray(value.cancelTokens) || value.cancelTokens.length > 1024 || value.cancelTokens.some((token) => !pendingToken(token)) || new Set(value.cancelTokens).size !== value.cancelTokens.length)
    throw new TypeError("Combat cancellation tokens are invalid or duplicated.");
  return Object.freeze({ seconds: value.seconds, cancelTokens: Object.freeze([...value.cancelTokens]) });
}
function validateCombatCandidate(raw) {
  const kindDescriptor = raw && typeof raw === "object" && !Array.isArray(raw) ? Object.getOwnPropertyDescriptor(raw, "kind") : void 0;
  if (!kindDescriptor?.enumerable || !("value" in kindDescriptor)) throw new TypeError("Combat candidate is invalid.");
  const base = combatData(
    raw,
    kindDescriptor.value === "advance" ? Object.hasOwn(raw, "cancelTokens") ? ["version", "kind", "seconds", "cancelTokens"] : ["version", "kind", "seconds"] : kindDescriptor.value === "resolve" ? ["version", "kind", "actorId", "targetId", "token", "damage", "rulesetRevision"] : ["version", "kind", "actorId", "targetId", "definitionId", "rulesetRevision"],
    "Combat candidate"
  );
  if (base.version !== 1) throw new TypeError("Combat candidate version is invalid.");
  if (base.kind === "advance") {
    const advance = validateCombatAdvanceInput(
      Object.hasOwn(base, "cancelTokens") ? { seconds: base.seconds, cancelTokens: base.cancelTokens } : { seconds: base.seconds }
    );
    return Object.freeze({ version: 1, kind: "advance", ...advance });
  }
  if (!identity(base.actorId) || !identity(base.targetId) || !safeRevision(base.rulesetRevision))
    throw new TypeError("Combat candidate identity is invalid.");
  if (base.kind === "request" && identity(base.definitionId))
    return Object.freeze({
      version: 1,
      kind: "request",
      actorId: base.actorId,
      targetId: base.targetId,
      definitionId: base.definitionId,
      rulesetRevision: base.rulesetRevision
    });
  if (base.kind === "resolve" && pendingToken(base.token) && finite(base.damage, 0, 1e6))
    return Object.freeze({
      version: 1,
      kind: "resolve",
      actorId: base.actorId,
      targetId: base.targetId,
      token: base.token,
      damage: base.damage,
      rulesetRevision: base.rulesetRevision
    });
  throw new TypeError("Combat candidate is invalid.");
}
function validateCombatRulesProfile(raw) {
  const value = combatData(raw, ["damageMultiplier", "immuneTargetModes"], "Combat Ruleset profile");
  if (!finite(value.damageMultiplier, 0, 100) || !Array.isArray(value.immuneTargetModes) || value.immuneTargetModes.length > 2 || value.immuneTargetModes.some((mode) => mode !== "survival" && mode !== "creative") || new Set(value.immuneTargetModes).size !== value.immuneTargetModes.length)
    throw new TypeError("Combat Ruleset profile is invalid.");
  return Object.freeze({
    damageMultiplier: value.damageMultiplier,
    immuneTargetModes: Object.freeze([...value.immuneTargetModes])
  });
}

// packages/stdlib/src/server/gameplay/modules/food-effect.ts
function foodEffect(food, needs, vitals) {
  if (food.healthRestore !== void 0 && !vitals) throw new Error("health-unavailable");
  const health = vitals ? Math.min(vitals.maxHealth, vitals.health + (food.healthRestore ?? 0)) : void 0;
  const hunger = needs.meaning === "satiety" ? Math.min(needs.maxHunger, needs.hunger + (food.hungerRestore ?? 0)) : Math.max(0, needs.hunger - (food.hungerRestore ?? 0));
  if (hunger === needs.hunger && (health === void 0 || health === vitals?.health))
    throw new Error(food.healthRestore !== void 0 ? "health-full" : "hunger-full");
  return { hunger, ...health === void 0 ? {} : { health } };
}

// packages/stdlib/src/server/gameplay/modules/inventory-api.ts
function createInventoryCandidate(items, value) {
  if (!Array.isArray(value) || value.length < 1 || value.length > 64)
    throw new TypeError("Inventory candidate capacity is invalid.");
  const slots = value.map((slot) => slot === null ? null : items.normalizeStack(slot));
  return new Inventory(slots.length, slots, items);
}

// packages/stdlib/src/server/gameplay/modules/crafting-provider.ts
var CRAFTING_CAPABILITY = "seedlands:crafting-match";
function freezeCraftingProvider(value) {
  if (!value || value.version !== 1 || typeof value.match !== "function")
    throw new TypeError("Invalid crafting provider version or matcher.");
  const match = value.match;
  return Object.freeze({ version: 1, match: (request) => match(request) });
}
var shapelessCraftingProvider = freezeCraftingProvider({
  version: 1,
  match({ recipe, slots }) {
    const result = [];
    for (const input of recipe.inputs) {
      let remaining = input.count;
      for (let slot = 0; slot < slots.length && remaining; slot++) {
        const stack2 = slots[slot];
        if (!stack2 || !sameItemStackIdentity(stack2, input)) continue;
        const count = Math.min(remaining, stack2.count);
        result.push({ slot, count });
        remaining -= count;
      }
      if (remaining) return null;
    }
    return result;
  }
});
function frozenSlots(slots) {
  return Object.freeze(
    slots.map(
      (stack2) => stack2 ? Object.freeze({
        ...stack2,
        ...stack2.instance ? { instance: Object.freeze({ ...stack2.instance }) } : {}
      }) : null
    )
  );
}
function applyCraftingMatch(inventory, recipeId, registry, provider, selectedSlot) {
  if (inventory.items !== registry.items) throw new TypeError("Crafting content registries do not match.");
  if (!provider) return { success: false, reason: "crafting-unavailable" };
  const recipe = registry.get(recipeId);
  if (!recipe) return { success: false, reason: "unknown-recipe" };
  if (!Number.isSafeInteger(selectedSlot) || selectedSlot < 0 || selectedSlot >= inventory.capacity)
    throw new RangeError("Crafting selected slot is out of range.");
  const slots = frozenSlots(inventory.snapshot());
  const plan = provider.match(Object.freeze({ recipe, slots, selectedSlot }));
  if (plan === null) return { success: false, reason: "missing-inputs" };
  if (!Array.isArray(plan) || !plan.length || plan.length > inventory.capacity)
    throw new TypeError("Invalid crafting consumption plan.");
  const used = /* @__PURE__ */ new Set(), consumed = recipe.inputs.map(() => 0);
  const candidate2 = new Inventory(inventory.capacity, slots, inventory.items);
  for (const entry of plan) {
    if (!entry || !Number.isSafeInteger(entry.slot) || entry.slot < 0 || entry.slot >= slots.length || !Number.isSafeInteger(entry.count) || entry.count <= 0 || used.has(entry.slot))
      throw new TypeError("Invalid or duplicate crafting consumption slot.");
    used.add(entry.slot);
    const stack2 = slots[entry.slot];
    const index = stack2 ? recipe.inputs.findIndex((input) => sameItemStackIdentity(input, stack2)) : -1;
    if (!stack2 || index < 0 || entry.count > stack2.count)
      throw new TypeError("Crafting consumption does not match its observed input.");
    consumed[index] += entry.count;
    if (consumed[index] > recipe.inputs[index].count || !candidate2.removeFromSlot(entry.slot, entry.count))
      throw new TypeError("Crafting consumption exceeds its recipe input.");
  }
  if (consumed.some((count, index) => count !== recipe.inputs[index].count))
    throw new TypeError("Crafting consumption omits required input.");
  for (const output of recipe.outputs) {
    if (!candidate2.add(output)) return { success: false, reason: "no-output-capacity" };
  }
  inventory.replace(candidate2.snapshot());
  return { success: true, recipe };
}

// packages/stdlib/src/server/gameplay/modules/inventory-action-model.ts
var INVENTORY_ACTIONS_CAPABILITY = "seedlands:inventory-actions";
var INVENTORY_ACTOR_COMPONENT = "seedlands:inventory-actor";
var INVENTORY_ITEM_COMPONENT = "seedlands:inventory-item";
var INVENTORY_RESOURCE = "seedlands.inventory";
var INVENTORY_ITEM_RESOURCE = "seedlands.inventory-item";
var INVENTORY_SELECT_OPERATION = "seedlands:inventory-select";
var INVENTORY_MOVE_OPERATION = "seedlands:inventory-move";
var INVENTORY_CONSUME_OPERATION = "seedlands:inventory-consume";
var INVENTORY_CRAFT_OPERATION = "seedlands:inventory-craft";
var INVENTORY_DROP_OPERATION = "seedlands:inventory-drop";
var INVENTORY_PICKUP_OPERATION = "seedlands:inventory-pickup";
var MAX_IDENTITY_LENGTH2 = 256;
var MAX_ACTION_COUNT = 1e6;
var MAX_INVENTORY_CAPACITY = 64;
var MAX_NEEDS_VALUE = 1e6;
var MAX_WORLD_COORDINATE = 3e7;
var inventoryActorAddress = (entityId) => ({
  componentId: INVENTORY_ACTOR_COMPONENT,
  target: { kind: "entity", entityId }
});
var inventoryItemAddress = (entityId) => ({
  componentId: INVENTORY_ITEM_COMPONENT,
  target: { kind: "entity", entityId }
});
var inventoryActionsCapability = () => Object.freeze({
  actorComponentId: INVENTORY_ACTOR_COMPONENT,
  itemComponentId: INVENTORY_ITEM_COMPONENT,
  selectOperationId: INVENTORY_SELECT_OPERATION,
  moveOperationId: INVENTORY_MOVE_OPERATION,
  consumeOperationId: INVENTORY_CONSUME_OPERATION,
  craftOperationId: INVENTORY_CRAFT_OPERATION,
  dropOperationId: INVENTORY_DROP_OPERATION,
  pickupOperationId: INVENTORY_PICKUP_OPERATION
});
var identity2 = (value) => typeof value === "string" && value.length > 0 && value.length <= MAX_IDENTITY_LENGTH2 && value.trim() === value;
var safeInteger = (value, min, max) => typeof value === "number" && Number.isSafeInteger(value) && value >= min && value <= max;
var finite2 = (value, min, max) => typeof value === "number" && Number.isFinite(value) && value >= min && value <= max;
function actionData(raw, allowed, label) {
  if (!raw || typeof raw !== "object" || Array.isArray(raw) || ![Object.prototype, null].includes(Object.getPrototypeOf(raw)))
    throw new TypeError(`${label} must be an object.`);
  const descriptors = Object.getOwnPropertyDescriptors(raw);
  for (const key2 of Reflect.ownKeys(descriptors))
    if (typeof key2 !== "string" || !allowed.includes(key2) || !descriptors[key2].enumerable || !("value" in descriptors[key2]))
      throw new TypeError(`${label} has invalid fields.`);
  if (Object.keys(descriptors).length !== allowed.length || allowed.some((key2) => !descriptors[key2]))
    throw new TypeError(`${label} has missing fields.`);
  return raw;
}
function validateReference2(raw, label) {
  const value = actionData(raw, ["entityId", "epoch", "lifetime"], `${label} reference`);
  if (!identity2(value.entityId) || !safeInteger(value.epoch, 1, Number.MAX_SAFE_INTEGER) || !safeInteger(value.lifetime, 1, Number.MAX_SAFE_INTEGER))
    throw new TypeError(`${label} reference is invalid.`);
  return Object.freeze({ entityId: value.entityId, epoch: value.epoch, lifetime: value.lifetime });
}
function freezeStack(stack2) {
  return Object.freeze({
    itemId: stack2.itemId,
    count: stack2.count,
    ...stack2.instance ? { instance: Object.freeze({ durability: stack2.instance.durability }) } : {}
  });
}
function validateStack(items, raw, label, maximumCount) {
  const hasInstance = Boolean(raw) && typeof raw === "object" && Object.hasOwn(raw, "instance");
  const value = actionData(raw, hasInstance ? ["itemId", "count", "instance"] : ["itemId", "count"], label);
  if (hasInstance) actionData(value.instance, ["durability"], `${label} instance`);
  const stack2 = items.normalizeStack(raw);
  if (stack2.count > maximumCount) throw new TypeError(`${label} count is too large.`);
  return freezeStack(stack2);
}
function freezeSlots2(slots) {
  return Object.freeze(slots.map((slot) => slot ? freezeStack(slot) : null));
}
function validateInventoryActorProjection(raw, items) {
  const value = actionData(
    raw,
    [
      "version",
      "reference",
      "kind",
      "slots",
      "equipment",
      "lifecycle",
      "needs",
      "inventoryRevision",
      "cursor",
      ...raw && typeof raw === "object" && Object.hasOwn(raw, "vitals") ? ["vitals"] : []
    ],
    "Inventory actor projection"
  );
  const reference3 = validateReference2(value.reference, "Inventory actor");
  if (value.version !== 1 || !["player", "creature", "npc"].includes(String(value.kind)) || !Array.isArray(value.slots) || value.slots.length < 1 || value.slots.length > MAX_INVENTORY_CAPACITY || !["alive", "dead"].includes(String(value.lifecycle)))
    throw new TypeError("Inventory actor projection is invalid.");
  const slots = freezeSlots2(
    value.slots.map((slot, index) => {
      if (slot === null) return null;
      const stack2 = validateStack(items, slot, `Inventory slot ${index}`, MAX_ACTION_COUNT);
      if (stack2.count > items.require(stack2.itemId).stackLimit)
        throw new TypeError(`Inventory slot ${index} exceeds its stack limit.`);
      return stack2;
    })
  );
  const equipment = actionData(value.equipment, ["selectedSlot", "hotbarSize"], "Inventory equipment projection");
  if (!safeInteger(equipment.hotbarSize, 1, slots.length) || !safeInteger(equipment.selectedSlot, 0, equipment.hotbarSize - 1))
    throw new TypeError("Inventory equipment projection is invalid.");
  const needs = actionData(value.needs, ["hunger", "maxHunger", "meaning"], "Inventory needs projection");
  if (!finite2(needs.maxHunger, Number.EPSILON, MAX_NEEDS_VALUE) || !finite2(needs.hunger, 0, needs.maxHunger) || !["satiety", "deficit"].includes(String(needs.meaning)))
    throw new TypeError("Inventory needs projection is invalid.");
  const vitals = value.vitals === void 0 ? void 0 : actionData(value.vitals, ["health", "maxHealth"], "Food vitals");
  if (vitals && (!finite2(vitals.maxHealth, Number.EPSILON, MAX_NEEDS_VALUE) || !finite2(vitals.health, 0, vitals.maxHealth)))
    throw new TypeError("Inventory vitals projection is invalid.");
  const inventoryRevision = value.inventoryRevision === void 0 ? 0 : value.inventoryRevision;
  if (!safeInteger(inventoryRevision, 0, Number.MAX_SAFE_INTEGER))
    throw new TypeError("Inventory actor revision is invalid.");
  const cursor = validateInventoryCursor(value.cursor, items);
  return Object.freeze({
    version: 1,
    reference: reference3,
    kind: value.kind,
    slots,
    equipment: Object.freeze({ selectedSlot: equipment.selectedSlot, hotbarSize: equipment.hotbarSize }),
    lifecycle: value.lifecycle,
    needs: Object.freeze({
      hunger: needs.hunger,
      maxHunger: needs.maxHunger,
      meaning: needs.meaning
    }),
    ...vitals ? { vitals: Object.freeze({ health: vitals.health, maxHealth: vitals.maxHealth }) } : {},
    inventoryRevision,
    cursor
  });
}
function validateInventoryWorldItemProjection(raw, items) {
  const value = actionData(raw, ["version", "reference", "position", "stack"], "Inventory item projection");
  const reference3 = validateReference2(value.reference, "Inventory item");
  if (value.version !== 1 || !Array.isArray(value.position) || value.position.length !== 3)
    throw new TypeError("Inventory item projection is invalid.");
  const position4 = value.position.map((coordinate) => {
    if (!finite2(coordinate, -MAX_WORLD_COORDINATE, MAX_WORLD_COORDINATE))
      throw new TypeError("Inventory item position is invalid.");
    return coordinate;
  });
  const stack2 = validateStack(items, value.stack, "Inventory item stack", MAX_ACTION_COUNT);
  return Object.freeze({ version: 1, reference: reference3, position: Object.freeze(position4), stack: stack2 });
}
function validateInventorySelectInput(raw) {
  const value = actionData(raw, ["slot"], "Inventory select input");
  if (!safeInteger(value.slot, 0, MAX_INVENTORY_CAPACITY - 1)) throw new TypeError("Inventory slot is invalid.");
  return Object.freeze({ slot: value.slot });
}
function validateInventoryMoveInput(raw) {
  const value = actionData(raw, ["source", "target"], "Inventory move input");
  if (!safeInteger(value.source, 0, MAX_INVENTORY_CAPACITY - 1) || !safeInteger(value.target, 0, MAX_INVENTORY_CAPACITY - 1) || value.source === value.target)
    throw new TypeError("Inventory move slots are invalid.");
  return Object.freeze({ source: value.source, target: value.target });
}
function validateInventoryConsumeInput(raw) {
  const value = actionData(raw, ["slot"], "Inventory consume input");
  if (!safeInteger(value.slot, 0, MAX_INVENTORY_CAPACITY - 1)) throw new TypeError("Inventory slot is invalid.");
  return Object.freeze({ slot: value.slot });
}
function validateInventoryCraftInput(raw) {
  const value = actionData(raw, ["recipeId"], "Inventory craft input");
  if (!identity2(value.recipeId)) throw new TypeError("Inventory recipe identity is invalid.");
  return Object.freeze({ recipeId: value.recipeId });
}
function validateInventoryDropInput(raw) {
  const value = actionData(raw, ["slot", "count"], "Inventory drop input");
  if (!safeInteger(value.slot, 0, MAX_INVENTORY_CAPACITY - 1) || !safeInteger(value.count, 1, MAX_ACTION_COUNT))
    throw new TypeError("Inventory drop input is invalid.");
  return Object.freeze({ slot: value.slot, count: value.count });
}
function validateInventoryPickupInput(raw) {
  if (raw === void 0) return Object.freeze({});
  const value = actionData(raw, ["count"], "Inventory pickup input");
  if (!safeInteger(value.count, 1, MAX_ACTION_COUNT)) throw new TypeError("Inventory pickup count is invalid.");
  return Object.freeze({ count: value.count });
}
function fail(reason) {
  throw new Error(reason);
}
function assertContent(content) {
  if (content.recipes.items !== content.items)
    throw new TypeError("Inventory action item and recipe registries do not match.");
}
function candidate(input) {
  const hunger = Object.freeze({
    ...input.actor.needs,
    ...input.hunger === void 0 ? {} : { hunger: input.hunger }
  });
  const result = Object.freeze({
    version: 1,
    success: true,
    kind: input.kind,
    actorId: input.actor.reference.entityId,
    ...input.result,
    selectedSlot: input.kind === "select" ? input.args.slot : input.actor.equipment.selectedSlot,
    hunger: hunger.hunger
  });
  return Object.freeze({
    version: 1,
    kind: input.kind,
    actorId: input.actor.reference.entityId,
    actorReference: input.actor.reference,
    args: input.args,
    slots: freezeSlots2(input.inventory.snapshot()),
    equipment: Object.freeze({
      selectedSlot: result.selectedSlot,
      hotbarSize: input.actor.equipment.hotbarSize
    }),
    hunger,
    ...input.health === void 0 ? {} : { health: input.health },
    dropIntent: input.dropIntent ?? null,
    pickupIntent: input.pickupIntent ?? null,
    result
  });
}
function buildInventoryActionCandidate(content, request) {
  assertContent(content);
  const actor = validateInventoryActorProjection(request.actor, content.items);
  if (actor.lifecycle !== "alive") fail("actor-dead");
  const inventory = createInventoryCandidate(content.items, actor.slots);
  switch (request.kind) {
    case "select": {
      const args = validateInventorySelectInput(request.input);
      if (args.slot >= actor.equipment.hotbarSize) fail("invalid-slot");
      return candidate({ kind: request.kind, actor, args, inventory });
    }
    case "move": {
      const args = validateInventoryMoveInput(request.input);
      if (!inventory.moveStack(args.source, args.target)) fail("cannot-move-item");
      return candidate({ kind: request.kind, actor, args, inventory });
    }
    case "consume": {
      const args = validateInventoryConsumeInput(request.input);
      const selected = inventory.slot(args.slot);
      if (!selected) fail("no-selected-item");
      const consume = content.items.capability(selected.itemId, "consume");
      if (!consume) fail("item-not-usable");
      const effect = foodEffect(consume, actor.needs, actor.vitals);
      if (!inventory.removeFromSlot(args.slot, 1)) fail("missing-items");
      return candidate({
        kind: request.kind,
        actor,
        args,
        inventory,
        ...effect,
        result: { itemId: selected.itemId, count: 1 }
      });
    }
    case "craft": {
      const args = validateInventoryCraftInput(request.input);
      const crafted = applyCraftingMatch(
        inventory,
        args.recipeId,
        content.recipes,
        content.crafting === void 0 ? shapelessCraftingProvider : content.crafting,
        actor.equipment.selectedSlot
      );
      if (!crafted.success) fail(crafted.reason);
      return candidate({ kind: request.kind, actor, args, inventory, result: { recipeId: args.recipeId } });
    }
    case "drop": {
      const args = validateInventoryDropInput(request.input);
      const selected = inventory.slot(args.slot);
      if (!selected || selected.count < args.count) fail("missing-items");
      if (!inventory.removeFromSlot(args.slot, args.count)) fail("missing-items");
      const stack2 = freezeStack({ ...selected, count: args.count });
      return candidate({
        kind: request.kind,
        actor,
        args,
        inventory,
        dropIntent: Object.freeze({ stack: stack2 }),
        result: { itemId: stack2.itemId, count: stack2.count }
      });
    }
    case "pickup": {
      const args = validateInventoryPickupInput(request.input);
      const item = validateInventoryWorldItemProjection(request.item, content.items);
      if (item.reference.entityId === actor.reference.entityId) fail("invalid-item");
      const count = args.count ?? item.stack.count;
      if (count > item.stack.count) fail("missing-items");
      const stack2 = freezeStack({ ...item.stack, count });
      if (!inventory.add(stack2)) fail("inventory-full");
      const pickupIntent = Object.freeze({
        reference: item.reference,
        position: item.position,
        stack: stack2,
        remainingCount: item.stack.count - count
      });
      return candidate({
        kind: request.kind,
        actor,
        args,
        inventory,
        pickupIntent,
        result: { itemId: item.stack.itemId, count }
      });
    }
  }
}

// packages/stdlib/src/server/gameplay/modules/behavior-registry-module.ts
var standard = (context) => {
  const value = context;
  if (!value.__standard) throw new TypeError("The standard behavior provider is not bound to a Character runtime.");
  return value.__standard;
};
var standardSkill = (id2, description, args, requiredOperations = []) => ({
  id: id2,
  version: "1.0.0",
  kind: "skill",
  description,
  arguments: args,
  requiredOperations,
  state: { version: "1.0.0", maximumBytes: 512 },
  start: (context, input) => standard(context).start(id2, input, context),
  continue: (context, input, state) => standard(context).continue(id2, input, state, context),
  cancel: (context, input, state, reason) => standard(context).cancel(id2, input, state, reason, context)
});
var standardCapabilities = [
  {
    id: "always",
    version: "1.0.0",
    kind: "condition",
    description: "Always true.",
    arguments: {},
    evaluate: () => true
  },
  {
    id: "hunger-at-least",
    version: "1.0.0",
    kind: "condition",
    description: "Hunger is at or above value.",
    arguments: { value: { type: "number", required: true, minimum: 0, maximum: 100 } },
    evaluate: (context, args) => context.actorState.needs.hunger >= Number(args.value)
  },
  {
    id: "hunger-at-most",
    version: "1.0.0",
    kind: "condition",
    description: "Hunger is at or below value.",
    arguments: { value: { type: "number", required: true, minimum: 0, maximum: 100 } },
    evaluate: (context, args) => context.actorState.needs.hunger <= Number(args.value)
  },
  ...[
    ["threat-visible", "A current visible threat exists.", {}],
    ["dialogue-received", "A new dialogue fact arrived since this consumer last evaluated.", {}],
    ["is-night", "World time is outside 06:00-18:00.", {}],
    ["is-day", "World time is within 06:00-18:00.", {}],
    [
      "at-position",
      "Actor is within radius of position.",
      {
        position: { type: "position", required: true },
        radius: { type: "number", minimum: 0.1, maximum: 16 }
      }
    ]
  ].map(([id2, description, args]) => ({
    id: id2,
    version: "1.0.0",
    kind: "condition",
    description,
    arguments: args,
    evaluate: (context, input) => standard(context).evaluate(id2, input)
  })),
  ...[
    [
      "flee-threat",
      "Commit to a fixed retreat from the closest visible threat, then finish at that destination.",
      {
        distance: { type: "number", minimum: 2, maximum: 24 },
        maxReplans: { type: "number", minimum: 0, maximum: 64, integer: true }
      }
    ],
    ["attack-threat", "Attack the closest visible threat.", {}],
    ["ignore-threat", "Acknowledge the current threat.", {}],
    [
      "satisfy-hunger",
      "Collect and consume food through registered Inventory and Feeding operations until satisfied.",
      {
        satisfiedAt: { type: "number", minimum: 0, maximum: 100 },
        avoidThreats: { type: "boolean" },
        maxReplans: { type: "number", minimum: 0, maximum: 64, integer: true }
      }
    ],
    [
      "rest-at-home",
      "Return home and rest until daylight.",
      { position: { type: "position", required: true }, avoidThreats: { type: "boolean" } }
    ],
    [
      "patrol",
      "Visit configured positions continuously.",
      {
        positions: { type: "position", required: true },
        avoidThreats: { type: "boolean" },
        maxReplans: { type: "number", minimum: 0, maximum: 64, integer: true }
      }
    ],
    [
      "wander",
      "Visit deterministic nearby points continuously.",
      {
        radius: { type: "number", minimum: 1, maximum: 16 },
        maxReplans: { type: "number", minimum: 0, maximum: 64, integer: true }
      }
    ],
    [
      "move-to",
      "Walk to a fixed position.",
      {
        position: { type: "position", required: true },
        maxReplans: { type: "number", minimum: 0, maximum: 64, integer: true }
      }
    ],
    [
      "follow",
      "Follow a currently authorized entity target reference.",
      {
        targetRef: { type: "entity-reference", required: true },
        maxReplans: { type: "number", minimum: 0, maximum: 64, integer: true }
      }
    ],
    [
      "wait",
      "Wait for a bounded simulated duration.",
      { seconds: { type: "number", required: true, minimum: 0, maximum: 3600 } }
    ],
    ["hold", "Remain still until interrupted.", {}],
    [
      "speak",
      "Emit one bounded speech fact per activation.",
      { text: { type: "string", required: true, maximum: 280 } }
    ]
  ].map(
    ([id2, description, args]) => standardSkill(
      id2,
      description,
      args,
      id2 === "satisfy-hunger" ? [
        { operationId: INVENTORY_CONSUME_OPERATION, authorization: "self" },
        { operationId: INVENTORY_PICKUP_OPERATION, authorization: "any" }
      ] : id2 === "attack-threat" ? [{ operationId: COMBAT_REQUEST_OPERATION, authorization: "any" }] : []
    )
  )
];
function defineBehaviorRegistryModule(input = {}) {
  return Object.freeze({
    descriptor: {
      id: STANDARD_BEHAVIOR_PROVIDER_MODULE_ID,
      version: "1.0.0",
      provides: [{ id: BEHAVIOR_REGISTRY_CAPABILITY, version: "1.0.0" }],
      ...input.permissions ? { permissions: input.permissions } : {}
    },
    register(api) {
      const registry = createBehaviorCapabilityRegistry();
      for (const capability of standardCapabilities) registry.register(api.identity, capability);
      api.provideCapability(BEHAVIOR_REGISTRY_CAPABILITY, registry);
      api.onDefinitionsReady((definitions3) => registry.freeze(definitions3));
    }
  });
}

// packages/stdlib/src/server/gameplay/modules/inventory-module.ts
var COMPONENT = "seedlands:inventory";
var RESOURCE = "seedlands.inventory";
function defineInventoryModule(options = {}) {
  const layout = options.playerLayout ? freezePlayerInventoryLayout(options.playerLayout) : void 0;
  return Object.freeze({
    descriptor: {
      id: "seedlands:inventory-module",
      version: "1.0.0",
      requires: [{ id: "seedlands:items", version: "1.0.0" }],
      provides: [
        { id: "seedlands:inventory", version: "1.0.0" },
        ...layout ? [{ id: PLAYER_INVENTORY_LAYOUT_CAPABILITY, version: "1.0.0", definitionIdentity: JSON.stringify(layout) }] : []
      ],
      resources: [{ id: RESOURCE, operations: ["read", "write", "execute"] }],
      permissions: [{ resource: RESOURCE, operations: ["read", "write", "execute"] }]
    },
    register(api) {
      if (layout) api.provideCapability(PLAYER_INVENTORY_LAYOUT_CAPABILITY, layout);
      const items = api.requireCapability("seedlands:items");
      api.registerState({
        id: COMPONENT,
        version: "1.0.0",
        resource: RESOURCE,
        validate(value) {
          try {
            createInventoryCandidate(items, value);
            return true;
          } catch {
            return false;
          }
        }
      });
      api.provideCapability(
        "seedlands:inventory",
        Object.freeze({ componentId: COMPONENT, transferOperation: "seedlands:inventory-transfer" })
      );
      api.registerOperation({
        id: "seedlands:inventory-transfer",
        resource: RESOURCE,
        run(context, input, state) {
          if (context.target.kind !== "entity" || context.target.entityId !== context.originalActorId)
            throw new TypeError("Inventory source must match the bound actor.");
          const args = transferInput(input);
          if (args.recipientId === context.originalActorId)
            throw new TypeError("Inventory transfer needs a different recipient.");
          const from = { componentId: COMPONENT, target: context.target };
          const to = { componentId: COMPONENT, target: { kind: "entity", entityId: args.recipientId } };
          const source = createInventoryCandidate(items, state.read(from));
          const destination = createInventoryCandidate(items, state.read(to));
          const stack2 = items.normalizeStack({
            itemId: args.itemId,
            count: args.count,
            ...args.instance === void 0 ? {} : { instance: args.instance }
          });
          if (!source.remove(stack2)) throw new Error("missing-items");
          if (!destination.add(stack2)) throw new Error("inventory-full");
          state.write(from, source.snapshot());
          state.write(to, destination.snapshot());
          return {
            itemId: args.itemId,
            count: args.count,
            actorId: context.originalActorId,
            recipientId: args.recipientId
          };
        }
      });
    }
  });
}
function transferInput(input) {
  if (!input || typeof input !== "object" || Array.isArray(input) || !("recipientId" in input) || !("itemId" in input) || !("count" in input) || typeof input.recipientId !== "string" || !input.recipientId.trim() || typeof input.itemId !== "string" || typeof input.count !== "number" || !Number.isSafeInteger(input.count) || input.count <= 0)
    throw new TypeError("Inventory transfer input is invalid.");
  return {
    recipientId: input.recipientId,
    itemId: input.itemId,
    count: input.count,
    instance: "instance" in input ? input.instance : void 0
  };
}

// packages/stdlib/src/server/gameplay/station-content.ts
function createStationContent(input, items) {
  const stack2 = (raw) => Object.freeze(items.normalizeStack(raw));
  const recipes = /* @__PURE__ */ new Map();
  for (const source of input.recipes) {
    if (!source.id?.trim() || recipes.has(source.id)) throw new TypeError("Duplicate or invalid station recipe ID.");
    if (!Array.isArray(source.outputs) || source.outputs.length === 0)
      throw new TypeError("Station recipe requires outputs.");
    const outputs = Object.freeze(source.outputs.map(stack2));
    let recipe;
    if (source.kind === "shaped") {
      if (!Array.isArray(source.pattern) || source.pattern.length !== 9)
        throw new TypeError("Station pattern must have nine slots.");
      const pattern = Object.freeze(source.pattern.map((value) => value === null ? null : stack2(value)));
      if (!pattern.some(Boolean)) throw new TypeError("Station recipe requires ingredients.");
      recipe = Object.freeze({ kind: source.kind, id: source.id, pattern, outputs });
    } else if (source.kind === "shapeless") {
      if (!Array.isArray(source.inputs) || source.inputs.length === 0)
        throw new TypeError("Station recipe requires ingredients.");
      recipe = Object.freeze({
        kind: source.kind,
        id: source.id,
        inputs: Object.freeze(source.inputs.map(stack2)),
        outputs
      });
    } else throw new TypeError("Invalid station recipe kind.");
    recipes.set(recipe.id, recipe);
  }
  const codec = createStationStateCodec({
    items,
    definitions: input.definitions,
    furnace: createFurnaceDefinitions({ items, recipes: input.furnaceRecipes, fuels: input.fuels })
  });
  const values = Object.freeze([...recipes.values()]);
  return Object.freeze({ codec, recipe: (id2) => recipes.get(id2), listRecipes: () => values });
}

// packages/stdlib/src/server/gameplay/melee-definition-registry.ts
var MAX_MELEE_DEFINITIONS = 64;
var MAX_COMBO_STEPS = 8;
function createMeleeDefinitionRegistry(inputs) {
  if (inputs.length > MAX_MELEE_DEFINITIONS) throw new TypeError("Melee definition registry exceeds its limit.");
  const registered = /* @__PURE__ */ new Map();
  for (const input of inputs) {
    if (!input.id?.trim() || registered.has(input.id))
      throw new TypeError(`Duplicate or empty melee definition: ${input.id}`);
    if (!Number.isFinite(input.range) || input.range <= 0 || !Array.isArray(input.steps) || input.steps.length === 0 || input.steps.length > MAX_COMBO_STEPS)
      throw new TypeError(`Melee definition is invalid: ${input.id}`);
    const steps = input.steps.map((value) => {
      if (!Number.isFinite(value.damage) || value.damage <= 0 || !Number.isFinite(value.windupSeconds) || value.windupSeconds < 0 || !Number.isFinite(value.hitSeconds) || value.hitSeconds <= 0 || !Number.isFinite(value.recoverySeconds) || value.recoverySeconds < 0)
        throw new TypeError(`Melee step is invalid: ${input.id}`);
      return Object.freeze({ ...value });
    });
    registered.set(input.id, Object.freeze({ id: input.id, range: input.range, steps: Object.freeze(steps) }));
  }
  const values = Object.freeze([...registered.values()]);
  return Object.freeze({ get: (id2) => registered.get(id2), list: () => values });
}

// packages/stdlib/src/server/gameplay/combat-runtime.ts
var defaultRegistry = createMeleeDefinitionRegistry([]);
var listMeleeDefinitions = () => defaultRegistry.list();

// packages/stdlib/src/server/gameplay/recipe-registry.ts
function createRecipeRegistry(inputs, items) {
  const registered = /* @__PURE__ */ new Map();
  for (const source of inputs) {
    if (!source.id?.trim() || registered.has(source.id)) throw new TypeError(`Duplicate or empty recipe: ${source.id}`);
    if (!Array.isArray(source.inputs) || source.inputs.length === 0 || !Array.isArray(source.outputs) || source.outputs.length === 0)
      throw new TypeError(`Recipe inputs and outputs are required: ${source.id}`);
    const freezeStacks = (stacks, side) => {
      const seen = /* @__PURE__ */ new Set();
      return Object.freeze(
        stacks.map((stack2) => {
          const normalized = items.normalizeStack(stack2);
          if (seen.has(normalized.itemId))
            throw new TypeError(`Duplicate ${side} item in recipe ${source.id}: ${normalized.itemId}`);
          seen.add(normalized.itemId);
          return Object.freeze(normalized);
        })
      );
    };
    registered.set(
      source.id,
      Object.freeze({
        id: source.id,
        inputs: freezeStacks(source.inputs, "input"),
        outputs: freezeStacks(source.outputs, "output")
      })
    );
  }
  const values = Object.freeze([...registered.values()]);
  return Object.freeze({ items, get: (id2) => registered.get(id2), list: () => values });
}
var defaultRecipeRegistry = createRecipeRegistry([], defaultItemDefinitionRegistry);

// packages/stdlib/src/server/gameplay/actor-profile.ts
var BEHAVIORS = [
  "idle",
  "wander",
  "seek-food",
  "flee",
  "chase",
  "attack",
  "routine-home",
  "routine-work"
];
var finitePositive = (value, label) => {
  if (!Number.isFinite(value) || value <= 0) throw new TypeError(`${label} must be positive.`);
  return value;
};
var freezeStack2 = (items, value) => {
  const stack2 = items.normalizeStack(value);
  return Object.freeze({
    ...stack2,
    ...stack2.instance ? { instance: Object.freeze({ ...stack2.instance }) } : {}
  });
};
function createActorProfileRegistry(inputs, items, meleeDefinitions, defaultPlayerMeleeDefinitionId, starterEcology) {
  const melee = new Set(meleeDefinitions.map(({ id: id2 }) => id2));
  const profiles = /* @__PURE__ */ new Map();
  for (const input of inputs) {
    if (!isActorArchetype(input.archetype) || profiles.has(input.archetype))
      throw new TypeError(`Duplicate or invalid actor profile: ${String(input.archetype)}`);
    if (input.entityType !== "creature" && input.entityType !== "npc")
      throw new TypeError(`Actor profile entity type is invalid: ${input.archetype}`);
    if (!Number.isSafeInteger(input.maxHealth) || input.maxHealth <= 0)
      throw new TypeError(`Actor profile max health is invalid: ${input.archetype}`);
    if (input.initialBehavior !== void 0 && !BEHAVIORS.includes(input.initialBehavior))
      throw new TypeError(`Actor profile behavior is invalid: ${input.archetype}`);
    if (input.meleeDefinitionId !== void 0 && !melee.has(input.meleeDefinitionId))
      throw new TypeError(`Actor profile references unknown melee definition: ${input.meleeDefinitionId}`);
    if (input.spawnWeight !== void 0 && (!Number.isSafeInteger(input.spawnWeight) || input.spawnWeight <= 0))
      throw new TypeError("Actor profile spawn weight is invalid: " + input.archetype);
    const deathDrop = input.deathDrop ? freezeStack2(items, input.deathDrop) : void 0;
    profiles.set(
      input.archetype,
      Object.freeze({
        archetype: input.archetype,
        entityType: input.entityType,
        maxHealth: input.maxHealth,
        navigation: Object.freeze({
          speed: finitePositive(input.navigation.speed, `${input.archetype} speed`),
          perceptionRange: finitePositive(input.navigation.perceptionRange, `${input.archetype} perception range`)
        }),
        ...input.initialBehavior !== void 0 ? { initialBehavior: input.initialBehavior } : {},
        ...input.meleeDefinitionId !== void 0 ? { meleeDefinitionId: input.meleeDefinitionId } : {},
        ...deathDrop ? { deathDrop } : {},
        ...input.disposition ? { disposition: input.disposition } : {},
        ...input.spawnWeight ? { spawnWeight: input.spawnWeight } : {},
        ...input.spawnBiomes ? { spawnBiomes: Object.freeze([...input.spawnBiomes]) } : {}
      })
    );
  }
  if (defaultPlayerMeleeDefinitionId !== void 0 && !melee.has(defaultPlayerMeleeDefinitionId))
    throw new TypeError(`Default player melee references unknown definition: ${defaultPlayerMeleeDefinitionId}`);
  let ecology = null;
  if (starterEcology !== void 0) {
    if (starterEcology.version !== 1) throw new TypeError("Starter ecology version is invalid.");
    const slots = /* @__PURE__ */ new Set();
    const actors = starterEcology.actors.map((actor) => {
      if (!["forager", "predator", "resident"].includes(actor.slot) || slots.has(actor.slot))
        throw new TypeError(`Duplicate or invalid starter ecology slot: ${String(actor.slot)}`);
      slots.add(actor.slot);
      if (!actor.idPrefix.trim() || !profiles.has(actor.archetype))
        throw new TypeError(`Starter ecology actor is invalid: ${actor.idPrefix}`);
      if (actor.hunger !== void 0 && (!Number.isFinite(actor.hunger) || actor.hunger < 0 || actor.hunger > 100))
        throw new TypeError(`Starter ecology hunger is invalid: ${actor.idPrefix}`);
      return Object.freeze({ ...actor });
    });
    if (slots.size !== 3) throw new TypeError("Starter ecology requires one actor in each bounded layout slot.");
    ecology = Object.freeze({
      version: 1,
      actors: Object.freeze(actors),
      initialItem: freezeStack2(items, starterEcology.initialItem)
    });
  }
  const values = Object.freeze([...profiles.values()]);
  const require2 = (archetype) => {
    const profile = profiles.get(archetype);
    if (!profile) throw new RangeError(`Unknown actor profile: ${archetype}`);
    return profile;
  };
  return Object.freeze({
    get: (archetype) => profiles.get(archetype),
    require: require2,
    list: () => values,
    defaultPlayerMeleeDefinitionId: defaultPlayerMeleeDefinitionId ?? null,
    starterEcology: ecology
  });
}
function createLegacyActorProfileRegistry(items, meleeDefinitions) {
  return createActorProfileRegistry([], items, meleeDefinitions);
}

// packages/stdlib/src/server/gameplay/voxel-gameplay.ts
function createVoxelGameplayRegistry(definitions3 = []) {
  const entries = /* @__PURE__ */ new Map();
  for (const definition2 of definitions3) {
    if (!Number.isSafeInteger(definition2.voxel) || definition2.voxel < 0 || definition2.voxel > 65535)
      throw new TypeError(`Voxel gameplay identity is invalid: ${String(definition2.voxel)}`);
    if (entries.has(definition2.voxel)) throw new TypeError(`Duplicate voxel gameplay definition: ${definition2.voxel}`);
    entries.set(definition2.voxel, Object.freeze({ ...definition2 }));
  }
  const values = Object.freeze([...entries.values()]);
  return Object.freeze({
    get: (voxel2) => entries.get(voxel2),
    require: (voxel2) => {
      const definition2 = entries.get(voxel2);
      if (!definition2) throw new RangeError(`No voxel gameplay definition is registered: ${voxel2}`);
      return definition2;
    },
    list: () => values
  });
}

// packages/stdlib/src/server/gameplay/gameplay-content.ts
function createGameplayContent(input) {
  const melee = createMeleeDefinitionRegistry(input.meleeDefinitions);
  const items = createItemDefinitionRegistry(input.items, (id2) => melee.get(id2) !== void 0);
  const recipes = createRecipeRegistry(input.recipes, items);
  const actorProfiles = input.actorProfiles === void 0 && input.defaultPlayerMeleeDefinitionId === void 0 && input.starterEcology === void 0 ? createLegacyActorProfileRegistry(items, melee.list()) : createActorProfileRegistry(
    input.actorProfiles ?? [],
    items,
    melee.list(),
    input.defaultPlayerMeleeDefinitionId,
    input.starterEcology
  );
  return Object.freeze({
    items,
    recipes,
    crafting: input.crafting === void 0 ? shapelessCraftingProvider : input.crafting === null ? null : freezeCraftingProvider(input.crafting),
    meleeDefinitions: melee.list(),
    actorProfiles,
    voxelGameplay: createVoxelGameplayRegistry(input.voxelGameplayDefinitions),
    voxelSemantics: createVoxelSemanticsRegistry(input.voxelSemanticsDefinitions ?? []),
    ...input.stations ? { stations: createStationContent(input.stations, items) } : {}
  });
}
var defaultGameplayContent = Object.freeze({
  items: defaultItemDefinitionRegistry,
  recipes: defaultRecipeRegistry,
  crafting: shapelessCraftingProvider,
  meleeDefinitions: listMeleeDefinitions(),
  actorProfiles: createActorProfileRegistry([], defaultItemDefinitionRegistry, listMeleeDefinitions()),
  voxelGameplay: createVoxelGameplayRegistry(),
  voxelSemantics: createVoxelSemanticsRegistry()
});

// packages/stdlib/src/server/composition/checkpoint-identity.ts
var INVENTORY_POINTER_PREDECESSOR_OVERWORLD = Object.freeze({
  manifestDigest: "05bc5e57bb6cfd4ed0e2da821f8b6e803bb7e3676453988a131a4b8524c066dd",
  entryDigest: "4a773fe7225f13ef018def0a930b469aa82e558fdebc5172b7ef602ed8e148e2"
});
var NPC_COMPOSABLE_PREDECESSOR_OVERWORLD = Object.freeze({
  manifestDigest: "05bc5e57bb6cfd4ed0e2da821f8b6e803bb7e3676453988a131a4b8524c066dd",
  entryDigest: "7583373d53f9cb3f2447bf40478eb9f8d817adc80060effa385633ecaacf5e6a"
});
var KERNEL_MIGRATION_PREDECESSOR_OVERWORLD = Object.freeze({
  manifestDigest: "e3c199e87d101672c1635d481771972edbf39deb43c336063ab3753d0b01bb89",
  entryDigest: "924d61fc72f253c85e191caa79f1c7ff51f83bc6237ad613a7c0c5595c2c169f"
});
var NAMESPACE_ID4 = /^[a-z0-9][a-z0-9._-]*:[a-z0-9][a-z0-9._/-]*$/;
var RESOURCE_ID = /^[a-z0-9][a-z0-9._:-]*$/;
var STORAGE_ID = /^[a-z0-9][a-z0-9._-]*(?::[a-z0-9][a-z0-9._/-]*)?$/;
var EXACT_VERSION3 = /^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:-[0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*)?(?:\+[0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*)?$/;
var SHA256 = /^[a-f0-9]{64}$/i;
var WORLD_OPERATIONS = /* @__PURE__ */ new Set(["read", "execute", "write", "control", "export", "restore"]);
var MAX_IDENTITY_ROWS = 4096;
function canonicalCompositionCheckpointIdentity(input) {
  let budget = 1048576;
  const active = /* @__PURE__ */ new Set();
  const visit = (value, depth) => {
    if (--budget < 0 || depth > 32) throw new TypeError("Composition identity exceeds data limits.");
    if (value === null || typeof value === "boolean") return JSON.stringify(value);
    if (typeof value === "string") {
      budget -= value.length;
      return JSON.stringify(value);
    }
    if (typeof value === "number" && Number.isFinite(value)) return JSON.stringify(value);
    if (typeof value !== "object" || value === null || active.has(value))
      throw new TypeError("Composition identity must be JSON data.");
    const prototype = Object.getPrototypeOf(value);
    if (prototype !== Object.prototype && prototype !== null && !Array.isArray(value))
      throw new TypeError("Invalid composition identity object.");
    active.add(value);
    const keys = Object.keys(value).sort();
    if (Reflect.ownKeys(value).length !== keys.length + (Array.isArray(value) ? 1 : 0))
      throw new TypeError("Composition identity contains unsupported fields.");
    let result2;
    if (Array.isArray(value)) {
      if (keys.length !== value.length) throw new TypeError("Composition identity arrays must be dense.");
      const entries = [];
      for (let index = 0; index < value.length; index += 1) {
        const descriptor = Object.getOwnPropertyDescriptor(value, String(index));
        if (!descriptor) throw new TypeError("Composition identity arrays must be dense.");
        if (!("value" in descriptor)) throw new TypeError("Composition identity accessors are forbidden.");
        entries.push(visit(descriptor.value, depth + 1));
      }
      result2 = `[${entries.join(",")}]`;
    } else {
      const entries = keys.map((key2) => {
        const descriptor = Object.getOwnPropertyDescriptor(value, key2);
        if (!descriptor || !("value" in descriptor))
          throw new TypeError("Composition identity accessors are forbidden.");
        budget -= key2.length;
        return [key2, descriptor.value];
      });
      result2 = `{${entries.filter(([, entry]) => entry !== void 0).map(([key2, entry]) => `${JSON.stringify(key2)}:${visit(entry, depth + 1)}`).join(",")}}`;
    }
    active.delete(value);
    return result2;
  };
  const result = visit(input, 0);
  if (budget < 0) throw new TypeError("Composition identity exceeds data limits.");
  return result;
}
var record = (raw, label) => {
  if (!raw || typeof raw !== "object" || Array.isArray(raw)) throw new TypeError(`${label} is invalid.`);
  return raw;
};
var exactKeys = (raw, required, optional = []) => {
  const allowed = /* @__PURE__ */ new Set([...required, ...optional]);
  if (required.some((key2) => !Object.hasOwn(raw, key2)) || Reflect.ownKeys(raw).some((key2) => typeof key2 !== "string" || !allowed.has(key2)))
    throw new TypeError("Composition checkpoint identity has an invalid shape.");
};
var dense = (raw, label) => {
  if (!Array.isArray(raw) || raw.length > MAX_IDENTITY_ROWS || Reflect.ownKeys(raw).length !== raw.length + 1)
    throw new TypeError(`${label} must be a bounded dense array.`);
  return raw;
};
var id = (raw, label) => {
  if (typeof raw !== "string" || raw.length > 256 || !NAMESPACE_ID4.test(raw))
    throw new TypeError(`${label} is invalid.`);
  return raw;
};
var version = (raw, label) => {
  if (typeof raw !== "string" || raw.length > 128 || !EXACT_VERSION3.test(raw))
    throw new TypeError(`${label} is invalid.`);
  return raw;
};
var string = (raw, label) => {
  if (typeof raw !== "string" || !raw || raw.length > 4096) throw new TypeError(`${label} is invalid.`);
  return raw;
};
var identityRow = (raw, required, optional = []) => {
  const value = record(raw, "Composition checkpoint identity row");
  exactKeys(value, required, optional);
  return value;
};
var validateOperationNames = (raw, label) => {
  const operations = dense(raw, label);
  if (!operations.length || operations.some((operation) => !WORLD_OPERATIONS.has(String(operation))))
    throw new TypeError(`${label} is invalid.`);
  if (new Set(operations).size !== operations.length) throw new TypeError(`${label} contains duplicates.`);
};
var validateDependencyIds = (raw, label) => {
  const dependencies = dense(raw, label).map((dependency) => id(dependency, label));
  if (new Set(dependencies).size !== dependencies.length) throw new TypeError(`${label} contains duplicates.`);
};
var uniqueRows = (raw, keyFor, label) => {
  const keys = raw.map((row) => keyFor(record(row, label)));
  if (new Set(keys).size !== keys.length) throw new TypeError(`${label} contains duplicates.`);
};
var validateDefinitionMap = (raw) => {
  const value = record(raw, "Composition checkpoint definition map");
  const lists = [
    "stateCodecs",
    "operations",
    "rules",
    "packs",
    "modules",
    "capabilities",
    "resources",
    "items",
    "recipes",
    "systems",
    "lifecycles"
  ];
  exactKeys(value, lists, ["schemaVersion", "voxels"]);
  if (value.schemaVersion !== void 0 && value.schemaVersion !== 2)
    throw new TypeError("Composition checkpoint definition map version is invalid.");
  for (const key2 of [...lists, ...value.voxels === void 0 ? [] : ["voxels"]])
    dense(value[key2], `Composition checkpoint ${key2}`);
  for (const rawRow of value.stateCodecs) {
    const row = identityRow(rawRow, ["id", "version", "resource", "moduleId"], ["partitions"]);
    id(row.id, "State codec id");
    version(row.version, "State codec version");
    string(row.resource, "State codec resource");
    id(row.moduleId, "State codec module id");
    if (row.partitions !== void 0 && (!Number.isSafeInteger(row.partitions) || row.partitions < 1))
      throw new TypeError("State codec partitions are invalid.");
  }
  for (const rawRow of value.operations) {
    const row = identityRow(rawRow, ["id", "resource", "moduleId", "executionKind"]);
    id(row.id, "Operation id");
    string(row.resource, "Operation resource");
    id(row.moduleId, "Operation module id");
    if (row.executionKind !== "actor" && row.executionKind !== "system")
      throw new TypeError("Operation execution kind is invalid.");
  }
  for (const rawRow of value.rules) {
    const row = identityRow(rawRow, ["id", "operationId", "moduleId", "stage"]);
    id(row.id, "Rule id");
    id(row.operationId, "Rule operation id");
    id(row.moduleId, "Rule module id");
    if (row.stage !== "before" && row.stage !== "after") throw new TypeError("Rule stage is invalid.");
  }
  for (const rawRow of value.packs) {
    const row = identityRow(rawRow, ["id", "version"]);
    id(row.id, "Pack definition id");
    version(row.version, "Pack definition version");
  }
  for (const rawRow of value.modules) {
    const row = identityRow(rawRow, ["id", "version", "packId"]);
    id(row.id, "Module id");
    version(row.version, "Module version");
    id(row.packId, "Module Pack id");
  }
  for (const rawRow of value.capabilities) {
    const row = identityRow(rawRow, ["id", "version", "moduleId"], ["definitionIdentity"]);
    id(row.id, "Capability id");
    version(row.version, "Capability version");
    id(row.moduleId, "Capability module id");
    if (row.definitionIdentity !== void 0) string(row.definitionIdentity, "Capability definition identity");
  }
  for (const rawRow of value.resources) {
    const row = identityRow(rawRow, ["id", "operations"]);
    if (typeof row.id !== "string" || !RESOURCE_ID.test(row.id)) throw new TypeError("Resource id is invalid.");
    validateOperationNames(row.operations, "Resource operations");
  }
  for (const key2 of ["items", "recipes"])
    for (const rawRow of value[key2]) {
      const row = identityRow(rawRow, ["id", "storageId"]);
      id(row.id, `${key2} id`);
      if (typeof row.storageId !== "string" || !STORAGE_ID.test(row.storageId))
        throw new TypeError(`${key2} storage id is invalid.`);
    }
  for (const rawRow of value.voxels ?? []) {
    const row = identityRow(rawRow, ["id", "storageId"]);
    id(row.id, "Voxel id");
    if (!Number.isSafeInteger(row.storageId) || row.storageId < 0 || row.storageId > 65535)
      throw new TypeError("Voxel storage id is invalid.");
  }
  for (const rawRow of value.systems) {
    const row = identityRow(rawRow, ["moduleId", "definition"]);
    id(row.moduleId, "System module id");
    const definition2 = identityRow(
      row.definition,
      ["id", "operationId", "cadence", "before", "after"],
      ["intervalSeconds"]
    );
    id(definition2.id, "System id");
    id(definition2.operationId, "System operation id");
    if (definition2.cadence !== "interval" && definition2.cadence !== "every-advance")
      throw new TypeError("System cadence is invalid.");
    validateDependencyIds(definition2.before, "System before dependencies");
    validateDependencyIds(definition2.after, "System after dependencies");
    if (definition2.intervalSeconds !== void 0 && (typeof definition2.intervalSeconds !== "number" || !Number.isFinite(definition2.intervalSeconds)))
      throw new TypeError("System interval is invalid.");
  }
  for (const rawRow of value.lifecycles) {
    const row = identityRow(rawRow, ["moduleId", "definition"]);
    id(row.moduleId, "Lifecycle module id");
    const definition2 = identityRow(row.definition, [], ["startOperationId", "stopOperationId"]);
    if (definition2.startOperationId === void 0 && definition2.stopOperationId === void 0)
      throw new TypeError("Lifecycle operation is missing.");
    if (definition2.startOperationId !== void 0) id(definition2.startOperationId, "Lifecycle start operation id");
    if (definition2.stopOperationId !== void 0) id(definition2.stopOperationId, "Lifecycle stop operation id");
  }
  for (const key2 of [
    "stateCodecs",
    "operations",
    "rules",
    "packs",
    "modules",
    "capabilities",
    "resources",
    "items",
    "recipes",
    "voxels"
  ])
    if (value[key2])
      uniqueRows(value[key2], (row) => String(row.id), `Composition checkpoint ${key2}`);
  uniqueRows(
    value.systems,
    (row) => String(record(row.definition, "System definition").id),
    "Composition checkpoint systems"
  );
  uniqueRows(
    value.lifecycles,
    (row) => String(row.moduleId),
    "Composition checkpoint lifecycles"
  );
};
var deepFreeze = (value) => {
  if (value && typeof value === "object") {
    for (const child of Object.values(value)) deepFreeze(child);
    Object.freeze(value);
  }
  return value;
};
function cloneCompositionCheckpointIdentity(raw) {
  const value = JSON.parse(canonicalCompositionCheckpointIdentity(raw));
  exactKeys(value, ["version", "playbookId", "packLock", "definitionMap"]);
  if (value.version !== 1) throw new TypeError("Composition checkpoint identity version is invalid.");
  id(value.playbookId, "Composition checkpoint Playbook id");
  for (const rawPack of dense(value.packLock, "Composition checkpoint Pack lock")) {
    const pack2 = record(rawPack, "Composition checkpoint Pack");
    exactKeys(pack2, ["id", "version", "integrity"]);
    id(pack2.id, "Composition checkpoint Pack id");
    version(pack2.version, "Composition checkpoint Pack version");
    const integrity = record(pack2.integrity, "Composition checkpoint Pack integrity");
    exactKeys(integrity, ["algorithm", "manifestDigest", "entryDigest", "resources"]);
    if (integrity.algorithm !== "sha256" || !SHA256.test(String(integrity.manifestDigest)) || !SHA256.test(String(integrity.entryDigest)))
      throw new TypeError("Composition checkpoint Pack integrity is invalid.");
    for (const rawResource of dense(integrity.resources, "Composition checkpoint Pack resources")) {
      const resource = record(rawResource, "Composition checkpoint Pack resource");
      exactKeys(resource, ["path", "digest"]);
      string(resource.path, "Composition checkpoint Pack resource path");
      if (!SHA256.test(String(resource.digest)))
        throw new TypeError("Composition checkpoint Pack resource digest is invalid.");
    }
  }
  validateDefinitionMap(value.definitionMap);
  return deepFreeze(value);
}

// packages/stdlib/src/server/gameplay/gameplay-snapshot-migration.ts
var MAX_GAMEPLAY_SNAPSHOT_PREDECESSORS = 16;
var dataProperty = (owner, key2, label) => {
  const descriptor = Object.getOwnPropertyDescriptor(owner, key2);
  if (!descriptor) throw new TypeError(`${label} must be a bounded dense array.`);
  if (!("value" in descriptor)) throw new TypeError(`${label} accessors are forbidden.`);
  return descriptor.value;
};
var denseDataArray = (raw, maximum, label) => {
  if (!Array.isArray(raw)) throw new TypeError(`${label} must be a bounded dense array.`);
  const length2 = dataProperty(raw, "length", label);
  if (!Number.isSafeInteger(length2) || length2 < 0 || length2 > maximum)
    throw new TypeError(`${label} must be a bounded dense array.`);
  const values = [];
  for (let index = 0; index < length2; index += 1) values.push(dataProperty(raw, String(index), label));
  if (Reflect.ownKeys(raw).length !== values.length + 1) throw new TypeError(`${label} must be a bounded dense array.`);
  return values;
};
var predecessorFields = (raw) => {
  if (!raw || typeof raw !== "object" || Array.isArray(raw))
    throw new TypeError("Gameplay snapshot predecessor is invalid.");
  const keys = Reflect.ownKeys(raw);
  if (keys.length !== 2 || !keys.includes("gameplayVersions") || !keys.includes("identity"))
    throw new TypeError("Gameplay snapshot predecessor has an invalid shape.");
  return {
    gameplayVersions: dataProperty(raw, "gameplayVersions", "Gameplay snapshot predecessor"),
    identity: dataProperty(raw, "identity", "Gameplay snapshot predecessor")
  };
};
function defineGameplaySnapshotPredecessorsV1(raw = []) {
  const entries = denseDataArray(raw, MAX_GAMEPLAY_SNAPSHOT_PREDECESSORS, "Gameplay snapshot predecessors");
  const identities = /* @__PURE__ */ new Set();
  return Object.freeze(
    entries.map((rawEntry) => {
      const entry = predecessorFields(rawEntry);
      const versionValues = denseDataArray(entry.gameplayVersions, 4, "Gameplay snapshot predecessor versions");
      if (versionValues.length === 0)
        throw new TypeError("Gameplay snapshot predecessor versions must be a non-empty dense array.");
      if (versionValues.some((value) => value !== 1 && value !== 2 && value !== 3 && value !== 4))
        throw new TypeError("Gameplay snapshot predecessor version is invalid.");
      const versions = versionValues.slice().sort((left, right) => left - right);
      if (new Set(versions).size !== versions.length)
        throw new TypeError("Gameplay snapshot predecessor versions must be unique.");
      const identity5 = cloneCompositionCheckpointIdentity(entry.identity);
      const key2 = canonicalCompositionCheckpointIdentity(identity5);
      if (identities.has(key2)) throw new TypeError("Gameplay snapshot predecessor identity is duplicated.");
      identities.add(key2);
      return Object.freeze({
        gameplayVersions: Object.freeze(versions),
        identity: identity5
      });
    })
  );
}
function matchesGameplaySnapshotPredecessorV1(predecessors, gameplayVersion, identity5) {
  const candidate2 = canonicalCompositionCheckpointIdentity(cloneCompositionCheckpointIdentity(identity5));
  return predecessors.some(
    (predecessor) => predecessor.gameplayVersions.includes(gameplayVersion) && canonicalCompositionCheckpointIdentity(predecessor.identity) === candidate2
  );
}
var GAMEPLAY_SNAPSHOT_MIGRATION_CAPABILITY = "seedlands:gameplay-snapshot-migration";

// packages/stdlib/src/server/gameplay/modules/content-capabilities.ts
var ITEMS_CAPABILITY = "seedlands:items";
var RECIPES_CAPABILITY = "seedlands:recipes";
var ACTOR_PROFILES_CAPABILITY = "seedlands:actor-profiles";
var MELEE_DEFINITIONS_CAPABILITY = "seedlands:melee-definitions";
var STATION_CONTENT_CAPABILITY = "seedlands:station-content";
var CONTENT_CRAFTING_CAPABILITY = "seedlands:content-crafting";
var VOXEL_SEMANTICS_CAPABILITY = "seedlands:voxel-semantics";
var GAMEPLAY_CONTENT_CAPABILITIES = Object.freeze([
  ITEMS_CAPABILITY,
  RECIPES_CAPABILITY,
  ACTOR_PROFILES_CAPABILITY,
  MELEE_DEFINITIONS_CAPABILITY,
  STATION_CONTENT_CAPABILITY,
  CONTENT_CRAFTING_CAPABILITY,
  VOXEL_SEMANTICS_CAPABILITY
]);
var assemble = (read) => {
  const items = read(ITEMS_CAPABILITY);
  const recipes = read(RECIPES_CAPABILITY);
  const actorProfiles = read(ACTOR_PROFILES_CAPABILITY);
  const meleeDefinitions = read(MELEE_DEFINITIONS_CAPABILITY);
  const stations = read(STATION_CONTENT_CAPABILITY);
  const crafting = read(CONTENT_CRAFTING_CAPABILITY);
  const voxelSemantics = read(VOXEL_SEMANTICS_CAPABILITY);
  return Object.freeze({
    items,
    recipes,
    actorProfiles,
    meleeDefinitions,
    crafting,
    voxelGameplay: createVoxelGameplayRegistry(),
    voxelSemantics,
    ...stations ? { stations } : {}
  });
};
var gameplayContentFromRegistration = (api) => assemble((id2) => api.requireCapability(id2));
var contentCapabilityContracts = () => GAMEPLAY_CONTENT_CAPABILITIES.map((id2) => Object.freeze({ id: id2, version: "1.0.0" }));

// packages/stdlib/src/server/gameplay/modules/content-module.ts
function defineContentModule(input) {
  return Object.freeze({
    descriptor: {
      id: input.moduleId,
      version: "1.0.0",
      requires: input.craftingProvider ? [{ id: CRAFTING_CAPABILITY, version: "1.0.0" }] : [],
      provides: [
        ...contentCapabilityContracts(),
        ...input.snapshotMigration ? [{ id: GAMEPLAY_SNAPSHOT_MIGRATION_CAPABILITY, version: "1.0.0" }] : []
      ]
    },
    register(api) {
      const crafting = input.craftingProvider ? freezeCraftingProvider(api.requireCapability(CRAFTING_CAPABILITY)) : null;
      input.items.forEach(api.registerItem);
      (input.recipes ?? []).forEach(api.registerRecipe);
      (input.voxels ?? []).forEach(api.registerVoxel);
      (input.actorProfiles ?? []).forEach(api.registerActorProfile);
      let content;
      const resolve = () => {
        if (content) return content;
        const definitions3 = api.readContentDefinitions();
        const storage = new Map(definitions3.items.map((item) => [item.id, item.storageId ?? item.id]));
        const stacks = (entries) => entries.map((entry) => {
          const itemId = storage.get(entry.itemId);
          if (!itemId) throw new TypeError(`Recipe references unknown item: ${entry.itemId}`);
          return {
            itemId,
            count: entry.count,
            ...entry.instance !== void 0 ? { instance: { ...entry.instance } } : {}
          };
        });
        content = createGameplayContent({
          items: definitions3.items.map((item) => ({
            id: item.storageId ?? item.id,
            name: item.name,
            stackLimit: item.stackLimit,
            itemType: item.itemType ?? "resource",
            ...item.durability ? { durability: item.durability } : {},
            capabilities: item.capabilities ?? []
          })),
          recipes: definitions3.recipes.map((recipe) => ({
            id: recipe.storageId ?? recipe.id,
            inputs: stacks(recipe.inputs),
            outputs: stacks(recipe.outputs)
          })),
          meleeDefinitions: input.meleeDefinitions,
          voxelSemanticsDefinitions: definitions3.voxels,
          crafting,
          actorProfiles: definitions3.actorProfiles.map((profile) => ({
            ...profile,
            ...profile.deathDrop ? { deathDrop: stacks([profile.deathDrop])[0] } : {}
          })),
          ...input.defaultPlayerMeleeDefinitionId ? { defaultPlayerMeleeDefinitionId: input.defaultPlayerMeleeDefinitionId } : {},
          ...input.starterEcology ? {
            starterEcology: {
              ...input.starterEcology,
              initialItem: stacks([input.starterEcology.initialItem])[0]
            }
          } : {},
          ...input.stations ? {
            stations: {
              definitions: input.stations.definitions,
              recipes: input.stations.recipes.map(
                (recipe) => recipe.kind === "shaped" ? {
                  ...recipe,
                  pattern: recipe.pattern.map((value) => value === null ? null : stacks([value])[0]),
                  outputs: stacks(recipe.outputs)
                } : { ...recipe, inputs: stacks(recipe.inputs), outputs: stacks(recipe.outputs) }
              ),
              furnaceRecipes: input.stations.furnaceRecipes.map((recipe) => ({
                ...recipe,
                input: stacks([recipe.input])[0],
                output: stacks([recipe.output])[0]
              })),
              fuels: input.stations.fuels.map((fuel) => ({
                ...fuel,
                itemId: stacks([{ itemId: fuel.itemId, count: 1 }])[0].itemId
              }))
            }
          } : {}
        });
        return content;
      };
      const items = Object.freeze({
        get: (id2) => resolve().items.get(id2),
        require: (id2) => resolve().items.require(id2),
        has: (id2) => resolve().items.has(id2),
        list: () => resolve().items.list(),
        capability: (id2, type) => resolve().items.capability(id2, type),
        normalizeStack: (value, options) => resolve().items.normalizeStack(value, options),
        assertStack: (stack2) => resolve().items.assertStack(stack2)
      });
      api.provideCapability(ITEMS_CAPABILITY, items);
      api.provideCapability(
        VOXEL_SEMANTICS_CAPABILITY,
        Object.freeze({
          get: (storageId) => resolve().voxelSemantics.get(storageId),
          require: (storageId) => resolve().voxelSemantics.require(storageId),
          getById: (id2) => resolve().voxelSemantics.getById(id2),
          list: () => resolve().voxelSemantics.list()
        })
      );
      api.provideCapability(
        RECIPES_CAPABILITY,
        Object.freeze({
          get: (id2) => resolve().recipes.get(id2),
          list: () => resolve().recipes.list(),
          get items() {
            return items;
          }
        })
      );
      api.provideCapability(
        ACTOR_PROFILES_CAPABILITY,
        Object.freeze({
          get: (id2) => resolve().actorProfiles.get(id2),
          require: (id2) => resolve().actorProfiles.require(id2),
          list: () => resolve().actorProfiles.list(),
          get defaultPlayerMeleeDefinitionId() {
            return resolve().actorProfiles.defaultPlayerMeleeDefinitionId;
          },
          get starterEcology() {
            return resolve().actorProfiles.starterEcology;
          }
        })
      );
      const meleeDefinitions = [];
      api.provideCapability(MELEE_DEFINITIONS_CAPABILITY, meleeDefinitions);
      api.provideCapability(
        STATION_CONTENT_CAPABILITY,
        input.stations ? (() => {
          const codec = Object.freeze({
            items,
            get furnace() {
              return resolve().stations.codec.furnace;
            },
            get definitions() {
              return resolve().stations.codec.definitions;
            },
            definition: (kind) => resolve().stations.codec.definition(kind),
            kindForVoxel: (voxel2) => resolve().stations.codec.kindForVoxel(voxel2),
            create: (entityId, kind) => resolve().stations.codec.create(entityId, kind),
            decode: (raw, expectedEntityId) => resolve().stations.codec.decode(raw, expectedEntityId)
          });
          return Object.freeze({
            codec,
            recipe: (id2) => resolve().stations.recipe(id2),
            listRecipes: () => resolve().stations.listRecipes()
          });
        })() : null
      );
      api.provideCapability(
        CONTENT_CRAFTING_CAPABILITY,
        Object.freeze({
          version: 1,
          match: (request) => resolve().crafting?.match(request) ?? null
        })
      );
      if (input.snapshotMigration)
        api.provideCapability(GAMEPLAY_SNAPSHOT_MIGRATION_CAPABILITY, input.snapshotMigration);
      api.onDefinitionsReady(() => {
        meleeDefinitions.push(...resolve().meleeDefinitions);
        Object.freeze(meleeDefinitions);
      });
    }
  });
}

// packages/kernel/src/spatial/provider.ts
var KERNEL_CHUNK_SIZE = 32;
var KERNEL_CHUNK_VOXEL_COUNT = KERNEL_CHUNK_SIZE ** 3;
var assertIdentityFields = (identity5) => {
  if (!identity5 || !identity5.id?.trim() || !identity5.implementationVersion?.trim() || !identity5.configurationIdentity?.trim() || !identity5.artifactIdentity?.trim())
    throw new TypeError("World-generation provider identity is incomplete.");
  if (!Array.isArray(identity5.supportedGeneratorVersions) || identity5.supportedGeneratorVersions.length === 0 || identity5.supportedGeneratorVersions.some((version2) => !Number.isSafeInteger(version2) || version2 < 0) || new Set(identity5.supportedGeneratorVersions).size !== identity5.supportedGeneratorVersions.length)
    throw new TypeError("World-generation provider versions are invalid.");
};
function freezeWorldgenProviderIdentity(identity5) {
  assertIdentityFields(identity5);
  return Object.freeze({
    ...identity5,
    supportedGeneratorVersions: Object.freeze([...identity5.supportedGeneratorVersions].sort((a, b) => a - b))
  });
}
function worldgenProviderIdentityKey(identity5) {
  const frozen = freezeWorldgenProviderIdentity(identity5);
  return JSON.stringify({
    id: frozen.id,
    implementationVersion: frozen.implementationVersion,
    configurationIdentity: frozen.configurationIdentity,
    supportedGeneratorVersions: frozen.supportedGeneratorVersions,
    artifactIdentity: frozen.artifactIdentity
  });
}
function freezeWorldgenProvider(provider) {
  if (typeof provider?.generate !== "function" || typeof provider?.sampleVoxel !== "function")
    throw new TypeError("World-generation provider executable ports are incomplete.");
  if (provider.acceptsStoredIdentity !== void 0 && typeof provider.acceptsStoredIdentity !== "function")
    throw new TypeError("World-generation provider compatibility port is invalid.");
  return Object.freeze({
    identity: freezeWorldgenProviderIdentity(provider.identity),
    generate: provider.generate,
    sampleVoxel: provider.sampleVoxel,
    ...provider.acceptsStoredIdentity ? { acceptsStoredIdentity: provider.acceptsStoredIdentity } : {}
  });
}

// packages/stdlib/src/server/worldgen/standard-worldgen-module.ts
var WORLDGEN_PROVIDER_CAPABILITY = "seedlands:worldgen-provider";
function defineStandardWorldgenModule(input) {
  const provider = freezeWorldgenProvider(input.provider);
  return Object.freeze({
    descriptor: {
      id: input.moduleId,
      version: "1.0.0",
      provides: [
        {
          id: WORLDGEN_PROVIDER_CAPABILITY,
          version: "1.0.0",
          definitionIdentity: worldgenProviderIdentityKey(provider.identity)
        }
      ]
    },
    register(api) {
      api.provideCapability(WORLDGEN_PROVIDER_CAPABILITY, provider);
    }
  });
}

// packages/stdlib/src/server/gameplay/modules/recipe-crafting-module.ts
function defineCraftingProviderModule(input) {
  const provider = freezeCraftingProvider(input.provider);
  return Object.freeze({
    descriptor: {
      id: input.moduleId,
      version: "1.0.0",
      provides: [{ id: CRAFTING_CAPABILITY, version: "1.0.0" }]
    },
    register(api) {
      api.provideCapability(CRAFTING_CAPABILITY, provider);
    }
  });
}
var defineRecipeCraftingModule = () => defineCraftingProviderModule({
  moduleId: "seedlands:recipe-crafting-module",
  provider: shapelessCraftingProvider
});

// packages/stdlib/src/world/voxel-geometry.ts
var MAX_GEOMETRY_DEFINITIONS = MAX_VOXEL_STORAGE_ID + 1;
var MAX_BOXES_PER_VOXEL = 64;
var record2 = (raw, keys, label) => {
  if (!raw || typeof raw !== "object" || Array.isArray(raw)) throw new TypeError(`${label} is invalid.`);
  const prototype = Object.getPrototypeOf(raw);
  if (prototype !== Object.prototype && prototype !== null) throw new TypeError(`${label} must be plain data.`);
  const descriptors = Object.getOwnPropertyDescriptors(raw);
  if (Reflect.ownKeys(descriptors).length !== keys.length) throw new TypeError(`${label} fields are invalid.`);
  for (const key2 of keys) {
    const descriptor = descriptors[key2];
    if (!descriptor?.enumerable || !("value" in descriptor)) throw new TypeError(`${label} fields are invalid.`);
  }
  return raw;
};
var denseArray = (raw, label, minimum, maximum) => {
  if (!Array.isArray(raw) || raw.length < minimum || raw.length > maximum)
    throw new TypeError(`${label} length is invalid.`);
  const keys = Reflect.ownKeys(raw).filter((key2) => key2 !== "length");
  if (keys.length !== raw.length || keys.some((key2, index) => {
    const descriptor = Object.getOwnPropertyDescriptor(raw, key2);
    return key2 !== String(index) || !descriptor?.enumerable || !("value" in descriptor);
  }))
    throw new TypeError(`${label} must be dense and cannot contain extra enumerable properties.`);
  return raw;
};
var vector = (raw, label) => {
  const values = denseArray(raw, label, 3, 3);
  if (values.some((value) => typeof value !== "number" || !Number.isFinite(value) || value < 0 || value > 1))
    throw new TypeError(`${label} must contain finite coordinates within 0..1.`);
  return Object.freeze([values[0], values[1], values[2]]);
};
var geometryBox = (raw, label) => {
  const value = record2(raw, ["min", "max"], label);
  const min = vector(value.min, `${label} minimum`);
  const max = vector(value.max, `${label} maximum`);
  if (min.some((coordinate, axis) => coordinate >= max[axis]))
    throw new TypeError(`${label} must have positive extent.`);
  return Object.freeze({ min, max });
};
var renderBox = (raw, label) => {
  const value = record2(raw, ["min", "max", "material"], label);
  const shape = geometryBox({ min: value.min, max: value.max }, label);
  if (typeof value.material !== "number" || !Number.isSafeInteger(value.material) || value.material < 1 || value.material > MAX_VOXEL_FACE_MATERIAL_ID)
    throw new TypeError(`${label} material is invalid.`);
  return Object.freeze({ ...shape, material: value.material });
};
var definition = (raw, index) => {
  const value = record2(raw, ["version", "voxel", "boxes", "collision", "occludesFullFace"], `Voxel geometry ${index}`);
  if (value.version !== 1) throw new TypeError(`Voxel geometry ${index} version is invalid.`);
  if (typeof value.voxel !== "number" || !Number.isSafeInteger(value.voxel) || value.voxel < 1 || value.voxel > MAX_VOXEL_STORAGE_ID)
    throw new TypeError(`Voxel geometry ${index} voxel is invalid.`);
  if (typeof value.occludesFullFace !== "boolean") throw new TypeError(`Voxel geometry ${index} occlusion is invalid.`);
  const boxes = Object.freeze(
    denseArray(value.boxes, `Voxel geometry ${value.voxel} boxes`, 1, MAX_BOXES_PER_VOXEL).map(
      (box2, boxIndex) => renderBox(box2, `Voxel geometry ${value.voxel} box ${boxIndex}`)
    )
  );
  const collision = Object.freeze(
    denseArray(value.collision, `Voxel geometry ${value.voxel} collision`, 0, MAX_BOXES_PER_VOXEL).map(
      (box2, boxIndex) => geometryBox(box2, `Voxel geometry ${value.voxel} collision box ${boxIndex}`)
    )
  );
  return Object.freeze({
    version: 1,
    voxel: value.voxel,
    boxes,
    collision,
    occludesFullFace: value.occludesFullFace
  });
};
function createVoxelGeometryRegistryV1(inputs) {
  const source = denseArray(inputs, "Voxel geometry definitions", 1, MAX_GEOMETRY_DEFINITIONS);
  const byVoxel = /* @__PURE__ */ new Map();
  for (const [index, raw] of source.entries()) {
    const value = definition(raw, index);
    if (byVoxel.has(value.voxel)) throw new TypeError(`Duplicate voxel geometry: ${value.voxel}`);
    byVoxel.set(value.voxel, value);
  }
  const values = Object.freeze([...byVoxel.values()].sort((left, right) => left.voxel - right.voxel));
  return Object.freeze({
    get: (voxel2) => byVoxel.get(voxel2),
    require: (voxel2) => {
      const value = byVoxel.get(voxel2);
      if (!value) throw new RangeError(`No voxel geometry is registered for storage ID: ${voxel2}`);
      return value;
    },
    list: () => values
  });
}

// packages/stdlib/src/server/gameplay/modules/voxel-geometry-module.ts
var VOXEL_GEOMETRY_CAPABILITY = "seedlands:voxel-geometry";
var NAMESPACE_ID5 = /^[a-z0-9][a-z0-9._-]*:[a-z0-9][a-z0-9._/-]*$/;
function defineVoxelGeometryModule(options) {
  if (!options || typeof options !== "object" || Array.isArray(options))
    throw new TypeError("Voxel geometry module options are invalid.");
  if (Object.keys(options).length !== 2 || !Object.hasOwn(options, "moduleId") || !Object.hasOwn(options, "descriptors"))
    throw new TypeError("Voxel geometry module option fields are invalid.");
  if (!NAMESPACE_ID5.test(options.moduleId)) throw new TypeError("Voxel geometry module id is invalid.");
  const source = createVoxelGeometryRegistryV1(options.descriptors).list();
  return Object.freeze({
    descriptor: Object.freeze({
      id: options.moduleId,
      version: "1.0.0",
      requires: Object.freeze([Object.freeze({ id: VOXEL_SEMANTICS_CAPABILITY, version: "1.0.0" })]),
      provides: Object.freeze([Object.freeze({ id: VOXEL_GEOMETRY_CAPABILITY, version: "1.0.0" })])
    }),
    register(api) {
      api.requireCapability(VOXEL_SEMANTICS_CAPABILITY);
      const registry = createVoxelGeometryRegistryV1(source);
      api.provideCapability(VOXEL_GEOMETRY_CAPABILITY, registry);
      api.onDefinitionsReady(() => {
        const semantics = new Map(api.readContentDefinitions().voxels.map((voxel2) => [voxel2.storageId, voxel2]));
        for (const descriptor of registry.list()) {
          const voxel2 = semantics.get(descriptor.voxel);
          if (!voxel2) throw new TypeError(`Geometry voxel ${descriptor.voxel} is not registered.`);
          if (!voxel2.renderable) throw new TypeError(`Geometry voxel ${descriptor.voxel} is not renderable.`);
          const materials = new Set(voxel2.faceMaterials);
          for (const box2 of descriptor.boxes)
            if (!materials.has(box2.material))
              throw new TypeError(`Geometry material ${box2.material} is not registered for voxel ${descriptor.voxel}.`);
          if (voxel2.solid !== descriptor.collision.length > 0)
            throw new TypeError(`Geometry collision does not match voxel semantics: ${descriptor.voxel}.`);
        }
      });
    }
  });
}

// packages/stdlib/src/server/composition/content-item-identity.ts
var DEFINITION_ID = /^[a-z0-9][a-z0-9._-]*:[a-z0-9][a-z0-9._/-]*$/;
var STORAGE_ID2 = /^[a-z0-9][a-z0-9._-]*(?::[a-z0-9][a-z0-9._/-]*)?$/;
function createContentItemIdentityResolver(definitions3) {
  const byDefinition = /* @__PURE__ */ new Map();
  const byStorage = /* @__PURE__ */ new Map();
  for (const item of definitions3.items) {
    if (!DEFINITION_ID.test(item.id)) throw new TypeError(`Content item definition id is invalid: ${item.id}`);
    if (!STORAGE_ID2.test(item.storageId)) throw new TypeError(`Content item storage id is invalid: ${item.storageId}`);
    if (byDefinition.has(item.id)) throw new TypeError(`Duplicate content item definition id: ${item.id}`);
    if (byStorage.has(item.storageId)) throw new TypeError(`Duplicate content item storage id: ${item.storageId}`);
    byDefinition.set(item.id, item.storageId);
    byStorage.set(item.storageId, item.id);
  }
  return Object.freeze({
    storageIdForDefinitionId: (definitionId) => byDefinition.get(definitionId) ?? null,
    definitionIdForStorageId: (storageId) => byStorage.get(storageId) ?? null
  });
}

// packages/stdlib/src/physics/geometry.ts
var COLLISION_EPSILON = 1e-6;
var add = (left, right) => ({
  x: left.x + right.x,
  y: left.y + right.y,
  z: left.z + right.z
});
var bodyWorldAabb = (state, config) => ({
  min: add(state.position, config.localAabb.min),
  max: add(state.position, config.localAabb.max)
});
var overlapDepth = (left, right) => {
  const depth = {
    x: Math.min(left.max.x, right.max.x) - Math.max(left.min.x, right.min.x),
    y: Math.min(left.max.y, right.max.y) - Math.max(left.min.y, right.min.y),
    z: Math.min(left.max.z, right.max.z) - Math.max(left.min.z, right.min.z)
  };
  return depth.x > COLLISION_EPSILON && depth.y > COLLISION_EPSILON && depth.z > COLLISION_EPSILON ? depth : null;
};
var finiteVec3 = (value) => Number.isFinite(value.x) && Number.isFinite(value.y) && Number.isFinite(value.z);
var finiteAabb = (aabb) => finiteVec3(aabb.min) && finiteVec3(aabb.max) && aabb.min.x < aabb.max.x && aabb.min.y < aabb.max.y && aabb.min.z < aabb.max.z;
var validCollisionBits = (value) => value === void 0 || Number.isInteger(value) && value >= 0 && value <= 4294967295;
var validateBodyConfig = (config) => {
  const numericValues = [
    config.gravity,
    config.terminalVelocity,
    config.maxHorizontalSpeed,
    config.groundAcceleration,
    config.airAcceleration,
    config.jumpSpeed,
    config.waterSurfaceJumpSpeed,
    config.buoyancy,
    config.fluidDrag,
    config.swimAcceleration,
    config.maxExternalAcceleration
  ];
  return finiteAabb(config.localAabb) && Math.abs(config.localAabb.min.y) <= COLLISION_EPSILON && numericValues.every((value) => value === void 0 || Number.isFinite(value)) && (config.maxExternalAcceleration === void 0 || config.maxExternalAcceleration >= 0) && validCollisionBits(config.collisionLayer) && validCollisionBits(config.collisionMask);
};

// packages/stdlib/src/physics/body-registry.ts
var CollisionLayer = Object.freeze({
  World: 1,
  Character: 2,
  Item: 4,
  PickupSensor: 8
});
var WORLD_ITEM_INTERACTION = Object.freeze({
  attractionRadius: 2.25,
  attractionSpeed: 6,
  pickupRadius: 0.75
});
var radialSensor = (purpose, radius) => ({
  purpose,
  shape: "sphere",
  radius
});
var worldItemSensors = Object.freeze([
  radialSensor("attraction", WORLD_ITEM_INTERACTION.attractionRadius),
  radialSensor("pickup", WORLD_ITEM_INTERACTION.pickupRadius)
]);
var character = (halfWidth, height, maxHorizontalSpeed) => ({
  localAabb: {
    min: { x: -halfWidth, y: 0, z: -halfWidth },
    max: { x: halfWidth, y: height, z: halfWidth }
  },
  collisionLayer: CollisionLayer.Character,
  collisionMask: CollisionLayer.World | CollisionLayer.Character,
  gravity: 18,
  terminalVelocity: 24,
  maxHorizontalSpeed,
  groundAcceleration: 50,
  airAcceleration: 20,
  jumpSpeed: 6.5,
  waterSurfaceJumpSpeed: 6.5,
  buoyancy: 1,
  fluidDrag: 6,
  swimAcceleration: 12
});
var configs = Object.freeze({
  player: character(0.32, 1.8, 4.5),
  "world-item": {
    localAabb: { min: { x: -0.2, y: 0, z: -0.2 }, max: { x: 0.2, y: 0.4, z: 0.2 } },
    collisionLayer: CollisionLayer.Item,
    collisionMask: CollisionLayer.World,
    gravity: 18,
    terminalVelocity: 24,
    maxHorizontalSpeed: 6,
    groundAcceleration: 20,
    airAcceleration: 8,
    buoyancy: 0.7,
    fluidDrag: 7,
    maxExternalAcceleration: 60
  },
  "falling-block": {
    localAabb: { min: { x: -0.49, y: 0, z: -0.49 }, max: { x: 0.49, y: 0.98, z: 0.49 } },
    collisionLayer: CollisionLayer.Item,
    collisionMask: CollisionLayer.World,
    gravity: 18,
    terminalVelocity: 24,
    maxHorizontalSpeed: 0,
    groundAcceleration: 0,
    airAcceleration: 0,
    buoyancy: 0,
    fluidDrag: 0
  },
  painting: {
    localAabb: { min: { x: -0.5, y: 0, z: -0.05 }, max: { x: 0.5, y: 1, z: 0.05 } },
    collisionLayer: CollisionLayer.Item,
    collisionMask: CollisionLayer.World,
    gravity: 0,
    terminalVelocity: 0,
    maxHorizontalSpeed: 0,
    groundAcceleration: 0,
    airAcceleration: 0,
    buoyancy: 0,
    fluidDrag: 0
  },
  grazer: character(0.75, 1.9, 2.1),
  "night-stalker": character(0.65, 2.1, 2.8),
  settler: character(0.65, 2.35, 2.2),
  chicken: character(0.3, 0.7, 1.8),
  cow: character(0.7, 1.4, 2),
  pig: character(0.55, 1, 2),
  "pig-zombie": character(0.3, 1.8, 2.3),
  sheep: character(0.55, 1.3, 2),
  squid: character(0.45, 0.9, 1.4),
  wolf: character(0.4, 0.9, 2.4),
  zombie: character(0.3, 1.8, 2.3),
  skeleton: character(0.3, 1.8, 2.4),
  spider: character(0.7, 0.9, 2.8),
  creeper: character(0.3, 1.7, 2.3),
  slime: character(0.5, 1, 2)
});
for (const config of Object.values(configs))
  if (!validateBodyConfig(config)) throw new TypeError("Body registry contains an invalid body configuration.");
function bodyConfigFor(kind) {
  const config = configs[kind];
  if (!config) throw new RangeError(`Unknown body kind: ${String(kind)}`);
  return config;
}

// packages/stdlib/src/physics/step-body.ts
var CONTACT_TOLERANCE = COLLISION_EPSILON * 4;

// packages/stdlib/src/world/voxel-model.ts
var FULL_BOX = { min: [0, 0, 0], max: [1, 1, 1] };
var LANTERN_COLLISION = { min: [0.25, 0, 0.25], max: [0.75, 0.94, 0.75] };
var FENCE_COLLISION = { min: [0.38, 0, 0.38], max: [0.62, 1, 0.62] };
var box = (min, max, material) => ({
  min,
  max,
  material
});
var crossedPlantMaterials = /* @__PURE__ */ new Map([
  [Voxel.Sapling, FaceMaterial.Sapling],
  [Voxel.TallGrass, FaceMaterial.TallGrass],
  [Voxel.Flower, FaceMaterial.Flower],
  [Voxel.Mushroom, FaceMaterial.Mushroom],
  [Voxel.SugarCane, FaceMaterial.SugarCane],
  [Voxel.DeadBush, FaceMaterial.DeadBush],
  [Voxel.RedFlower, FaceMaterial.RedFlower],
  [Voxel.RedMushroom, FaceMaterial.RedMushroom]
]);
var models = /* @__PURE__ */ new Map([
  [Voxel.Rail, [box([0, 0, 0], [1, 0.08, 1], FaceMaterial.Rail)]],
  [Voxel.PoweredRail, [box([0, 0, 0], [1, 0.08, 1], FaceMaterial.PoweredRail)]],
  [Voxel.DetectorRail, [box([0, 0, 0], [1, 0.08, 1], FaceMaterial.DetectorRail)]],
  [Voxel.Slab, [box([0, 0, 0], [1, 0.5, 1], FaceMaterial.Slab)]],
  [
    Voxel.WoodStairs,
    [box([0, 0, 0], [1, 0.5, 1], FaceMaterial.WoodStairs), box([0, 0.5, 0.5], [1, 1, 1], FaceMaterial.WoodStairs)]
  ],
  [
    Voxel.CobblestoneStairs,
    [
      box([0, 0, 0], [1, 0.5, 1], FaceMaterial.CobblestoneStairs),
      box([0, 0.5, 0.5], [1, 1, 1], FaceMaterial.CobblestoneStairs)
    ]
  ],
  [Voxel.WoodenDoor, [box([0, 0, 0.44], [1, 1, 0.56], FaceMaterial.WoodenDoor)]],
  [Voxel.Ladder, [box([0, 0, 0.88], [1, 1, 1], FaceMaterial.Ladder)]],
  [
    Voxel.Torch,
    [
      box([0.43, 0, 0.43], [0.57, 0.56, 0.57], FaceMaterial.Torch),
      box([0.36, 0.56, 0.36], [0.64, 0.82, 0.64], FaceMaterial.TorchFlame)
    ]
  ],
  [Voxel.Bed, [box([0, 0, 0], [1, 0.56, 1], FaceMaterial.Bed)]],
  [
    Voxel.Sign,
    [
      box([0.08, 0.48, 0.45], [0.92, 0.95, 0.55], FaceMaterial.Sign),
      box([0.46, 0, 0.46], [0.54, 0.5, 0.54], FaceMaterial.Sign)
    ]
  ],
  [
    Voxel.Fence,
    [
      box(FENCE_COLLISION.min, FENCE_COLLISION.max, FaceMaterial.Fence),
      box([0, 0.38, 0.44], [1, 0.5, 0.56], FaceMaterial.Fence),
      box([0, 0.68, 0.44], [1, 0.8, 0.56], FaceMaterial.Fence),
      box([0.44, 0.38, 0], [0.56, 0.5, 1], FaceMaterial.Fence),
      box([0.44, 0.68, 0], [0.56, 0.8, 1], FaceMaterial.Fence)
    ]
  ],
  [Voxel.Cake, [box([0.06, 0, 0.06], [0.94, 0.5, 0.94], FaceMaterial.Cake)]]
]);
var lanternModel = [
  { min: [0.22, 0, 0.22], max: [0.78, 0.12, 0.78], material: FaceMaterial.LanternFrame },
  { min: [0.24, 0.68, 0.24], max: [0.76, 0.78, 0.76], material: FaceMaterial.LanternFrame },
  { min: [0.3, 0.14, 0.3], max: [0.7, 0.68, 0.7], material: FaceMaterial.LanternGlow },
  { min: [0.22, 0.1, 0.22], max: [0.29, 0.72, 0.29], material: FaceMaterial.LanternFrame },
  { min: [0.71, 0.1, 0.22], max: [0.78, 0.72, 0.29], material: FaceMaterial.LanternFrame },
  { min: [0.22, 0.1, 0.71], max: [0.29, 0.72, 0.78], material: FaceMaterial.LanternFrame },
  { min: [0.71, 0.1, 0.71], max: [0.78, 0.72, 0.78], material: FaceMaterial.LanternFrame },
  { min: [0.34, 0.76, 0.47], max: [0.4, 0.9, 0.53], material: FaceMaterial.LanternFrame },
  { min: [0.6, 0.76, 0.47], max: [0.66, 0.9, 0.53], material: FaceMaterial.LanternFrame },
  { min: [0.34, 0.88, 0.47], max: [0.66, 0.94, 0.53], material: FaceMaterial.LanternFrame }
];
function modelBoxesForVoxel(voxel2, geometry) {
  const registered = geometry?.get(voxel2);
  if (registered) return registered.boxes;
  return voxel2 === Voxel.Lantern ? lanternModel : models.get(voxel2) ?? [];
}
function crossedPlantMaterialForVoxel(voxel2) {
  return crossedPlantMaterials.get(voxel2);
}
function hasVoxelModelGeometry(voxel2) {
  return modelBoxesForVoxel(voxel2).length > 0 || crossedPlantMaterialForVoxel(voxel2) !== void 0;
}
function collisionBoxesForVoxel(voxel2, geometry) {
  const registered = geometry?.get(voxel2);
  if (registered) return registered.collision;
  if (!isSolid(voxel2)) return [];
  if (voxel2 === Voxel.Ladder || voxel2 === Voxel.Torch || voxel2 === Voxel.Sign) return [];
  if (voxel2 === Voxel.Fence) return [FENCE_COLLISION];
  return voxel2 === Voxel.Lantern ? [LANTERN_COLLISION] : models.get(voxel2)?.map(({ min, max }) => ({ min, max })) ?? [FULL_BOX];
}

// packages/stdlib/src/server/gameplay/player-occupancy.ts
function playerOccupiesVoxelShape(player, voxel2, voxelId2, geometry) {
  const body = bodyWorldAabb(
    { position: { x: player[0], y: player[1], z: player[2] }, velocity: { x: 0, y: 0, z: 0 } },
    bodyConfigFor("player")
  );
  return collisionBoxesForVoxel(voxelId2, geometry).some(
    (box2) => Boolean(
      overlapDepth(body, {
        min: { x: voxel2[0] + box2.min[0], y: voxel2[1] + box2.min[1], z: voxel2[2] + box2.min[2] },
        max: { x: voxel2[0] + box2.max[0], y: voxel2[1] + box2.max[1], z: voxel2[2] + box2.max[2] }
      })
    )
  );
}

// packages/stdlib/src/server/gameplay/modules/structure-definition.ts
var NAMESPACE_ID6 = /^[a-z0-9][a-z0-9._-]*:[a-z0-9][a-z0-9._/-]*$/;
var LOCAL_ID = /^[a-z0-9][a-z0-9._-]*$/;
var MAX_PARTS = 64;
var MAX_STATES = 64;
var MAX_TRANSITIONS = 64;
var MAX_OFFSET = 64;
var MAX_VOXEL = 65535;
var localId = (value, label) => {
  if (typeof value !== "string" || !LOCAL_ID.test(value)) throw new TypeError(`${label} is invalid.`);
  return value;
};
var cloneOffset = (value, label) => {
  if (!Array.isArray(value) || value.length !== 3 || !value.every((coordinate) => Number.isSafeInteger(coordinate) && Math.abs(coordinate) <= MAX_OFFSET))
    throw new TypeError(`${label} is invalid.`);
  return Object.freeze([value[0], value[1], value[2]]);
};
var clonePosition = (value, label) => {
  if (!Array.isArray(value) || value.length !== 3 || !value.every(Number.isSafeInteger))
    throw new TypeError(`${label} is invalid.`);
  return Object.freeze([value[0], value[1], value[2]]);
};
var validateVoxel = (value, label) => {
  if (!Number.isSafeInteger(value) || value < 1 || value > MAX_VOXEL)
    throw new TypeError(`${label} is invalid.`);
  return value;
};
var offsetKey = (value) => value.join(",");
var stateById = (definition2, stateId) => {
  const state = definition2.states.find((candidate2) => candidate2.id === stateId);
  if (!state) throw new RangeError(`Unknown structure state: ${stateId}`);
  return state;
};
function defineStructureDefinitionV1(input) {
  if (!input || input.version !== 1) throw new TypeError("Structure definition version is invalid.");
  if (typeof input.id !== "string" || !NAMESPACE_ID6.test(input.id))
    throw new TypeError("Structure id must be namespace-qualified.");
  if (!Array.isArray(input.parts) || input.parts.length === 0 || input.parts.length > MAX_PARTS)
    throw new TypeError("Structure parts are invalid.");
  if (!Array.isArray(input.states) || input.states.length === 0 || input.states.length > MAX_STATES)
    throw new TypeError("Structure states are invalid.");
  if (!Array.isArray(input.transitions) || input.transitions.length > MAX_TRANSITIONS)
    throw new TypeError("Structure transitions are invalid.");
  if (input.legacyStates !== void 0 && (!Array.isArray(input.legacyStates) || input.legacyStates.length > MAX_STATES))
    throw new TypeError("Structure legacy states are invalid.");
  const roles = /* @__PURE__ */ new Set();
  const offsets = /* @__PURE__ */ new Set();
  const parts = input.parts.map((source, index) => {
    const role = localId(source.role, `Structure part ${index} role`);
    const offset = cloneOffset(source.offset, `Structure part ${role} offset`);
    if (roles.has(role)) throw new TypeError(`Duplicate structure part role: ${role}`);
    if (offsets.has(offsetKey(offset))) throw new TypeError(`Duplicate structure part offset: ${offsetKey(offset)}`);
    roles.add(role);
    offsets.add(offsetKey(offset));
    return Object.freeze({ role, offset });
  });
  const rootRole = localId(input.rootRole, "Structure root role");
  const rootPart = parts.find((part) => part.role === rootRole);
  if (!rootPart) throw new TypeError(`Unknown structure root role: ${rootRole}`);
  if (offsetKey(rootPart.offset) !== "0,0,0") throw new TypeError("Structure root role must use offset 0,0,0.");
  const supportRole = localId(input.support?.role, "Structure support role");
  if (!roles.has(supportRole) || input.support?.requirement !== "solid")
    throw new TypeError("Structure support policy is invalid.");
  const support = Object.freeze({
    role: supportRole,
    offset: cloneOffset(input.support.offset, "Structure support offset"),
    requirement: "solid"
  });
  if (offsets.has(offsetKey(support.offset)))
    throw new TypeError("Structure support offset must not overlap a structure part.");
  if (input.variantDescriptorKind !== "voxel-semantics" && input.variantDescriptorKind !== "registered-structure")
    throw new TypeError("Structure variant descriptor kind is invalid.");
  if (typeof input.placementItemId !== "string" || !NAMESPACE_ID6.test(input.placementItemId))
    throw new TypeError("Structure placement item id is invalid.");
  const dropOwnerRole = localId(input.dropOwnerRole, "Structure drop owner role");
  if (!roles.has(dropOwnerRole)) throw new TypeError(`Unknown structure drop owner role: ${dropOwnerRole}`);
  if (!input.drop || typeof input.drop.itemId !== "string" || !NAMESPACE_ID6.test(input.drop.itemId) || !Number.isSafeInteger(input.drop.count) || input.drop.count <= 0 || input.drop.count > 64)
    throw new TypeError("Structure drop mapping is invalid.");
  const drop = Object.freeze({ itemId: input.drop.itemId, count: input.drop.count });
  const stateIds = /* @__PURE__ */ new Set();
  const states = input.states.map((source, index) => {
    const id2 = localId(source.id, `Structure state ${index} id`);
    if (stateIds.has(id2)) throw new TypeError(`Duplicate structure state: ${id2}`);
    stateIds.add(id2);
    if (!source.variants || typeof source.variants !== "object" || Array.isArray(source.variants))
      throw new TypeError(`Structure state ${id2} variants are invalid.`);
    const keys = Object.keys(source.variants);
    if (keys.length !== roles.size || keys.some((role) => !roles.has(role)))
      throw new TypeError(`Structure state ${id2} must define every known part role exactly once.`);
    if (!source.collision || typeof source.collision !== "object" || Array.isArray(source.collision))
      throw new TypeError(`Structure state ${id2} collision contract is invalid.`);
    const collisionKeys = Object.keys(source.collision);
    if (collisionKeys.length !== roles.size || collisionKeys.some((role) => !roles.has(role)) || collisionKeys.some((role) => !["blocking", "passable"].includes(source.collision[role])))
      throw new TypeError(`Structure state ${id2} collision contract must define every part role exactly once.`);
    const variants = Object.fromEntries(
      parts.map((part) => [part.role, validateVoxel(source.variants[part.role], `Structure state ${id2} variant`)])
    );
    const collision = Object.fromEntries(parts.map((part) => [part.role, source.collision[part.role]]));
    return Object.freeze({ id: id2, variants: Object.freeze(variants), collision: Object.freeze(collision) });
  });
  const initialState = localId(input.initialState, "Structure initial state");
  if (!stateIds.has(initialState)) throw new TypeError(`Unknown structure initial state: ${initialState}`);
  const legacyStates = (input.legacyStates ?? []).map((source, index) => {
    const stateId = localId(source.stateId, `Structure legacy state ${index} id`);
    if (!stateIds.has(stateId)) throw new TypeError(`Structure legacy state references an unknown state: ${stateId}`);
    if (!source.variants || typeof source.variants !== "object" || Array.isArray(source.variants))
      throw new TypeError(`Structure legacy state ${stateId} variants are invalid.`);
    const keys = Object.keys(source.variants);
    if (keys.length !== roles.size || keys.some((role) => !roles.has(role)))
      throw new TypeError(`Structure legacy state ${stateId} must define every known part role exactly once.`);
    return Object.freeze({
      stateId,
      variants: Object.freeze(
        Object.fromEntries(
          parts.map((part) => [
            part.role,
            validateVoxel(source.variants[part.role], `Structure legacy state ${stateId} variant`)
          ])
        )
      )
    });
  });
  const transitionSources = /* @__PURE__ */ new Set();
  const transitions = input.transitions.map((source, index) => {
    const id2 = localId(source.id, `Structure transition ${index} id`);
    const from = localId(source.from, `Structure transition ${id2} from`);
    const to = localId(source.to, `Structure transition ${id2} to`);
    if (!stateIds.has(from) || !stateIds.has(to))
      throw new TypeError(`Structure transition ${id2} references an unknown state.`);
    if (from === to) throw new TypeError(`Structure transition ${id2} must change state.`);
    const sourceKey = `${id2}\0${from}`;
    if (transitionSources.has(sourceKey))
      throw new TypeError(`Duplicate structure transition source: ${id2} from ${from}`);
    transitionSources.add(sourceKey);
    return Object.freeze({ id: id2, from, to });
  });
  return Object.freeze({
    version: 1,
    id: input.id,
    rootRole,
    initialState,
    parts: Object.freeze(parts),
    states: Object.freeze(states),
    transitions: Object.freeze(transitions),
    legacyStates: Object.freeze(legacyStates),
    support,
    variantDescriptorKind: input.variantDescriptorKind,
    placementItemId: input.placementItemId,
    dropOwnerRole,
    drop
  });
}
function transitionStructureStateV1(definition2, stateId, transitionId) {
  stateById(definition2, stateId);
  localId(transitionId, "Structure transition id");
  const transition = definition2.transitions.find(
    (candidate2) => candidate2.id === transitionId && candidate2.from === stateId
  );
  if (!transition) throw new RangeError(`Unknown structure transition ${transitionId} from ${stateId}`);
  return transition.to;
}
function structureFootprintV1(definition2, root, stateId) {
  const frozenRoot = clonePosition(root, "Structure root");
  const state = stateById(definition2, stateId);
  const parts = definition2.parts.map((part) => {
    const position4 = clonePosition(
      [frozenRoot[0] + part.offset[0], frozenRoot[1] + part.offset[1], frozenRoot[2] + part.offset[2]],
      "Structure part position"
    );
    const chunk = [
      floorDiv2(position4[0], CHUNK_SIZE),
      floorDiv2(position4[1], CHUNK_SIZE),
      floorDiv2(position4[2], CHUNK_SIZE)
    ];
    return {
      value: Object.freeze({
        role: part.role,
        offset: part.offset,
        position: position4,
        voxel: state.variants[part.role],
        chunkKey: chunkKey(...chunk)
      }),
      chunk
    };
  });
  parts.sort(({ value: left, chunk: leftChunk }, { value: right, chunk: rightChunk }) => {
    for (let axis = 0; axis < 3; axis += 1) {
      const chunkOrder = leftChunk[axis] - rightChunk[axis];
      if (chunkOrder) return chunkOrder;
    }
    for (let axis = 0; axis < 3; axis += 1) {
      const positionOrder = left.position[axis] - right.position[axis];
      if (positionOrder) return positionOrder;
    }
    return left.role.localeCompare(right.role);
  });
  return Object.freeze(parts.map(({ value }) => value));
}

// packages/stdlib/src/server/gameplay/modules/structure-definition-module.ts
var STRUCTURE_DEFINITIONS_CAPABILITY = "seedlands:structure-definitions";
var NAMESPACE_ID7 = /^[a-z0-9][a-z0-9._-]*:[a-z0-9][a-z0-9._/-]*$/;
var MAX_DEFINITIONS = 256;
var MAX_TARGET_PATTERNS_PER_VOXEL = 256;
var exactKeys2 = (value, expected, label) => {
  const keys = Object.keys(value);
  if (keys.length !== expected.length || keys.some((key2) => !expected.includes(key2)))
    throw new TypeError(`${label} fields are invalid.`);
};
var cloneDefinition = (definition2) => defineStructureDefinitionV1({
  version: definition2.version,
  id: definition2.id,
  rootRole: definition2.rootRole,
  initialState: definition2.initialState,
  parts: definition2.parts.map((part) => ({ role: part.role, offset: [...part.offset] })),
  states: definition2.states.map((state) => ({
    id: state.id,
    variants: { ...state.variants },
    collision: { ...state.collision }
  })),
  transitions: definition2.transitions.map((transition) => ({ ...transition })),
  legacyStates: definition2.legacyStates.map((state) => ({ stateId: state.stateId, variants: { ...state.variants } })),
  support: { ...definition2.support, offset: [...definition2.support.offset] },
  variantDescriptorKind: definition2.variantDescriptorKind,
  placementItemId: definition2.placementItemId,
  dropOwnerRole: definition2.dropOwnerRole,
  drop: { ...definition2.drop }
});
var positionKey = (position4) => position4.join(",");
var targetKey = (target) => `${target.definitionId}\0${target.source}\0${target.stateId}\0${positionKey(target.root)}`;
var resolvePattern = (pattern, selected, read) => {
  const selectedPart = pattern.definition.parts.find(({ role }) => role === pattern.role);
  const root = Object.freeze([
    selected[0] - selectedPart.offset[0],
    selected[1] - selectedPart.offset[1],
    selected[2] - selectedPart.offset[2]
  ]);
  const parts = Object.freeze(
    structureFootprintV1(pattern.definition, root, pattern.stateId).map(
      (part) => Object.freeze({ ...part, voxel: pattern.variants[part.role] })
    )
  );
  if (!parts.every((part) => read(part.position) === part.voxel)) return null;
  return Object.freeze({
    definitionId: pattern.definition.id,
    stateId: pattern.stateId,
    source: pattern.source,
    root,
    parts
  });
};
function createStructureDefinitionRegistryV1(inputs) {
  if (!Array.isArray(inputs) || inputs.length === 0 || inputs.length > MAX_DEFINITIONS)
    throw new TypeError("Structure definitions are invalid.");
  const definitions3 = /* @__PURE__ */ new Map();
  const variants = /* @__PURE__ */ new Map();
  const registeredTargets = /* @__PURE__ */ new Map();
  const legacyTargets = /* @__PURE__ */ new Map();
  const placementItems = /* @__PURE__ */ new Map();
  for (const input of inputs) {
    const definition2 = cloneDefinition(input);
    if (definitions3.has(definition2.id)) throw new TypeError(`Duplicate structure definition: ${definition2.id}`);
    if (placementItems.has(definition2.placementItemId))
      throw new TypeError(`Duplicate structure placement item: ${definition2.placementItemId}`);
    definitions3.set(definition2.id, definition2);
    placementItems.set(definition2.placementItemId, definition2);
    for (const state of definition2.states)
      for (const part of definition2.parts) {
        const voxel2 = state.variants[part.role];
        const previous = variants.get(voxel2);
        if (previous)
          throw new TypeError(
            `Structure variant voxel ${voxel2} conflicts between ${previous.definition.id}/${previous.stateId}/${previous.role} and ${definition2.id}/${state.id}/${part.role}.`
          );
        variants.set(
          voxel2,
          Object.freeze({
            definition: definition2,
            stateId: state.id,
            role: part.role
          })
        );
        registeredTargets.set(
          voxel2,
          Object.freeze({
            definition: definition2,
            stateId: state.id,
            source: "registered",
            role: part.role,
            variants: state.variants
          })
        );
      }
    for (const state of definition2.legacyStates)
      for (const part of definition2.parts) {
        const voxel2 = state.variants[part.role];
        const candidates = legacyTargets.get(voxel2) ?? [];
        if (candidates.length >= MAX_TARGET_PATTERNS_PER_VOXEL)
          throw new TypeError(`Structure legacy target candidates exceed the per-voxel limit: ${voxel2}`);
        candidates.push(
          Object.freeze({
            definition: definition2,
            stateId: state.stateId,
            source: "legacy",
            role: part.role,
            variants: state.variants
          })
        );
        legacyTargets.set(voxel2, candidates);
      }
  }
  for (const candidates of legacyTargets.values()) Object.freeze(candidates);
  const ordered2 = Object.freeze([...definitions3.values()].sort((left, right) => left.id.localeCompare(right.id)));
  const patternsForVoxel = (voxel2) => {
    const registered = registeredTargets.get(voxel2);
    const legacy = legacyTargets.get(voxel2) ?? [];
    return registered ? [registered, ...legacy] : legacy;
  };
  const resolveTarget = (position4, read) => {
    const selectedVoxel = read(position4);
    if (selectedVoxel === void 0) return null;
    const matches = /* @__PURE__ */ new Map();
    for (const pattern of patternsForVoxel(selectedVoxel)) {
      const target = resolvePattern(pattern, position4, read);
      if (target) matches.set(targetKey(target), target);
    }
    if (matches.size !== 1) return null;
    const resolved = matches.values().next().value;
    for (const part of resolved.parts) {
      for (const pattern of patternsForVoxel(part.voxel)) {
        const overlapping = resolvePattern(pattern, part.position, read);
        if (overlapping) matches.set(targetKey(overlapping), overlapping);
      }
    }
    return matches.size === 1 ? resolved : null;
  };
  return Object.freeze({
    get: (id2) => definitions3.get(id2),
    require: (id2) => {
      const definition2 = definitions3.get(id2);
      if (!definition2) throw new RangeError(`Unknown structure definition: ${id2}`);
      return definition2;
    },
    resolveVariant: (voxel2) => variants.get(voxel2),
    resolveTarget,
    resolvePlacementItem: (itemId) => placementItems.get(itemId),
    list: () => ordered2
  });
}
function defineStructureDefinitionModule(options) {
  if (!options || typeof options !== "object") throw new TypeError("Structure definition module options are invalid.");
  exactKeys2(options, ["moduleId", "definitions"], "Structure definition module options");
  if (typeof options.moduleId !== "string" || !NAMESPACE_ID7.test(options.moduleId))
    throw new TypeError("Structure definition module id must be namespace-qualified.");
  const source = createStructureDefinitionRegistryV1(options.definitions).list();
  const requiresGeometry = source.some(({ variantDescriptorKind }) => variantDescriptorKind === "registered-structure");
  return Object.freeze({
    descriptor: Object.freeze({
      id: options.moduleId,
      version: "1.0.0",
      requires: Object.freeze([
        Object.freeze({ id: ITEMS_CAPABILITY, version: "1.0.0" }),
        Object.freeze({ id: VOXEL_SEMANTICS_CAPABILITY, version: "1.0.0" }),
        ...requiresGeometry ? [Object.freeze({ id: VOXEL_GEOMETRY_CAPABILITY, version: "1.0.0" })] : []
      ]),
      provides: Object.freeze([Object.freeze({ id: STRUCTURE_DEFINITIONS_CAPABILITY, version: "1.0.0" })])
    }),
    register(api) {
      api.requireCapability(ITEMS_CAPABILITY);
      api.requireCapability(VOXEL_SEMANTICS_CAPABILITY);
      const geometry = requiresGeometry ? api.requireCapability(VOXEL_GEOMETRY_CAPABILITY) : void 0;
      const registry = createStructureDefinitionRegistryV1(source);
      api.provideCapability(STRUCTURE_DEFINITIONS_CAPABILITY, registry);
      api.onDefinitionsReady(() => {
        const content = api.readContentDefinitions();
        const voxels = new Map(content.voxels.map((voxel2) => [voxel2.storageId, voxel2]));
        const items = new Set(content.items.map(({ id: id2 }) => id2));
        for (const definition2 of registry.list()) {
          if (!items.has(definition2.placementItemId))
            throw new TypeError(`Structure placement item is not registered: ${definition2.placementItemId}`);
          if (!items.has(definition2.drop.itemId))
            throw new TypeError(`Structure drop item is not registered: ${definition2.drop.itemId}`);
          for (const state of definition2.states)
            for (const part of definition2.parts) {
              const variant = state.variants[part.role];
              const semantic = voxels.get(variant);
              if (!semantic)
                throw new TypeError(
                  `Structure variant voxel semantics are not registered: ${definition2.id}/${variant}`
                );
              if (semantic.solid !== (state.collision[part.role] === "blocking"))
                throw new TypeError(
                  `Structure collision semantics do not match: ${definition2.id}/${state.id}/${part.role}`
                );
              if (definition2.variantDescriptorKind === "registered-structure") {
                const descriptor = geometry?.get(variant);
                if (!descriptor)
                  throw new TypeError(`Structure variant descriptor is not registered: ${definition2.id}/${variant}`);
                if (descriptor.collision.length > 0 !== (state.collision[part.role] === "blocking"))
                  throw new TypeError(
                    `Structure descriptor collision does not match: ${definition2.id}/${state.id}/${part.role}`
                  );
                if (descriptor.boxes.some((box2) => !semantic.faceMaterials.includes(box2.material)))
                  throw new TypeError(
                    `Structure descriptor material does not match: ${definition2.id}/${state.id}/${part.role}`
                  );
              }
            }
          for (const legacy of definition2.legacyStates) {
            const state = definition2.states.find(({ id: id2 }) => id2 === legacy.stateId);
            for (const part of definition2.parts) {
              const variant = legacy.variants[part.role];
              const semantic = voxels.get(variant);
              if (!semantic)
                throw new TypeError(
                  `Structure variant voxel semantics are not registered: ${definition2.id}/${variant}`
                );
              if (semantic.solid !== (state.collision[part.role] === "blocking"))
                throw new TypeError(
                  `Structure legacy collision semantics do not match: ${definition2.id}/${legacy.stateId}/${part.role}`
                );
            }
          }
        }
      });
    }
  });
}

// packages/stdlib/src/server/gameplay/modules/structure-multi-edit-model.ts
var MAX_STRUCTURE_EDITS = 64;
var MAX_VOXEL2 = 65535;
var positionKey2 = (position4) => position4.join(",");
var clonePosition2 = (raw, label) => {
  if (!Array.isArray(raw) || raw.length !== 3 || !raw.every(Number.isSafeInteger))
    throw new TypeError(`${label} is invalid.`);
  return Object.freeze([raw[0], raw[1], raw[2]]);
};
var voxel = (raw, label) => {
  if (!Number.isSafeInteger(raw) || raw < 0 || raw > MAX_VOXEL2)
    throw new TypeError(`${label} is invalid.`);
  return raw;
};
var exactKeys3 = (raw, expected, label) => {
  const keys = Object.keys(raw);
  if (keys.length !== expected.length || keys.some((key2) => !expected.includes(key2)))
    throw new TypeError(`${label} fields are invalid.`);
};
var definitionFootprint = (definition2, root, stateId, label) => {
  const footprint = structureFootprintV1(definition2, root, stateId);
  if (footprint.length !== definition2.parts.length || footprint.length === 0 || footprint.length > MAX_STRUCTURE_EDITS || footprint.some((part) => !Number.isSafeInteger(part.voxel) || part.voxel < 1 || part.voxel > MAX_VOXEL2))
    throw new TypeError(`${label} structure state is incomplete.`);
  return footprint;
};
var sourcePatterns = (definition2, root, stateId) => {
  const footprint = definitionFootprint(definition2, root, stateId, "Source");
  return Object.freeze([
    Object.freeze(footprint.map(({ voxel: voxel2 }) => voxel2)),
    ...definition2.legacyStates.filter((state) => state.stateId === stateId).map((state) => Object.freeze(footprint.map(({ role }) => state.variants[role])))
  ]);
};
function validateStructureMultiEditCandidateV1(raw, definition2) {
  if (!raw || typeof raw !== "object" || Array.isArray(raw))
    throw new TypeError("Structure multi-edit candidate is invalid.");
  exactKeys3(
    raw,
    ["version", "kind", "definitionId", "root", "fromState", "toState", "transitionId", "edits"],
    "Structure candidate"
  );
  const value = raw;
  if (value.version !== 1 || value.definitionId !== definition2.id)
    throw new TypeError("Structure candidate identity is invalid.");
  if (typeof value.fromState !== "string" || typeof value.toState !== "string")
    throw new TypeError("Structure candidate states are invalid.");
  if (value.kind === "transition" && value.fromState === value.toState)
    throw new TypeError("Structure transition candidate must change state.");
  if (value.kind === "transition") {
    if (typeof value.transitionId !== "string") throw new TypeError("Structure transition candidate id is invalid.");
    if (transitionStructureStateV1(definition2, value.fromState, value.transitionId) !== value.toState)
      throw new TypeError("Structure transition candidate does not follow the transition graph.");
  } else if (value.kind === "placement") {
    if (value.transitionId !== null || value.fromState !== definition2.initialState || value.toState !== definition2.initialState)
      throw new TypeError("Structure placement candidate must target the initial state.");
  } else throw new TypeError("Structure candidate kind is invalid.");
  const root = clonePosition2(value.root, "Structure candidate root");
  const from = definitionFootprint(definition2, root, value.fromState, "Source");
  const to = definitionFootprint(definition2, root, value.toState, "Target");
  if (!Array.isArray(value.edits) || value.edits.length !== definition2.parts.length)
    throw new TypeError("Structure candidate edits are partial or oversized.");
  const targetByRole = new Map(to.map((part) => [part.role, part]));
  const coordinates = /* @__PURE__ */ new Set();
  const roles = /* @__PURE__ */ new Set();
  const edits = value.edits.map((rawEdit, index) => {
    if (!rawEdit || typeof rawEdit !== "object" || Array.isArray(rawEdit))
      throw new TypeError("Structure candidate edit is invalid.");
    exactKeys3(rawEdit, ["role", "position", "chunkKey", "expected", "from", "to"], "Structure candidate edit");
    const edit = rawEdit;
    const source = from[index];
    const target = targetByRole.get(source.role);
    const position4 = clonePosition2(edit.position, "Structure candidate edit position");
    if (typeof edit.role !== "string" || edit.role !== source.role || !target || typeof edit.chunkKey !== "string" || edit.chunkKey !== source.chunkKey || positionKey2(position4) !== positionKey2(source.position))
      throw new TypeError("Structure candidate edit does not match its stable footprint.");
    const expected = voxel(edit.expected, "Structure candidate expected voxel");
    const fromVoxel = voxel(edit.from, "Structure candidate source voxel");
    const toVoxel = voxel(edit.to, "Structure candidate target voxel");
    if (expected !== fromVoxel || toVoxel !== target.voxel)
      throw new TypeError("Structure candidate expected, source or target voxel does not match its state.");
    const coordinate = positionKey2(position4);
    if (coordinates.has(coordinate) || roles.has(edit.role))
      throw new TypeError("Structure candidate contains a duplicate coordinate or role.");
    coordinates.add(coordinate);
    roles.add(edit.role);
    return Object.freeze({
      role: edit.role,
      position: position4,
      chunkKey: edit.chunkKey,
      expected,
      from: fromVoxel,
      to: toVoxel
    });
  });
  if (value.kind === "transition") {
    const actual = edits.map(({ from: from2 }) => from2);
    if (!sourcePatterns(definition2, root, value.fromState).some(
      (pattern) => pattern.every((voxel2, index) => voxel2 === actual[index])
    ))
      throw new TypeError("Structure transition source does not match a registered or legacy state pattern.");
  } else {
    const expectedVoxel = edits[0].expected;
    if (!edits.every((edit) => edit.expected === expectedVoxel && edit.from === expectedVoxel))
      throw new TypeError("Structure placement source voxels must use one expected replaceable value.");
  }
  return Object.freeze({
    version: 1,
    kind: value.kind,
    definitionId: definition2.id,
    root,
    fromState: value.fromState,
    toState: value.toState,
    transitionId: value.transitionId,
    edits: Object.freeze(edits)
  });
}
function assertStructureMultiEditReadsV1(candidate2, read) {
  for (const edit of candidate2.edits) {
    const current2 = read(edit.position);
    if (current2 === void 0) throw new Error(`Structure candidate read is unknown: ${positionKey2(edit.position)}`);
    if (current2 !== edit.expected)
      throw new Error(`Structure candidate expected voxel is stale: ${positionKey2(edit.position)}`);
  }
}
var buildTransitionCandidate = (definition2, input) => {
  if (input.current.definitionId !== definition2.id)
    throw new TypeError("Resolved structure does not match the transition definition.");
  const from = input.current.parts;
  const to = definitionFootprint(definition2, input.current.root, input.toState, "Target");
  if (from.length !== definition2.parts.length) throw new TypeError("Resolved structure footprint is incomplete.");
  const targetByRole = new Map(to.map((part) => [part.role, part]));
  const observed = /* @__PURE__ */ new Map();
  for (const source of from) {
    const current2 = input.read(source.position);
    if (current2 === void 0) throw new Error(`Structure candidate read is unknown: ${positionKey2(source.position)}`);
    if (current2 !== source.voxel)
      throw new Error(`Structure candidate expected voxel is stale: ${positionKey2(source.position)}`);
    observed.set(source.role, current2);
  }
  const candidate2 = validateStructureMultiEditCandidateV1(
    {
      version: 1,
      kind: "transition",
      definitionId: definition2.id,
      root: input.current.root,
      fromState: input.current.stateId,
      toState: input.toState,
      transitionId: input.transitionId,
      edits: from.map((source) => ({
        role: source.role,
        position: source.position,
        chunkKey: source.chunkKey,
        expected: observed.get(source.role),
        from: source.voxel,
        to: targetByRole.get(source.role)?.voxel
      }))
    },
    definition2
  );
  assertStructureMultiEditReadsV1(candidate2, input.read);
  return candidate2;
};
function buildStructureTransitionCandidateV1(definition2, input) {
  const toState = transitionStructureStateV1(definition2, input.current.stateId, input.transitionId);
  return buildTransitionCandidate(definition2, {
    current: input.current,
    toState,
    transitionId: input.transitionId,
    read: input.read
  });
}

// packages/stdlib/src/server/gameplay/gameplay-geometry.ts
var distanceSquared = (left, right) => left.reduce((sum, value, index) => sum + (value - right[index]) ** 2, 0);
var voxelCenter = (position4) => [
  position4[0] + 0.5,
  position4[1] + 0.5,
  position4[2] + 0.5
];
var positionsInRange = (left, right, radius) => distanceSquared(left, right) <= radius * radius;

// packages/stdlib/src/server/gameplay/modules/structure-target-dispatch.ts
var key = (position4) => position4.join(",");
var chunkFor = (position4) => chunkKey(...position4.map((value) => floorDiv2(value, CHUNK_SIZE)));
var ordered = (values) => Object.freeze([...new Set(values)].sort());
var position = (value, label) => {
  if (!Array.isArray(value) || value.length !== 3 || !value.every(Number.isSafeInteger))
    throw new TypeError(`${label} is invalid.`);
  return Object.freeze([value[0], value[1], value[2]]);
};
function resolveStructureTargetIntentV1(registry, hit, read) {
  position(hit, "Structure target");
  const cache = /* @__PURE__ */ new Map();
  const readOnce = (position4) => {
    const id2 = key(position4);
    if (!cache.has(id2)) cache.set(id2, read(position4));
    return cache.get(id2);
  };
  const selected = readOnce(hit);
  if (selected === void 0) return { status: "unavailable", chunkKeys: Object.freeze([chunkFor(hit)]) };
  const candidates = registry.list().flatMap((definition3) => [
    ...definition3.states.map((state) => ({
      definition: definition3,
      stateId: state.id,
      source: "registered",
      variants: state.variants
    })),
    ...definition3.legacyStates.map((state) => ({
      definition: definition3,
      stateId: state.stateId,
      source: "legacy",
      variants: state.variants
    }))
  ]).flatMap(
    (candidate2) => candidate2.definition.parts.filter((part) => candidate2.variants[part.role] === selected).map((part) => ({ ...candidate2, selectedPart: part }))
  );
  if (!candidates.length) return { status: "not-structure" };
  const chunkKeys = /* @__PURE__ */ new Set();
  let unavailable = false, completeCandidate = false;
  for (const candidate2 of candidates) {
    const root = Object.freeze([
      hit[0] - candidate2.selectedPart.offset[0],
      hit[1] - candidate2.selectedPart.offset[1],
      hit[2] - candidate2.selectedPart.offset[2]
    ]);
    const parts = Object.freeze(
      structureFootprintV1(candidate2.definition, root, candidate2.stateId).map(
        (part) => Object.freeze({ ...part, voxel: candidate2.variants[part.role] })
      )
    );
    parts.forEach((part) => chunkKeys.add(part.chunkKey));
    const support = Object.freeze([
      root[0] + candidate2.definition.support.offset[0],
      root[1] + candidate2.definition.support.offset[1],
      root[2] + candidate2.definition.support.offset[2]
    ]);
    chunkKeys.add(chunkFor(support));
    const values = parts.map((part) => readOnce(part.position));
    if (values.some((value) => value === void 0) || readOnce(support) === void 0) {
      unavailable = true;
      continue;
    }
    if (values.every((value, index) => value === parts[index].voxel)) completeCandidate = true;
  }
  const structure = completeCandidate ? registry.resolveTarget(hit, readOnce) : null;
  if (!structure)
    return completeCandidate || !unavailable ? { status: "malformed" } : { status: "unavailable", chunkKeys: ordered(chunkKeys) };
  const definition2 = registry.require(structure.definitionId);
  structure.parts.forEach((part) => chunkKeys.add(part.chunkKey));
  chunkKeys.add(
    chunkFor([
      structure.root[0] + definition2.support.offset[0],
      structure.root[1] + definition2.support.offset[1],
      structure.root[2] + definition2.support.offset[2]
    ])
  );
  return { status: "resolved", structure, chunkKeys: ordered(chunkKeys) };
}
function resolveStructurePlacementIntentV1(registry, identity5, selectedStorageId2, hit, adjacent2, actorPosition2) {
  position(hit, "Structure placement hit");
  position(adjacent2, "Structure placement adjacent");
  if (!selectedStorageId2) return { status: "not-structure" };
  const definitionId = identity5.definitionIdForStorageId(selectedStorageId2);
  const definition2 = definitionId ? registry.resolvePlacementItem(definitionId) : void 0;
  if (!definition2) return { status: "not-structure" };
  const delta = adjacent2.map((value, axis) => value - hit[axis]);
  if (delta.reduce((sum, value) => sum + Math.abs(value), 0) !== 1)
    return { status: "malformed", reason: "invalid-target" };
  let bearing;
  if (delta[0] !== 0) bearing = delta[0] > 0 ? "east" : "west";
  else if (delta[2] !== 0) bearing = delta[2] > 0 ? "south" : "north";
  else {
    const x2 = adjacent2[0] + 0.5 - actorPosition2[0];
    const z = adjacent2[2] + 0.5 - actorPosition2[2];
    if (x2 === 0 && z === 0) return { status: "malformed", reason: "ambiguous-placement-orientation" };
    bearing = Math.abs(x2) >= Math.abs(z) ? x2 > 0 ? "east" : "west" : z > 0 ? "south" : "north";
  }
  const root = Object.freeze([...adjacent2]);
  const chunkKeys = structureFootprintV1(definition2, root, definition2.initialState).map((part) => part.chunkKey);
  chunkKeys.push(
    chunkFor([
      root[0] + definition2.support.offset[0],
      root[1] + definition2.support.offset[1],
      root[2] + definition2.support.offset[2]
    ])
  );
  return {
    status: "resolved",
    definition: definition2,
    stateId: definition2.initialState,
    root,
    bearing,
    chunkKeys: ordered(chunkKeys)
  };
}

// packages/stdlib/src/server/gameplay/modules/structure-operation-model.ts
var StructureOperationModelError = class extends Error {
  constructor(code) {
    super(code);
    this.code = code;
    this.name = "StructureOperationModelError";
  }
  code;
};
function fail2(code) {
  throw new StructureOperationModelError(code);
}
var frozenPosition = (position4) => Object.freeze([position4[0], position4[1], position4[2]]);
var supportPosition = (root, offset) => frozenPosition(root.map((value, axis) => value + offset[axis]));
var freezeEdit = (edit) => Object.freeze({ ...edit, position: frozenPosition(edit.position) });
var freezePlan = (plan) => Object.freeze({
  ...plan,
  root: frozenPosition(plan.root),
  edits: Object.freeze(plan.edits.map(freezeEdit)),
  ...plan.consume ? { consume: Object.freeze({ ...plan.consume }) } : {},
  ...plan.drop ? { drop: Object.freeze({ ...plan.drop, position: frozenPosition(plan.drop.position) }) } : {},
  ...plan.support ? { support: Object.freeze({ ...plan.support, position: frozenPosition(plan.support.position) }) } : {}
});
var resolvedTarget = (registry, hit, read) => {
  const result = resolveStructureTargetIntentV1(registry, hit, read);
  if (result.status === "unavailable") throw new StructureOperationModelError("structure-unavailable");
  if (result.status !== "resolved") throw new StructureOperationModelError("structure-malformed");
  return result.structure;
};
var requireValue = (value, code) => {
  if (value === void 0) throw new StructureOperationModelError(code);
  return value;
};
var transitionCandidate = (definition2, input) => {
  try {
    return buildStructureTransitionCandidateV1(definition2, input);
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    if (/candidate read is unknown/i.test(message)) throw new StructureOperationModelError("structure-unavailable");
    if (/stale/i.test(message)) throw new StructureOperationModelError("structure-stale");
    throw new StructureOperationModelError("structure-transition-invalid");
  }
};
function buildStructurePlaceCandidateV1(registry, input) {
  const definition2 = requireValue(
    registry.resolvePlacementItem(input.actor.selectedItemDefinitionId),
    "structure-definition-missing"
  );
  const state = requireValue(
    definition2.states.find(({ id: id2 }) => id2 === input.stateId),
    "structure-state-invalid"
  );
  const footprint = structureFootprintV1(definition2, input.root, state.id);
  const edits = footprint.map((part) => {
    const expected = requireValue(input.read(part.position), "structure-unavailable");
    if (!input.isReplaceable(expected)) fail2("structure-target-occupied");
    if (state.collision[part.role] === "blocking" && input.collides(part.position, part.voxel))
      fail2("structure-player-collision");
    return freezeEdit({
      role: part.role,
      position: part.position,
      chunkKey: part.chunkKey,
      expected,
      from: expected,
      to: part.voxel
    });
  });
  const at2 = supportPosition(input.root, definition2.support.offset);
  const support = requireValue(input.read(at2), "structure-unavailable");
  if (!input.isSolid(support)) fail2("structure-support-invalid");
  return freezePlan({
    version: 1,
    kind: "place",
    actorId: input.actor.actorId,
    mode: input.actor.mode,
    definitionId: definition2.id,
    root: input.root,
    fromState: null,
    toState: state.id,
    transitionId: null,
    edits,
    consume: input.actor.mode === "survival" ? Object.freeze({ itemDefinitionId: definition2.placementItemId, count: 1 }) : null,
    drop: null,
    support: Object.freeze({ position: at2, expected: support })
  });
}
function buildStructureToggleCandidateV1(registry, input) {
  const current2 = resolvedTarget(registry, input.hit, input.read);
  const definition2 = registry.require(current2.definitionId);
  const candidate2 = transitionCandidate(definition2, {
    current: current2,
    transitionId: input.transitionId,
    read: input.read
  });
  const state = definition2.states.find(({ id: id2 }) => id2 === candidate2.toState);
  if (candidate2.edits.some((edit) => state.collision[edit.role] === "blocking" && input.collides(edit.position, edit.to)))
    fail2("structure-player-collision");
  return freezePlan({
    version: 1,
    kind: "toggle",
    actorId: input.actor.actorId,
    mode: input.actor.mode,
    definitionId: definition2.id,
    root: candidate2.root,
    fromState: candidate2.fromState,
    toState: candidate2.toState,
    transitionId: candidate2.transitionId,
    edits: candidate2.edits,
    consume: null,
    drop: null,
    support: null
  });
}
function buildStructureBreakCandidateV1(registry, input) {
  const current2 = resolvedTarget(registry, input.hit, input.read);
  const definition2 = registry.require(current2.definitionId);
  const edits = current2.parts.map(
    (part) => freezeEdit({
      role: part.role,
      position: part.position,
      chunkKey: part.chunkKey,
      expected: part.voxel,
      from: part.voxel,
      to: Voxel.Air
    })
  );
  const owner = current2.parts.find(({ role }) => role === definition2.dropOwnerRole);
  return freezePlan({
    version: 1,
    kind: "break",
    actorId: input.actor.actorId,
    mode: input.actor.mode,
    definitionId: definition2.id,
    root: current2.root,
    fromState: current2.stateId,
    toState: null,
    transitionId: null,
    edits,
    consume: null,
    drop: input.actor.mode === "survival" ? Object.freeze({
      ownerRole: owner.role,
      position: owner.position,
      itemDefinitionId: definition2.drop.itemId,
      count: definition2.drop.count
    }) : null,
    support: null
  });
}

// packages/stdlib/src/server/gameplay/modules/structure-actions-module.ts
var STRUCTURE_ACTIONS_CAPABILITY = "seedlands:structure-actions";
var STRUCTURE_ACTOR_COMPONENT = "seedlands:structure-actor";
var STRUCTURE_VOXEL_COMPONENT = "seedlands:structure-voxel";
var STRUCTURE_RESOURCE = "seedlands.structure";
var STRUCTURE_PLACE_OPERATION = "seedlands:structure-place";
var STRUCTURE_TOGGLE_OPERATION = "seedlands:structure-toggle";
var STRUCTURE_BREAK_OPERATION = "seedlands:structure-break";
var MAX_WORLD_COORDINATE2 = 3e7;
var MAX_IDENTITY_LENGTH3 = 256;
var record3 = (raw, keys, label) => {
  if (!raw || typeof raw !== "object" || Array.isArray(raw)) throw new TypeError(`${label} is invalid.`);
  const descriptors = Object.getOwnPropertyDescriptors(raw);
  if (Reflect.ownKeys(descriptors).length !== keys.length) throw new TypeError(`${label} fields are invalid.`);
  for (const key2 of keys) {
    const descriptor = descriptors[key2];
    if (!descriptor?.enumerable || !("value" in descriptor)) throw new TypeError(`${label} fields are invalid.`);
  }
  return raw;
};
var position2 = (raw, label) => {
  if (!Array.isArray(raw) || raw.length !== 3 || Reflect.ownKeys(raw).length !== 4 || raw.some((value) => !Number.isSafeInteger(value) || Math.abs(value) > MAX_WORLD_COORDINATE2))
    throw new TypeError(`${label} is invalid.`);
  return Object.freeze([raw[0], raw[1], raw[2]]);
};
var actorPosition = (raw) => {
  if (!Array.isArray(raw) || raw.length !== 3 || Reflect.ownKeys(raw).length !== 4 || raw.some((value) => typeof value !== "number" || !Number.isFinite(value) || Math.abs(value) > MAX_WORLD_COORDINATE2))
    throw new TypeError("Structure actor position is invalid.");
  return Object.freeze([raw[0], raw[1], raw[2]]);
};
var revision = (value) => Number.isSafeInteger(value) && value >= 0;
var identity3 = (value) => typeof value === "string" && value.length > 0 && value.length <= MAX_IDENTITY_LENGTH3 && value.trim() === value;
function validateStructureActorProjectionV1(raw, items) {
  const value = record3(
    raw,
    [
      "version",
      "reference",
      "position",
      "lifecycle",
      "mode",
      "inventoryRevision",
      "slots",
      "selectedSlot",
      "creativeCatalog"
    ],
    "Structure actor projection"
  );
  const reference3 = record3(value.reference, ["entityId", "epoch", "lifetime"], "Structure actor reference");
  const mode = record3(value.mode, ["value", "revision"], "Structure actor mode");
  const catalog = record3(value.creativeCatalog, ["revision", "selectedSlot", "hotbar"], "Structure creative catalog");
  if (value.version !== 1 || !identity3(reference3.entityId) || !revision(reference3.epoch) || reference3.epoch === 0 || !revision(reference3.lifetime) || reference3.lifetime === 0 || value.lifecycle !== "alive" && value.lifecycle !== "dead" || mode.value !== "survival" && mode.value !== "creative" || !revision(mode.revision) || !revision(value.inventoryRevision) || !Array.isArray(value.slots) || value.slots.length < 1 || value.slots.length > 64 || !Number.isSafeInteger(value.selectedSlot) || value.selectedSlot < 0 || value.selectedSlot >= value.slots.length || !revision(catalog.revision) || !Array.isArray(catalog.hotbar) || catalog.hotbar.length < 1 || catalog.hotbar.length > 9 || !Number.isSafeInteger(catalog.selectedSlot) || catalog.selectedSlot < 0 || catalog.selectedSlot >= catalog.hotbar.length)
    throw new TypeError("Structure actor projection is invalid.");
  const slots = Object.freeze(
    value.slots.map((slot) => slot === null ? null : Object.freeze(items.normalizeStack(slot)))
  );
  const hotbar2 = Object.freeze(
    catalog.hotbar.map((itemId) => {
      if (itemId !== null && (!identity3(itemId) || !items.has(itemId)))
        throw new TypeError("Structure creative catalog item is invalid.");
      return itemId;
    })
  );
  return Object.freeze({
    version: 1,
    reference: Object.freeze({
      entityId: reference3.entityId,
      epoch: reference3.epoch,
      lifetime: reference3.lifetime
    }),
    position: actorPosition(value.position),
    lifecycle: value.lifecycle,
    mode: Object.freeze({ value: mode.value, revision: mode.revision }),
    inventoryRevision: value.inventoryRevision,
    slots,
    selectedSlot: value.selectedSlot,
    creativeCatalog: Object.freeze({
      revision: catalog.revision,
      selectedSlot: catalog.selectedSlot,
      hotbar: hotbar2
    })
  });
}
function validateStructureVoxelProjectionV1(raw) {
  const value = record3(raw, ["version", "position", "voxel", "fluid"], "Structure voxel projection");
  if (value.version !== 1 || !Number.isSafeInteger(value.voxel) || value.voxel < 0 || value.voxel > 65535 || !Number.isSafeInteger(value.fluid) || value.fluid < 0 || value.fluid > 255)
    throw new TypeError("Structure voxel projection is invalid.");
  return Object.freeze({
    version: 1,
    position: position2(value.position, "Structure voxel position"),
    voxel: value.voxel,
    fluid: value.fluid
  });
}
var structureActorAddress = (entityId) => Object.freeze({ componentId: STRUCTURE_ACTOR_COMPONENT, target: Object.freeze({ kind: "entity", entityId }) });
var structureVoxelAddress = (at2) => Object.freeze({ componentId: STRUCTURE_VOXEL_COMPONENT, target: Object.freeze({ kind: "voxel", position: at2 }) });
function validateStructureActionTargetV1(raw) {
  const value = record3(raw, ["hit", "adjacent"], "Structure action input");
  const hit = position2(value.hit, "Structure hit");
  const adjacent2 = position2(value.adjacent, "Structure adjacent");
  if (hit.reduce((sum, coordinate, axis) => sum + Math.abs(coordinate - adjacent2[axis]), 0) !== 1)
    throw new TypeError("Structure hit and adjacent cells must be orthogonally adjacent.");
  return Object.freeze({ hit, adjacent: adjacent2 });
}
var selectedStorageId = (actor) => actor.mode.value === "creative" ? actor.creativeCatalog.hotbar[actor.creativeCatalog.selectedSlot] ?? null : actor.slots[actor.selectedSlot]?.itemId ?? null;
function buildRegisteredStructureCandidateV1(environment, input) {
  if (input.actor.lifecycle !== "alive") throw new Error("structure-actor-unavailable");
  const actor = { actorId: input.actor.reference.entityId, mode: input.actor.mode.value };
  const collides = (at2, voxel2) => playerOccupiesVoxelShape(input.actor.position, at2, voxel2, environment.geometry);
  if (input.kind === "place") {
    if (!input.target.every((value, axis) => value === input.action.adjacent[axis]))
      throw new TypeError("Structure place target must be the adjacent cell.");
    const storageId = selectedStorageId(input.actor);
    const resolved = resolveStructurePlacementIntentV1(
      environment.registry,
      environment.identity,
      storageId,
      input.action.hit,
      input.action.adjacent,
      input.actor.position
    );
    if (resolved.status !== "resolved") throw new Error(`structure-${resolved.status}`);
    const stateId = environment.policy.placementState(resolved.definition, resolved.bearing);
    return buildStructurePlaceCandidateV1(environment.registry, {
      actor: { ...actor, selectedItemDefinitionId: resolved.definition.placementItemId },
      root: resolved.root,
      stateId,
      read: input.read,
      isReplaceable: environment.policy.isReplaceable,
      isSolid: (voxel2) => environment.semantics.get(voxel2)?.solid === true,
      collides
    });
  }
  if (!input.target.every((value, axis) => value === input.action.hit[axis]))
    throw new TypeError("Structure target must be the hit cell.");
  return input.kind === "toggle" ? buildStructureToggleCandidateV1(environment.registry, {
    actor,
    hit: input.action.hit,
    transitionId: environment.policy.toggleTransitionId(
      environment.registry.require(
        environment.registry.resolveTarget(input.action.hit, input.read)?.definitionId ?? (() => {
          throw new Error("structure-malformed");
        })()
      )
    ),
    read: input.read,
    collides
  }) : buildStructureBreakCandidateV1(environment.registry, { actor, hit: input.action.hit, read: input.read });
}
function defineStructureActionsModuleV1(options) {
  return Object.freeze({
    descriptor: Object.freeze({
      id: options.moduleId,
      version: "1.0.0",
      requires: Object.freeze([
        { id: STRUCTURE_DEFINITIONS_CAPABILITY, version: "1.0.0" },
        { id: ITEMS_CAPABILITY, version: "1.0.0" },
        { id: VOXEL_SEMANTICS_CAPABILITY, version: "1.0.0" },
        { id: VOXEL_GEOMETRY_CAPABILITY, version: "1.0.0" }
      ]),
      provides: Object.freeze([{ id: STRUCTURE_ACTIONS_CAPABILITY, version: "1.0.0" }]),
      resources: Object.freeze([{ id: STRUCTURE_RESOURCE, operations: ["read", "execute"] }]),
      permissions: Object.freeze([{ resource: STRUCTURE_RESOURCE, operations: ["read", "execute"] }])
    }),
    register(api) {
      const registry = api.requireCapability(STRUCTURE_DEFINITIONS_CAPABILITY);
      const items = api.requireCapability(ITEMS_CAPABILITY);
      const semantics = api.requireCapability(VOXEL_SEMANTICS_CAPABILITY);
      const geometry = api.requireCapability(VOXEL_GEOMETRY_CAPABILITY);
      let identityResolver;
      api.onDefinitionsReady(() => {
        identityResolver = createContentItemIdentityResolver({
          items: api.readContentDefinitions().items.map(({ id: id2, storageId }) => ({ id: id2, storageId: storageId ?? id2 }))
        });
      });
      const environment = () => {
        if (!identityResolver) throw new Error("Structure item identities are unavailable.");
        return { registry, identity: identityResolver, semantics, geometry, policy: options.policy };
      };
      api.provideCapability(STRUCTURE_ACTIONS_CAPABILITY, Object.freeze({ policy: options.policy }));
      api.registerState({
        id: STRUCTURE_ACTOR_COMPONENT,
        version: "1.0.0",
        resource: STRUCTURE_RESOURCE,
        validate(value) {
          try {
            validateStructureActorProjectionV1(value, items);
            return true;
          } catch {
            return false;
          }
        }
      });
      api.registerState({
        id: STRUCTURE_VOXEL_COMPONENT,
        version: "1.0.0",
        resource: STRUCTURE_RESOURCE,
        validate(value) {
          try {
            validateStructureVoxelProjectionV1(value);
            return true;
          } catch {
            return false;
          }
        }
      });
      for (const [id2, kind] of [
        [STRUCTURE_PLACE_OPERATION, "place"],
        [STRUCTURE_TOGGLE_OPERATION, "toggle"],
        [STRUCTURE_BREAK_OPERATION, "break"]
      ])
        api.registerOperation({
          id: id2,
          resource: STRUCTURE_RESOURCE,
          run(context, raw, state) {
            if (context.kind !== "actor" || context.target.kind !== "voxel")
              throw new TypeError("Structure operation requires an actor voxel target.");
            const actor = validateStructureActorProjectionV1(
              state.read(structureActorAddress(context.originalActorId)),
              items
            );
            if (actor.reference.entityId !== context.originalActorId)
              throw new TypeError("Structure actor projection does not match the bound actor.");
            const action = validateStructureActionTargetV1(raw);
            return buildRegisteredStructureCandidateV1(environment(), {
              kind,
              actor,
              target: position2(context.target.position, "Structure authorization target"),
              action,
              read: (at2) => validateStructureVoxelProjectionV1(state.read(structureVoxelAddress(at2))).voxel
            });
          }
        });
    }
  });
}

// packages/stdlib/src/server/gameplay/modules/media-playback-model.ts
var NAMESPACE_ID8 = /^[a-z0-9][a-z0-9._-]*:[a-z0-9][a-z0-9._/-]*$/;
var RESOURCE_PATH_SEGMENT = /^[a-zA-Z0-9_-][a-zA-Z0-9._-]*$/;
var MAX_ID_LENGTH = 128;
var MAX_RESOURCE_PATH_LENGTH = 256;
var MAX_TRACKS = 64;
var MAX_DEVICES = 64;
var MAX_BINDINGS_PER_DEVICE = 64;
var MAX_WORLD_COORDINATE3 = 3e7;
var MediaPlaybackModelError = class extends Error {
  constructor(code) {
    super(code);
    this.code = code;
    this.name = "MediaPlaybackModelError";
  }
  code;
};
var record4 = (value, label) => {
  if (!value || typeof value !== "object" || Array.isArray(value)) throw new TypeError(`${label} is invalid.`);
  return value;
};
var exactKeys4 = (value, keys, label) => {
  const allowed = new Set(keys);
  if (Object.keys(value).some((key2) => !allowed.has(key2)) || keys.some((key2) => !Object.hasOwn(value, key2)))
    throw new TypeError(`${label} has an invalid shape.`);
};
var namespaceId = (value, label) => {
  if (typeof value !== "string" || value.length > MAX_ID_LENGTH || !NAMESPACE_ID8.test(value))
    throw new TypeError(`${label} is invalid.`);
  return value;
};
var resourcePath = (value) => {
  const normalized = typeof value === "string" && value.startsWith("./") ? value.slice(2) : value;
  if (typeof normalized !== "string" || normalized.length === 0 || normalized.length > MAX_RESOURCE_PATH_LENGTH || normalized.split("/").some((part) => !RESOURCE_PATH_SEGMENT.test(part)))
    throw new TypeError("Media track resource is invalid.");
  return normalized;
};
var freezeResource = (raw) => {
  const value = record4(raw, "Media track resource");
  exactKeys4(value, ["packId", "path"], "Media track resource");
  return Object.freeze({
    packId: namespaceId(value.packId, "Media track resource pack id"),
    path: resourcePath(value.path)
  });
};
var freezeTarget = (raw) => {
  const value = record4(raw, "Media device target");
  exactKeys4(value, ["kind", "voxelId"], "Media device target");
  if (value.kind !== "voxel") throw new TypeError("Media device target kind is invalid.");
  return Object.freeze({ kind: "voxel", voxelId: namespaceId(value.voxelId, "Media device target voxel id") });
};
var freezeSlot2 = (itemId, trackId) => Object.freeze({ itemId, trackId });
var cloneMediaDeviceInstanceV1 = (raw) => {
  const source = record4(raw, "Media device instance");
  exactKeys4(source, ["kind", "position", "definitionId"], "Media device instance");
  if (source.kind !== "voxel" || !Array.isArray(source.position) || source.position.length !== 3 || Reflect.ownKeys(source.position).length !== 4 || !source.position.every(
    (coordinate) => Number.isSafeInteger(coordinate) && Math.abs(coordinate) <= MAX_WORLD_COORDINATE3
  ))
    throw new TypeError("Media device instance position is invalid.");
  return Object.freeze({
    kind: "voxel",
    position: Object.freeze([...source.position]),
    definitionId: namespaceId(source.definitionId, "Media device instance definition id")
  });
};
var compareId = (left, right) => left.id < right.id ? -1 : left.id > right.id ? 1 : 0;
function defineMediaPlaybackModelV1(input) {
  const source = record4(input, "Media playback model");
  exactKeys4(source, ["version", "tracks", "devices"], "Media playback model");
  if (source.version !== 1) throw new TypeError("Media playback model version is invalid.");
  if (!Array.isArray(source.tracks) || source.tracks.length === 0 || source.tracks.length > MAX_TRACKS)
    throw new TypeError("Media playback tracks are invalid.");
  if (!Array.isArray(source.devices) || source.devices.length === 0 || source.devices.length > MAX_DEVICES)
    throw new TypeError("Media playback devices are invalid.");
  const trackIds = /* @__PURE__ */ new Set();
  const tracks = source.tracks.map((raw, index) => {
    const track = record4(raw, `Media track ${index}`);
    exactKeys4(track, ["id", "resource"], `Media track ${index}`);
    const id2 = namespaceId(track.id, `Media track ${index} id`);
    if (trackIds.has(id2)) throw new TypeError(`Duplicate media track: ${id2}`);
    trackIds.add(id2);
    return Object.freeze({ id: id2, resource: freezeResource(track.resource) });
  });
  const deviceIds = /* @__PURE__ */ new Set();
  const targetSelectors = /* @__PURE__ */ new Set();
  const devices = source.devices.map((raw, index) => {
    const device = record4(raw, `Media device ${index}`);
    const deviceKeys = ["id", "target", "tracks", ...device.playOnInsert === void 0 ? [] : ["playOnInsert"]];
    exactKeys4(device, deviceKeys, `Media device ${index}`);
    const id2 = namespaceId(device.id, `Media device ${index} id`);
    if (device.playOnInsert !== void 0 && device.playOnInsert !== true)
      throw new TypeError(`Media device play-on-insert policy is invalid: ${id2}`);
    if (deviceIds.has(id2)) throw new TypeError(`Duplicate media device: ${id2}`);
    deviceIds.add(id2);
    const target = freezeTarget(device.target);
    const targetKey2 = `${target.kind}:${target.voxelId}`;
    if (targetSelectors.has(targetKey2)) throw new TypeError(`Duplicate media device target: ${targetKey2}`);
    targetSelectors.add(targetKey2);
    if (!Array.isArray(device.tracks) || device.tracks.length === 0 || device.tracks.length > MAX_BINDINGS_PER_DEVICE)
      throw new TypeError(`Media device tracks are invalid: ${id2}`);
    const itemIds = /* @__PURE__ */ new Set();
    const bindings = device.tracks.map((rawBinding, bindingIndex) => {
      const binding = record4(rawBinding, `Media device ${id2} track ${bindingIndex}`);
      exactKeys4(binding, ["itemId", "trackId"], `Media device ${id2} track ${bindingIndex}`);
      const itemId = namespaceId(binding.itemId, `Media device ${id2} item id`);
      const trackId = namespaceId(binding.trackId, `Media device ${id2} track id`);
      if (itemIds.has(itemId)) throw new TypeError(`Duplicate media item binding: ${id2} ${itemId}`);
      if (!trackIds.has(trackId)) throw new TypeError(`Media device ${id2} references unknown track: ${trackId}`);
      itemIds.add(itemId);
      return Object.freeze({ itemId, trackId });
    });
    bindings.sort(
      (left, right) => left.itemId < right.itemId ? -1 : left.itemId > right.itemId ? 1 : left.trackId.localeCompare(right.trackId)
    );
    return Object.freeze({
      id: id2,
      target,
      tracks: Object.freeze(bindings),
      ...device.playOnInsert === true ? { playOnInsert: true } : {}
    });
  });
  tracks.sort(compareId);
  devices.sort(compareId);
  return Object.freeze({ version: 1, tracks: Object.freeze(tracks), devices: Object.freeze(devices) });
}
var requireDevice = (model, deviceId) => {
  const device = model.devices.find((candidate2) => candidate2.id === deviceId);
  if (!device) throw new RangeError(`Unknown media device: ${deviceId}`);
  return device;
};
var requireTrack = (model, trackId) => {
  const track = model.tracks.find((candidate2) => candidate2.id === trackId);
  if (!track) throw new RangeError(`Unknown media track: ${trackId}`);
  return track;
};
var bindingFor = (model, deviceId, itemId) => {
  const binding = requireDevice(model, deviceId).tracks.find((candidate2) => candidate2.itemId === itemId);
  if (!binding) throw new MediaPlaybackModelError("unsupported-media");
  return binding;
};
var freezeState = (state) => Object.freeze({ ...state, slot: state.slot ? freezeSlot2(state.slot.itemId, state.slot.trackId) : null });
function createMediaPlaybackStateV1(model, deviceIdValue) {
  const deviceId = namespaceId(deviceIdValue, "Media playback device id");
  requireDevice(model, deviceId);
  return freezeState({ version: 1, deviceId, revision: 0, slot: null, playing: false, resumePending: false });
}
var decodeSlot = (model, deviceId, raw) => {
  if (raw === null) return null;
  const slot = record4(raw, "Media playback slot");
  exactKeys4(slot, ["itemId", "trackId"], "Media playback slot");
  const itemId = namespaceId(slot.itemId, "Media playback item id");
  const trackId = namespaceId(slot.trackId, "Media playback track id");
  const binding = bindingFor(model, deviceId, itemId);
  if (binding.trackId !== trackId) throw new TypeError("Media playback slot track does not match its item binding.");
  requireTrack(model, trackId);
  return freezeSlot2(itemId, trackId);
};
function restoreMediaPlaybackStateV1(model, deviceIdValue, raw) {
  const deviceId = namespaceId(deviceIdValue, "Media playback device id");
  requireDevice(model, deviceId);
  if (raw === void 0) return createMediaPlaybackStateV1(model, deviceId);
  const snapshot = record4(raw, "Media playback snapshot");
  exactKeys4(snapshot, ["version", "deviceId", "revision", "slot", "playingIntent"], "Media playback snapshot");
  if (snapshot.version !== 1 || snapshot.deviceId !== deviceId)
    throw new TypeError("Media playback snapshot identity is invalid.");
  if (!Number.isSafeInteger(snapshot.revision) || snapshot.revision < 0)
    throw new TypeError("Media playback snapshot revision is invalid.");
  if (typeof snapshot.playingIntent !== "boolean")
    throw new TypeError("Media playback snapshot playing intent is invalid.");
  const slot = decodeSlot(model, deviceId, snapshot.slot);
  if (!slot && snapshot.playingIntent) throw new TypeError("Empty media playback slot cannot retain playing intent.");
  return freezeState({
    version: 1,
    deviceId,
    revision: snapshot.revision,
    slot,
    playing: false,
    resumePending: Boolean(slot && snapshot.playingIntent)
  });
}
var validateLiveState = (model, raw) => {
  const state = record4(raw, "Media playback state");
  exactKeys4(state, ["version", "deviceId", "revision", "slot", "playing", "resumePending"], "Media playback state");
  if (state.version !== 1) throw new TypeError("Media playback state version is invalid.");
  const deviceId = namespaceId(state.deviceId, "Media playback state device id");
  requireDevice(model, deviceId);
  if (!Number.isSafeInteger(state.revision) || state.revision < 0)
    throw new TypeError("Media playback state revision is invalid.");
  if (typeof state.playing !== "boolean" || typeof state.resumePending !== "boolean" || state.playing && state.resumePending)
    throw new TypeError("Media playback state flags are invalid.");
  const slot = decodeSlot(model, deviceId, state.slot);
  if (!slot && (state.playing || state.resumePending))
    throw new TypeError("Empty media playback slot cannot be active.");
  return freezeState({
    version: 1,
    deviceId,
    revision: state.revision,
    slot,
    playing: state.playing,
    resumePending: state.resumePending
  });
};
var decodeAction = (raw) => {
  const action = record4(raw, "Media playback action");
  if (action.kind === "insert" || action.kind === "insert-and-activate" || action.kind === "switch") {
    exactKeys4(action, ["kind", "itemId"], "Media playback action");
    return Object.freeze({ kind: action.kind, itemId: namespaceId(action.itemId, "Media playback action item id") });
  }
  if (action.kind === "eject" || action.kind === "activate" || action.kind === "stop") {
    exactKeys4(action, ["kind"], "Media playback action");
    return Object.freeze({ kind: action.kind });
  }
  throw new MediaPlaybackModelError("invalid-action");
};
function buildMediaPlaybackCandidateV1(input) {
  const current2 = validateLiveState(input.model, input.state);
  const device = cloneMediaDeviceInstanceV1(input.device);
  if (device.definitionId !== current2.deviceId) throw new TypeError("Media candidate device identity is invalid.");
  if (!Number.isSafeInteger(input.expectedRevision) || input.expectedRevision !== current2.revision)
    throw new MediaPlaybackModelError("stale-revision");
  if (current2.revision === Number.MAX_SAFE_INTEGER) throw new MediaPlaybackModelError("revision-exhausted");
  const action = decodeAction(input.action);
  const previousSlot = current2.slot;
  let slot = previousSlot;
  let playing = current2.playing;
  let resumePending = current2.resumePending;
  let insertedItemId;
  let ejectedItemId;
  if (action.kind === "insert" || action.kind === "insert-and-activate") {
    if (slot) throw new MediaPlaybackModelError("slot-occupied");
    const binding = bindingFor(input.model, current2.deviceId, action.itemId);
    slot = freezeSlot2(binding.itemId, binding.trackId);
    insertedItemId = binding.itemId;
    playing = action.kind === "insert-and-activate";
    resumePending = false;
  } else if (action.kind === "eject") {
    if (!slot) throw new MediaPlaybackModelError("empty-slot");
    ejectedItemId = slot.itemId;
    slot = null;
    playing = false;
    resumePending = false;
  } else if (action.kind === "activate") {
    if (!slot) throw new MediaPlaybackModelError("empty-slot");
    if (playing) throw new MediaPlaybackModelError("already-playing");
    playing = true;
    resumePending = false;
  } else if (action.kind === "stop") {
    if (!slot) throw new MediaPlaybackModelError("empty-slot");
    if (!playing && !resumePending) throw new MediaPlaybackModelError("already-stopped");
    playing = false;
    resumePending = false;
  } else {
    if (!slot) throw new MediaPlaybackModelError("empty-slot");
    const binding = bindingFor(input.model, current2.deviceId, action.itemId);
    if (binding.itemId === slot.itemId) throw new MediaPlaybackModelError("same-media");
    ejectedItemId = slot.itemId;
    insertedItemId = binding.itemId;
    slot = freezeSlot2(binding.itemId, binding.trackId);
  }
  const state = freezeState({
    version: 1,
    deviceId: current2.deviceId,
    revision: current2.revision + 1,
    slot,
    playing,
    resumePending
  });
  const track = state.slot ? requireTrack(input.model, state.slot.trackId) : null;
  const fact = Object.freeze({
    version: 1,
    kind: action.kind,
    device,
    revision: state.revision,
    previousTrackId: previousSlot?.trackId ?? null,
    trackId: state.slot?.trackId ?? null,
    resource: track ? freezeResource(track.resource) : null,
    playing: state.playing,
    resumePending: state.resumePending,
    ...insertedItemId ? { insertedItemId } : {},
    ...ejectedItemId ? { ejectedItemId } : {}
  });
  return Object.freeze({ state, fact });
}

// packages/stdlib/src/server/gameplay/modules/media-playback-module.ts
var MEDIA_PLAYBACK_MODULE_ID = "seedlands:media-playback-module";
var MEDIA_PLAYBACK_CAPABILITY = "seedlands:media-playback";
var MEDIA_PLAYBACK_COMPONENT = "seedlands:media-playback-device";
var MEDIA_PLAYBACK_RESOURCE = "seedlands.media-playback";
var MEDIA_INSERT_OPERATION = "seedlands:media-insert";
var MEDIA_INSERT_AND_ACTIVATE_OPERATION = "seedlands:media-insert-and-activate";
var MEDIA_EJECT_OPERATION = "seedlands:media-eject";
var MEDIA_ACTIVATE_OPERATION = "seedlands:media-activate";
var MEDIA_STOP_OPERATION = "seedlands:media-stop";
var MEDIA_SWITCH_OPERATION = "seedlands:media-switch";
var mediaPlaybackAddress = (target) => Object.freeze({ componentId: MEDIA_PLAYBACK_COMPONENT, target });
var isInvocationRecord = (value) => value !== null && typeof value === "object" && !Array.isArray(value);
var inputRecord = (value) => {
  if (!isInvocationRecord(value)) throw new TypeError("Media playback operation input is invalid.");
  return value;
};
var operationInput = (value, kind) => {
  const input = inputRecord(value);
  const withItem = kind === "insert" || kind === "insert-and-activate" || kind === "switch";
  const allowed = new Set(withItem ? ["expectedRevision", "itemId"] : ["expectedRevision"]);
  if (Object.keys(input).some((key2) => !allowed.has(key2)) || !Object.hasOwn(input, "expectedRevision") || !Number.isSafeInteger(input.expectedRevision) || input.expectedRevision < 0)
    throw new TypeError("Media playback operation input is invalid.");
  if (withItem) {
    if (!Object.hasOwn(input, "itemId") || typeof input.itemId !== "string")
      throw new TypeError("Media playback item input is invalid.");
    return Object.freeze({
      expectedRevision: input.expectedRevision,
      action: Object.freeze({ kind, itemId: input.itemId })
    });
  }
  return Object.freeze({ expectedRevision: input.expectedRevision, action: Object.freeze({ kind }) });
};
var mediaTarget = (target) => {
  if (target.kind !== "voxel") throw new TypeError("Media playback requires a voxel device target.");
  return target;
};
function defineMediaPlaybackModuleV1(input) {
  const moduleId = input.moduleId ?? MEDIA_PLAYBACK_MODULE_ID;
  let model;
  const resolve = () => model ??= defineMediaPlaybackModelV1(input.definition);
  return Object.freeze({
    descriptor: {
      id: moduleId,
      version: "1.0.0",
      provides: [{ id: MEDIA_PLAYBACK_CAPABILITY, version: "1.0.0" }],
      resources: [{ id: MEDIA_PLAYBACK_RESOURCE, operations: ["read", "write", "execute"] }],
      permissions: [{ resource: MEDIA_PLAYBACK_RESOURCE, operations: ["read", "write", "execute"] }]
    },
    register(api) {
      api.provideCapability(MEDIA_PLAYBACK_CAPABILITY, Object.freeze({ resolve }));
      api.onDefinitionsReady(() => {
        const defined = resolve();
        const content = api.readContentDefinitions();
        const items = new Map(content.items.map((item) => [item.id, item]));
        const voxelIds = new Set(content.voxels.map((voxel2) => voxel2.id));
        for (const device of defined.devices) {
          if (!voxelIds.has(device.target.voxelId))
            throw new TypeError(`Media device ${device.id} references unknown voxel: ${device.target.voxelId}`);
          for (const binding of device.tracks) {
            const item = items.get(binding.itemId);
            if (!item) throw new TypeError(`Media device ${device.id} references unknown item: ${binding.itemId}`);
            if (item.durability !== void 0)
              throw new TypeError(
                `Media device ${device.id} cannot bind an item with instance state: ${binding.itemId}`
              );
          }
        }
      });
      api.registerState({
        id: MEDIA_PLAYBACK_COMPONENT,
        version: "1.0.0",
        resource: MEDIA_PLAYBACK_RESOURCE,
        validate(value) {
          try {
            if (!value || typeof value !== "object" || Array.isArray(value) || !("deviceId" in value)) return false;
            const keys = /* @__PURE__ */ new Set(["version", "deviceId", "revision", "slot", "playing", "resumePending"]);
            if (Object.keys(value).length !== keys.size || Object.keys(value).some((key2) => !keys.has(key2)))
              return false;
            if (value.version !== 1 || typeof value.deviceId !== "string") return false;
            restoreMediaPlaybackStateV1(resolve(), String(value.deviceId), {
              version: 1,
              deviceId: value.deviceId,
              revision: value.revision,
              slot: value.slot,
              playingIntent: Boolean(value.playing || value.resumePending)
            });
            return (value.playing === true || value.playing === false) && (value.resumePending === true || value.resumePending === false) && !(value.playing && value.resumePending);
          } catch {
            return false;
          }
        }
      });
      const register = (id2, kind) => api.registerOperation({
        id: id2,
        resource: MEDIA_PLAYBACK_RESOURCE,
        run(context, value, state) {
          const target = mediaTarget(context.target);
          const parsed = operationInput(value, kind);
          const address = mediaPlaybackAddress(target);
          const current2 = state.read(address);
          const device = resolve().devices.find((entry) => entry.id === current2.deviceId);
          if (!device) throw new TypeError("Media playback device definition is unavailable.");
          const candidate2 = buildMediaPlaybackCandidateV1({
            model: resolve(),
            device: { kind: "voxel", position: target.position, definitionId: device.id },
            state: current2,
            expectedRevision: parsed.expectedRevision,
            action: parsed.action
          });
          state.write(address, candidate2.state);
          return candidate2.fact;
        }
      });
      register(MEDIA_INSERT_OPERATION, "insert");
      register(MEDIA_INSERT_AND_ACTIVATE_OPERATION, "insert-and-activate");
      register(MEDIA_EJECT_OPERATION, "eject");
      register(MEDIA_ACTIVATE_OPERATION, "activate");
      register(MEDIA_STOP_OPERATION, "stop");
      register(MEDIA_SWITCH_OPERATION, "switch");
    }
  });
}

// packages/stdlib/src/server/gameplay/modules/item-interaction-module.ts
var ITEM_INTERACTION_CAPABILITY = "seedlands:item-interactions";
var NAMESPACE_ID9 = /^[a-z0-9][a-z0-9._-]*:[a-z0-9][a-z0-9._/-]*$/;
var PRESENTATION_KEY = /^[a-z0-9][a-z0-9._:-]{0,127}$/;
function hasExecutePermission(module, resource) {
  return Boolean(
    module?.permissions.some(
      (permission) => permission.resource === resource && permission.operations.includes("execute")
    )
  );
}
function snapshotDefinition(raw) {
  if (!raw || typeof raw !== "object" || !NAMESPACE_ID9.test(raw.id))
    throw new TypeError("Item interaction id is invalid.");
  if (!raw.selector || typeof raw.selector !== "object" || !NAMESPACE_ID9.test(raw.selector.itemId))
    throw new TypeError(`Item interaction selector is invalid: ${raw.id}`);
  if (!["self", "voxel", "entity"].includes(raw.trigger))
    throw new TypeError(`Item interaction trigger is invalid: ${raw.id}`);
  if (!NAMESPACE_ID9.test(raw.operationId)) throw new TypeError(`Item interaction operation is invalid: ${raw.id}`);
  if (!PRESENTATION_KEY.test(raw.presentationKey))
    throw new TypeError(`Item interaction presentation key is invalid: ${raw.id}`);
  return Object.freeze({
    id: raw.id,
    selector: Object.freeze({ itemId: raw.selector.itemId }),
    trigger: raw.trigger,
    operationId: raw.operationId,
    presentationKey: raw.presentationKey
  });
}
function createItemInteractionRegistry() {
  const registered = /* @__PURE__ */ new Map();
  const selectors = /* @__PURE__ */ new Set();
  let resolved = null;
  return Object.freeze({
    register(identity5, raw) {
      if (resolved) throw new TypeError("Item interaction registry is frozen.");
      const definition2 = snapshotDefinition(raw);
      if (registered.has(definition2.id)) throw new TypeError(`Duplicate item interaction: ${definition2.id}`);
      const selector = `${definition2.selector.itemId}:${definition2.trigger}`;
      if (selectors.has(selector)) throw new TypeError(`Item interaction item/trigger conflict: ${selector}`);
      selectors.add(selector);
      registered.set(definition2.id, Object.freeze({ identity: Object.freeze({ ...identity5 }), definition: definition2 }));
    },
    freeze(definitions3, items) {
      if (resolved) throw new TypeError("Item interaction registry is already frozen.");
      const byId = new Map(items.map((item) => [item.id, item]));
      const next = [];
      for (const { identity: identity5, definition: definition2 } of registered.values()) {
        const item = byId.get(definition2.selector.itemId);
        if (!item) throw new TypeError(`Item interaction references unknown item: ${definition2.selector.itemId}`);
        const operation = definitions3.operation(definition2.operationId);
        if (!operation) throw new TypeError(`Item interaction operation is missing: ${definition2.operationId}`);
        if (operation.executionKind !== "actor")
          throw new TypeError(`Item interaction operation is not actor-executable: ${definition2.operationId}`);
        if (!hasExecutePermission(definitions3.module(operation.moduleId), operation.resource))
          throw new TypeError(`Item interaction operation owner has no execute permission: ${definition2.operationId}`);
        if (!hasExecutePermission(definitions3.module(identity5.moduleId), operation.resource))
          throw new TypeError(`Item interaction provider has no execute permission: ${definition2.operationId}`);
        next.push(
          Object.freeze({
            definition: definition2,
            moduleId: identity5.moduleId,
            itemId: item.storageId ?? item.id
          })
        );
      }
      resolved = Object.freeze(next.sort((left, right) => left.definition.id.localeCompare(right.definition.id)));
    },
    capability() {
      return Object.freeze({
        resolve(itemId, trigger) {
          if (!resolved) throw new TypeError("Item interaction registry is not frozen.");
          return resolved.find((entry) => entry.itemId === itemId && entry.definition.trigger === trigger) ?? null;
        },
        list() {
          if (!resolved) throw new TypeError("Item interaction registry is not frozen.");
          return resolved;
        }
      });
    }
  });
}
function defineItemInteractionModule(input) {
  if (!NAMESPACE_ID9.test(input.moduleId)) throw new TypeError("Item interaction module id is invalid.");
  if (!Array.isArray(input.definitions)) throw new TypeError("Item interaction definitions must be an array.");
  const definitions3 = Object.freeze(input.definitions.map(snapshotDefinition));
  return Object.freeze({
    descriptor: {
      id: input.moduleId,
      version: "1.0.0",
      provides: [{ id: ITEM_INTERACTION_CAPABILITY, version: "1.0.0" }],
      ...input.permissions ? { permissions: input.permissions } : {}
    },
    register(api) {
      const registry = createItemInteractionRegistry();
      for (const definition2 of definitions3) registry.register(api.identity, definition2);
      api.provideCapability(ITEM_INTERACTION_CAPABILITY, registry.capability());
      api.onDefinitionsReady((definitions4) => registry.freeze(definitions4, api.readContentDefinitions().items));
    }
  });
}

// packages/stdlib/src/server/gameplay/modules/block-action-model.ts
var BLOCK_ACTIONS_CAPABILITY = "seedlands:block-actions";
var BLOCK_RULES_CAPABILITY = "seedlands:block-rules";
var BLOCK_ACTOR_COMPONENT = "seedlands:block-actor";
var BLOCK_VOXEL_COMPONENT = "seedlands:block-voxel";
var BLOCK_WORLD_COMPONENT = "seedlands:block-world";
var BLOCK_ACTOR_RESOURCE = "seedlands.block-actor";
var BLOCK_VOXEL_RESOURCE = "seedlands.block-voxel";
var BLOCK_CLOCK_RESOURCE = "seedlands.block-clock";
var BLOCK_BEGIN_OPERATION = "seedlands:block-begin";
var BLOCK_CANCEL_OPERATION = "seedlands:block-cancel";
var BLOCK_PLACE_OPERATION = "seedlands:block-place";
var BLOCK_FINISH_OPERATION = "seedlands:block-finish";
var BLOCK_ADVANCE_OPERATION = "seedlands:block-advance";
var BLOCK_SYSTEM = "seedlands:block-system";
var BLOCK_PARTITIONS = 8;
var BLOCK_PARTITION_SIZE = 16;
var MAX_IDENTITY_LENGTH4 = 256;
var MAX_INVENTORY_CAPACITY2 = 64;
var MAX_SECONDS = 1e6;
var MAX_VOXEL3 = 65535;
var MAX_WORLD_COORDINATE4 = 3e7;
var blockActorAddress = (entityId) => ({
  componentId: BLOCK_ACTOR_COMPONENT,
  target: { kind: "entity", entityId }
});
var blockVoxelAddress = (position4) => ({
  componentId: BLOCK_VOXEL_COMPONENT,
  target: { kind: "voxel", position: position4 }
});
var blockWorldAddress = (partition) => ({
  componentId: BLOCK_WORLD_COMPONENT,
  target: { kind: "world" },
  partition
});
var blockActionsCapability = () => Object.freeze({
  actorComponentId: BLOCK_ACTOR_COMPONENT,
  voxelComponentId: BLOCK_VOXEL_COMPONENT,
  worldComponentId: BLOCK_WORLD_COMPONENT,
  beginOperationId: BLOCK_BEGIN_OPERATION,
  cancelOperationId: BLOCK_CANCEL_OPERATION,
  placeOperationId: BLOCK_PLACE_OPERATION,
  finishOperationId: BLOCK_FINISH_OPERATION,
  advanceOperationId: BLOCK_ADVANCE_OPERATION,
  partitions: BLOCK_PARTITIONS
});
function blockData(raw, allowed, label) {
  if (!raw || typeof raw !== "object" || Array.isArray(raw) || ![Object.prototype, null].includes(Object.getPrototypeOf(raw)))
    throw new TypeError(`${label} must be an object.`);
  const descriptors = Object.getOwnPropertyDescriptors(raw);
  for (const key2 of Reflect.ownKeys(descriptors))
    if (typeof key2 !== "string" || !allowed.includes(key2) || !descriptors[key2].enumerable || !("value" in descriptors[key2]))
      throw new TypeError(`${label} has invalid fields.`);
  if (Object.keys(descriptors).length !== allowed.length || allowed.some((key2) => !descriptors[key2]))
    throw new TypeError(`${label} has missing fields.`);
  return raw;
}
var identity4 = (value) => typeof value === "string" && value.length > 0 && value.length <= MAX_IDENTITY_LENGTH4 && value.trim() === value;
var safeInteger2 = (value, min, max) => typeof value === "number" && Number.isSafeInteger(value) && value >= min && value <= max;
var finite3 = (value, min, max) => typeof value === "number" && Number.isFinite(value) && value >= min && value <= max;
var voxelId = (value) => safeInteger2(value, Voxel.Air, MAX_VOXEL3);
function validateBlockPosition(raw, label = "Block position") {
  if (!Array.isArray(raw) || raw.length !== 3 || !raw.every((value) => safeInteger2(value, -MAX_WORLD_COORDINATE4, MAX_WORLD_COORDINATE4)))
    throw new TypeError(`${label} is invalid.`);
  return Object.freeze([raw[0], raw[1], raw[2]]);
}
function cloneBlockReference(raw) {
  const value = blockData(raw, ["entityId", "epoch", "lifetime"], "Block entity reference");
  if (!identity4(value.entityId) || !safeInteger2(value.epoch, 1, Number.MAX_SAFE_INTEGER) || !safeInteger2(value.lifetime, 1, Number.MAX_SAFE_INTEGER))
    throw new TypeError("Block entity reference is invalid.");
  return Object.freeze({ entityId: value.entityId, epoch: value.epoch, lifetime: value.lifetime });
}
function cloneBlockStack(items, raw, enforceLimit) {
  const hasInstance = Boolean(raw) && typeof raw === "object" && Object.hasOwn(raw, "instance");
  const value = blockData(raw, hasInstance ? ["itemId", "count", "instance"] : ["itemId", "count"], "Block item stack");
  if (hasInstance) blockData(value.instance, ["durability"], "Block item instance");
  const stack2 = items.normalizeStack(raw);
  if (enforceLimit && stack2.count > items.require(stack2.itemId).stackLimit)
    throw new TypeError("Block inventory stack exceeds its limit.");
  return Object.freeze({
    itemId: stack2.itemId,
    count: stack2.count,
    ...stack2.instance ? { instance: Object.freeze({ durability: stack2.instance.durability }) } : {}
  });
}
function validateBlockBreakAction(raw) {
  const hasOrigin = Boolean(raw) && typeof raw === "object" && Object.hasOwn(raw, "origin");
  const value = blockData(
    raw,
    hasOrigin ? ["position", "voxel", "elapsedSeconds", "requiredSeconds", "origin"] : ["position", "voxel", "elapsedSeconds", "requiredSeconds"],
    "Block break action"
  );
  if (!voxelId(value.voxel) || !finite3(value.elapsedSeconds, 0, MAX_SECONDS) || !finite3(value.requiredSeconds, Number.EPSILON, MAX_SECONDS))
    throw new TypeError("Block break action is invalid.");
  return Object.freeze({
    position: validateBlockPosition(value.position, "Block break position"),
    voxel: value.voxel,
    elapsedSeconds: value.elapsedSeconds,
    requiredSeconds: value.requiredSeconds,
    ...hasOrigin ? { origin: validateDurableExecutionOrigin(value.origin) } : {}
  });
}
function validateBlockActorProjection(raw, items) {
  const value = blockData(
    raw,
    [
      "version",
      "reference",
      "kind",
      "position",
      "lifecycle",
      "mode",
      "slots",
      "equipment",
      "creativeCatalog",
      "breakAction"
    ],
    "Block actor projection"
  );
  if (value.version !== 1 || value.kind !== "player" || !["alive", "dead"].includes(String(value.lifecycle)))
    throw new TypeError("Block actor projection is invalid.");
  if (!Array.isArray(value.position) || value.position.length !== 3 || Object.keys(value.position).length !== 3 || !value.position.every((entry) => finite3(entry, -MAX_WORLD_COORDINATE4, MAX_WORLD_COORDINATE4)))
    throw new TypeError("Block actor position is invalid.");
  const position4 = Object.freeze([value.position[0], value.position[1], value.position[2]]);
  if (!Array.isArray(value.slots) || value.slots.length < 1 || value.slots.length > MAX_INVENTORY_CAPACITY2)
    throw new TypeError("Block actor inventory is invalid.");
  const slots = Object.freeze(value.slots.map((slot) => slot === null ? null : cloneBlockStack(items, slot, true)));
  const mode = blockData(value.mode, ["value", "revision"], "Block actor mode");
  if (!["survival", "creative"].includes(String(mode.value)) || !safeInteger2(mode.revision, 0, Number.MAX_SAFE_INTEGER))
    throw new TypeError("Block actor mode is invalid.");
  const equipment = blockData(value.equipment, ["selectedSlot", "hotbarSize"], "Block actor equipment");
  if (!safeInteger2(equipment.hotbarSize, 1, slots.length) || !safeInteger2(equipment.selectedSlot, 0, equipment.hotbarSize - 1))
    throw new TypeError("Block actor equipment is invalid.");
  const catalog = blockData(value.creativeCatalog, ["hotbar", "selectedSlot"], "Block creative catalog");
  if (!Array.isArray(catalog.hotbar) || catalog.hotbar.length < 1 || catalog.hotbar.length > MAX_INVENTORY_CAPACITY2 || !safeInteger2(catalog.selectedSlot, 0, catalog.hotbar.length - 1))
    throw new TypeError("Block creative catalog is invalid.");
  const hotbar2 = Object.freeze(
    catalog.hotbar.map((itemId) => {
      if (itemId !== null && (!identity4(itemId) || !items.has(itemId)))
        throw new TypeError("Block creative catalog item is invalid.");
      return itemId;
    })
  );
  return Object.freeze({
    version: 1,
    reference: cloneBlockReference(value.reference),
    kind: "player",
    position: position4,
    lifecycle: value.lifecycle,
    mode: Object.freeze({ value: mode.value, revision: mode.revision }),
    slots,
    equipment: Object.freeze({ selectedSlot: equipment.selectedSlot, hotbarSize: equipment.hotbarSize }),
    creativeCatalog: Object.freeze({ hotbar: hotbar2, selectedSlot: catalog.selectedSlot }),
    breakAction: value.breakAction === null ? null : validateBlockBreakAction(value.breakAction)
  });
}
function validateBlockVoxelProjection(raw) {
  const hasFluid = Boolean(raw) && typeof raw === "object" && Object.hasOwn(raw, "fluid");
  const value = blockData(
    raw,
    ["version", "position", "voxel", ...hasFluid ? ["fluid"] : []],
    "Block voxel projection"
  );
  if (value.version !== 1 || !voxelId(value.voxel)) throw new TypeError("Block voxel projection is invalid.");
  let fluid;
  if (hasFluid) {
    if (value.fluid === null) fluid = null;
    else {
      const cell = blockData(value.fluid, ["level", "source"], "Block fluid cell");
      if (!safeInteger2(cell.level, 1, 8) || typeof cell.source !== "boolean")
        throw new TypeError("Block fluid cell is invalid.");
      fluid = Object.freeze({ level: cell.level, source: cell.source });
    }
  }
  return Object.freeze({
    version: 1,
    position: validateBlockPosition(value.position),
    voxel: value.voxel,
    ...fluid === void 0 ? {} : { fluid }
  });
}
function validateBlockWorldProjection(raw) {
  const value = blockData(raw, ["version", "partition", "entries"], "Block world projection");
  if (value.version !== 1 || !safeInteger2(value.partition, 0, BLOCK_PARTITIONS - 1) || !Array.isArray(value.entries) || value.entries.length > BLOCK_PARTITION_SIZE)
    throw new TypeError("Block world projection is invalid.");
  let previous = "";
  const entries = Object.freeze(
    value.entries.map((rawEntry) => {
      const entry = blockData(rawEntry, ["reference", "breakAction"], "Block world entry");
      const reference3 = cloneBlockReference(entry.reference);
      if (reference3.entityId <= previous) throw new TypeError("Block world entries are duplicated or unsorted.");
      previous = reference3.entityId;
      return Object.freeze({
        reference: reference3,
        breakAction: entry.breakAction === null ? null : validateBlockBreakAction(entry.breakAction)
      });
    })
  );
  return Object.freeze({ version: 1, partition: value.partition, entries });
}
function validateBlockTargetInput(raw) {
  const value = blockData(raw, ["position"], "Block target input");
  return Object.freeze({ position: validateBlockPosition(value.position) });
}
function validateBlockBeginEffectiveInput(raw) {
  const value = blockData(
    raw,
    ["position", "expectedVoxel", "creative", "requiredSeconds", "modeRevision"],
    "Block begin effective input"
  );
  if (!voxelId(value.expectedVoxel) || typeof value.creative !== "boolean" || !finite3(value.requiredSeconds, 0, MAX_SECONDS) || !safeInteger2(value.modeRevision, 0, Number.MAX_SAFE_INTEGER) || (value.creative ? value.requiredSeconds !== 0 : value.requiredSeconds <= 0))
    throw new TypeError("Block begin policy is invalid.");
  return Object.freeze({
    position: validateBlockPosition(value.position),
    expectedVoxel: value.expectedVoxel,
    creative: value.creative,
    requiredSeconds: value.requiredSeconds,
    modeRevision: value.modeRevision
  });
}
function validateBlockPlaceEffectiveInput(raw) {
  const value = blockData(
    raw,
    ["position", "expectedVoxel", "placedVoxel", "itemId", "consumeCount", "modeRevision"],
    "Block place effective input"
  );
  if (!voxelId(value.expectedVoxel) || !voxelId(value.placedVoxel) || value.placedVoxel === Voxel.Air || !identity4(value.itemId) || value.consumeCount !== 0 && value.consumeCount !== 1 || !safeInteger2(value.modeRevision, 0, Number.MAX_SAFE_INTEGER))
    throw new TypeError("Block placement policy is invalid.");
  return Object.freeze({
    position: validateBlockPosition(value.position),
    expectedVoxel: value.expectedVoxel,
    placedVoxel: value.placedVoxel,
    itemId: value.itemId,
    consumeCount: value.consumeCount,
    modeRevision: value.modeRevision
  });
}
function validateBlockFinishEffectiveInput(raw, items) {
  const hasWear = typeof raw === "object" && raw !== null && Object.hasOwn(raw, "toolWear");
  const value = blockData(
    raw,
    ["position", "expectedVoxel", "creative", "drop", "modeRevision", ...hasWear ? ["toolWear"] : []],
    "Block finish effective input"
  );
  if (hasWear && (value.toolWear !== 0 && value.toolWear !== 1 || value.creative === true && value.toolWear !== 0))
    throw new TypeError("Block finish tool wear is invalid.");
  if (!voxelId(value.expectedVoxel) || typeof value.creative !== "boolean" || !safeInteger2(value.modeRevision, 0, Number.MAX_SAFE_INTEGER) || value.creative && value.drop !== null)
    throw new TypeError("Block finish policy is invalid.");
  return Object.freeze({
    position: validateBlockPosition(value.position),
    expectedVoxel: value.expectedVoxel,
    creative: value.creative,
    ...hasWear ? { toolWear: value.toolWear } : {},
    drop: value.drop === null ? null : cloneBlockStack(items, value.drop, false),
    modeRevision: value.modeRevision
  });
}
function validateBlockAdvanceInput(raw) {
  const hasCancellations = Boolean(raw) && typeof raw === "object" && Object.hasOwn(raw, "cancelActorIds");
  const value = blockData(raw, hasCancellations ? ["seconds", "cancelActorIds"] : ["seconds"], "Block advance input");
  if (!finite3(value.seconds, 0, 1)) throw new TypeError("Block advance must be between 0 and 1 second.");
  const ids = hasCancellations ? value.cancelActorIds : [];
  if (!Array.isArray(ids) || ids.length > BLOCK_PARTITIONS * BLOCK_PARTITION_SIZE || ids.some((id2) => !identity4(id2)) || new Set(ids).size !== ids.length)
    throw new TypeError("Block cancellation actor identities are invalid or duplicated.");
  return Object.freeze({ seconds: value.seconds, cancelActorIds: Object.freeze([...ids]) });
}

// packages/stdlib/src/server/gameplay/modules/fluid-container-interaction.ts
var FLUID_CONTAINER_INTERACTION_CAPABILITY = "seedlands:fluid-container-interaction";
var samePosition = (left, right) => left.length === right.length && left.every((value, index) => value === right[index]);
var adjacent = (left, right) => left.reduce((sum, value, index) => sum + Math.abs(value - right[index]), 0) === 1;
var fail3 = (reason) => {
  throw new Error(reason);
};
function buildFluidContainerInteractionCandidate(items, config, rawActor, rawHit, rawAdjacent, rawInput) {
  const actor = validateBlockActorProjection(rawActor, items);
  const hit = validateBlockVoxelProjection(rawHit);
  const next = validateBlockVoxelProjection(rawAdjacent);
  const input = rawInput;
  if (input?.version !== 1 || input.trigger !== "voxel" || input.target?.kind !== "voxel")
    throw new TypeError("Fluid interaction input is invalid.");
  const inputHit = validateBlockPosition(input.target.hit, "Fluid interaction hit");
  const inputAdjacent = validateBlockPosition(input.target.adjacent, "Fluid interaction adjacent");
  if (!samePosition(hit.position, inputHit) || !samePosition(next.position, inputAdjacent) || !adjacent(inputHit, inputAdjacent))
    throw new TypeError("Fluid interaction target does not match its projections.");
  if (actor.lifecycle !== "alive") fail3("player-dead");
  const creative = actor.mode.value === "creative";
  const selectedItemId = creative ? actor.creativeCatalog.hotbar[actor.creativeCatalog.selectedSlot] : actor.slots[actor.equipment.selectedSlot]?.itemId;
  if (!selectedItemId) fail3("no-selected-item");
  const inventory = createInventoryCandidate(items, actor.slots);
  let action;
  let targetPosition2;
  let fromVoxel;
  let toVoxel;
  let outputItemId;
  if (selectedItemId === config.emptyItemId) {
    const source = config.filled.find(({ voxel: voxel2 }) => voxel2 === hit.voxel);
    if (!source || hit.fluid?.source !== true || hit.fluid.level !== 8) fail3("not-fluid-source");
    action = "fill";
    targetPosition2 = Object.freeze([...hit.position]);
    fromVoxel = hit.voxel;
    toVoxel = config.emptyVoxel;
    outputItemId = source.itemId;
  } else {
    const source = config.filled.find(({ itemId }) => itemId === selectedItemId);
    if (!source) fail3("item-no-interaction");
    if (!config.replaceableVoxels.includes(next.voxel)) fail3("target-occupied");
    action = "empty";
    targetPosition2 = Object.freeze([...next.position]);
    fromVoxel = next.voxel;
    toVoxel = source.voxel;
    outputItemId = config.emptyItemId;
  }
  if (!creative) {
    if (!inventory.removeFromSlot(actor.equipment.selectedSlot, 1) || !inventory.add({ itemId: outputItemId, count: 1 }))
      fail3("inventory-full");
  }
  return Object.freeze({
    version: 1,
    kind: "fluid-container",
    actorId: actor.reference.entityId,
    actorReference: actor.reference,
    hit,
    adjacent: next,
    targetPosition: targetPosition2,
    fromVoxel,
    toVoxel,
    slots: Object.freeze(inventory.snapshot()),
    creative,
    result: Object.freeze({ version: 1, success: true, action, actorId: actor.reference.entityId })
  });
}
function defineFluidContainerInteractionModule(config) {
  const frozen = Object.freeze({
    ...config,
    filled: Object.freeze(config.filled.map((entry) => Object.freeze({ ...entry }))),
    replaceableVoxels: Object.freeze([...config.replaceableVoxels])
  });
  return Object.freeze({
    descriptor: {
      id: frozen.moduleId,
      version: "1.0.0",
      requires: [
        { id: BLOCK_ACTIONS_CAPABILITY, version: "1.0.0" },
        ...GAMEPLAY_CONTENT_CAPABILITIES.map((id2) => ({ id: id2, version: "1.0.0" }))
      ],
      provides: [{ id: FLUID_CONTAINER_INTERACTION_CAPABILITY, version: "1.0.0" }],
      permissions: [
        { resource: BLOCK_ACTOR_RESOURCE, operations: ["read", "execute"] },
        { resource: BLOCK_VOXEL_RESOURCE, operations: ["read", "execute"] }
      ]
    },
    register(api) {
      api.requireCapability(BLOCK_ACTIONS_CAPABILITY);
      const items = api.requireCapability("seedlands:items");
      api.provideCapability(FLUID_CONTAINER_INTERACTION_CAPABILITY, frozen);
      api.registerOperation({
        id: frozen.operationId,
        resource: BLOCK_VOXEL_RESOURCE,
        run(context, input, state) {
          if (context.target.kind !== "voxel") throw new TypeError("Fluid interaction requires a voxel target.");
          const target = input;
          const hit = validateBlockPosition(target?.target?.hit, "Fluid interaction hit");
          const next = validateBlockPosition(target?.target?.adjacent, "Fluid interaction adjacent");
          const result = buildFluidContainerInteractionCandidate(
            items,
            frozen,
            state.read(blockActorAddress(context.originalActorId)),
            state.read(blockVoxelAddress(hit)),
            state.read(blockVoxelAddress(next)),
            input
          );
          if (result.actorId !== context.originalActorId) throw new TypeError("Fluid interaction actor changed.");
          return result;
        }
      });
    }
  });
}

// packages/stdlib/src/server/gameplay/modules/ruleset-module.ts
var RULESET_COMPONENT = "seedlands:world-ruleset";
var RULESET_RESOURCE = "seedlands.ruleset";
var rulesetSnapshot = (definition2) => Object.freeze({ version: 1, definitionId: definition2.id, definitionVersion: definition2.version, revision: 0 });
function validateWorldRuleset(raw, definition2) {
  if (!raw || typeof raw !== "object" || Array.isArray(raw)) throw new TypeError("World Ruleset snapshot is invalid.");
  const expected = rulesetSnapshot(definition2);
  const descriptors = Object.getOwnPropertyDescriptors(raw);
  if (Object.keys(descriptors).length !== Object.keys(expected).length)
    throw new TypeError("World Ruleset fields are invalid.");
  for (const [key2, value] of Object.entries(expected))
    if (!descriptors[key2] || !("value" in descriptors[key2]) || descriptors[key2].value !== value)
      throw new TypeError(`World Ruleset identity or revision is incompatible: ${key2}.`);
  return expected;
}
function defineRulesetModule(input) {
  if (!/^[a-z0-9][a-z0-9._-]*:[a-z0-9][a-z0-9._/-]*$/.test(input.id) || !/^\d+\.\d+\.\d+$/.test(input.version))
    throw new TypeError("World Ruleset definition is invalid.");
  const definition2 = Object.freeze({ id: input.id, version: input.version });
  return Object.freeze({
    descriptor: {
      id: "seedlands:ruleset-module",
      version: "1.0.0",
      provides: [{ id: RULESET_COMPONENT, version: "1.0.0" }],
      resources: [{ id: RULESET_RESOURCE, operations: ["read"] }],
      permissions: [{ resource: RULESET_RESOURCE, operations: ["read"] }]
    },
    register(api) {
      api.provideCapability(RULESET_COMPONENT, definition2);
      api.registerState({
        id: RULESET_COMPONENT,
        version: "1.0.0",
        resource: RULESET_RESOURCE,
        validate(value) {
          try {
            validateWorldRuleset(value, definition2);
            return true;
          } catch {
            return false;
          }
        }
      });
    }
  });
}

// packages/stdlib/src/server/gameplay/modules/mode-module.ts
var RESOURCE2 = "seedlands.mode";
var MODE_COMPONENT = "seedlands:actor-mode";
var data = (value) => {
  if (!value || typeof value !== "object" || Array.isArray(value)) throw new TypeError("Mode input must be an object.");
  return value;
};
function defineModeModule() {
  return Object.freeze({
    descriptor: {
      id: "seedlands:mode-module",
      version: "1.0.0",
      requires: [
        { id: "seedlands:items", version: "1.0.0" },
        { id: RULESET_COMPONENT, version: "1.0.0" }
      ],
      provides: [{ id: "seedlands:actor-modes", version: "1.0.0" }],
      resources: [{ id: RESOURCE2, operations: ["read", "write", "execute"] }],
      permissions: [
        { resource: RESOURCE2, operations: ["read", "write", "execute"] },
        { resource: RULESET_RESOURCE, operations: ["read"] }
      ]
    },
    register(api) {
      const items = api.requireCapability("seedlands:items");
      const ruleset = api.requireCapability(RULESET_COMPONENT);
      api.provideCapability(
        "seedlands:actor-modes",
        Object.freeze({
          setMode: "seedlands:set-mode",
          setCatalog: "seedlands:set-creative-catalog",
          setFlight: "seedlands:set-flight"
        })
      );
      api.registerState({
        id: MODE_COMPONENT,
        version: "1.0.0",
        resource: RESOURCE2,
        validate(value) {
          try {
            const facets = data(value);
            if (!facets.mode || !facets.creativeCatalog || !facets.flight) return false;
            validateActorModeFacets(facets, items);
            return true;
          } catch {
            return false;
          }
        }
      });
      for (const operation of ["set-mode", "set-creative-catalog", "set-flight"]) {
        api.registerOperation({
          id: `seedlands:${operation}`,
          resource: RESOURCE2,
          run(context, input, state) {
            if (context.target.kind !== "entity" || context.target.entityId !== context.originalActorId)
              throw new TypeError("Mode target must match the bound actor.");
            validateWorldRuleset(state.read({ componentId: RULESET_COMPONENT, target: { kind: "world" } }), ruleset);
            const address = { componentId: MODE_COMPONENT, target: context.target };
            const current2 = validateActorModeFacets(data(state.read(address)), items);
            const args = data(input);
            let { mode, creativeCatalog, flight } = current2;
            if (operation === "set-mode") {
              if (args.mode !== "survival" && args.mode !== "creative") throw new TypeError("Unknown actor mode.");
              if (args.mode === mode.value) throw new TypeError("Actor is already in the requested mode.");
              mode = { ...mode, value: args.mode, revision: mode.revision + 1 };
              flight = {
                ...flight,
                enabled: args.mode === "creative",
                revision: flight.revision + Number(flight.enabled !== (args.mode === "creative"))
              };
              if (args.mode === "creative") {
                const initial = items.list().filter((item) => item.capabilities.some((capability) => capability.type === "place")).slice(0, creativeCatalog.hotbar.length).map((item) => item.id);
                const hotbar2 = creativeCatalog.hotbar.some((id2) => id2 !== null) ? creativeCatalog.hotbar : Array.from({ length: creativeCatalog.hotbar.length }, (_, index) => initial[index] ?? null);
                creativeCatalog = { ...creativeCatalog, hotbar: hotbar2, revision: creativeCatalog.revision + 1 };
              }
            } else {
              if (mode.value !== "creative") throw new TypeError("Creative controls require creative mode.");
              if (operation === "set-flight") {
                if (typeof args.enabled !== "boolean") throw new TypeError("Flight enabled must be boolean.");
                flight = {
                  ...flight,
                  enabled: args.enabled,
                  revision: flight.revision + Number(flight.enabled !== args.enabled)
                };
              } else {
                if (typeof args.slot !== "number" || !Number.isSafeInteger(args.slot) || args.slot < 0 || args.slot >= creativeCatalog.hotbar.length || args.itemId !== null && (typeof args.itemId !== "string" || !items.has(args.itemId)))
                  throw new TypeError("Creative catalog selection is invalid.");
                const hotbar2 = [...creativeCatalog.hotbar];
                hotbar2[args.slot] = args.itemId;
                creativeCatalog = {
                  ...creativeCatalog,
                  hotbar: hotbar2,
                  selectedSlot: args.slot,
                  revision: creativeCatalog.revision + 1
                };
              }
            }
            const candidate2 = validateActorModeFacets({ mode, creativeCatalog, flight }, items);
            state.write(address, candidate2);
            return { mode: candidate2.mode.value, modeRevision: candidate2.mode.revision };
          }
        });
      }
    }
  });
}

// packages/stdlib/src/server/gameplay/modules/needs-model.ts
var NEEDS_COMPONENT = "seedlands:actor-needs";
var NEEDS_RESOURCE = "seedlands.needs";
var NEEDS_CAPABILITY = "seedlands:needs";
var NEEDS_PARTITIONS = 5;
var NEEDS_PARTITION_SIZE = 128;
function needsData(value, allowed) {
  if (!value || typeof value !== "object" || Array.isArray(value) || ![Object.prototype, null].includes(Object.getPrototypeOf(value)))
    throw new TypeError("Needs data must be an object.");
  const descriptors = Object.getOwnPropertyDescriptors(value);
  for (const key2 of Reflect.ownKeys(descriptors))
    if (typeof key2 !== "string" || !allowed.includes(key2) || !("value" in descriptors[key2]))
      throw new TypeError("Needs data has invalid fields.");
  return value;
}
var finite4 = (value, min = 0, max = Number.MAX_SAFE_INTEGER) => typeof value === "number" && Number.isFinite(value) && value >= min && value <= max;
function validateNeedsPartition(value) {
  const part = needsData(value, ["version", "partition", "entries"]);
  if (part.version !== 1 || !Number.isSafeInteger(part.partition) || !finite4(part.partition, 0, NEEDS_PARTITIONS - 1) || !Array.isArray(part.entries) || part.entries.length > NEEDS_PARTITION_SIZE)
    throw new TypeError("Needs partition is invalid.");
  const seen = /* @__PURE__ */ new Set();
  for (const raw of part.entries) {
    const entry = needsData(raw, ["reference", "kind", "health", "maxHealth", "lifecycle", "mode", "needs"]);
    const reference3 = needsData(entry.reference, ["entityId", "epoch", "lifetime"]);
    const mode = needsData(entry.mode, ["version", "value", "revision"]);
    const needs = needsData(entry.needs, [
      "hunger",
      "maxHunger",
      "hungerMeaning",
      "hungerAccumulator",
      "healingAccumulator",
      "starvationAccumulator"
    ]);
    if (typeof reference3.entityId !== "string" || !reference3.entityId.trim() || reference3.entityId.length > 256 || seen.has(reference3.entityId) || !Number.isSafeInteger(reference3.epoch) || !finite4(reference3.epoch, 1) || !Number.isSafeInteger(reference3.lifetime) || !finite4(reference3.lifetime, 1) || !["player", "creature", "npc"].includes(String(entry.kind)) || !finite4(entry.maxHealth, Number.EPSILON) || !finite4(entry.health, 0, entry.maxHealth) || !["alive", "dead"].includes(String(entry.lifecycle)) || entry.health === 0 !== (entry.lifecycle === "dead") || mode.version !== 1 || !["survival", "creative"].includes(String(mode.value)) || !Number.isSafeInteger(mode.revision) || !finite4(mode.revision) || !finite4(needs.maxHunger, Number.EPSILON) || !finite4(needs.hunger, 0, needs.maxHunger) || !["satiety", "deficit"].includes(String(needs.hungerMeaning)) || !finite4(needs.hungerAccumulator) || !finite4(needs.healingAccumulator) || !finite4(needs.starvationAccumulator))
      throw new TypeError("Needs actor projection is invalid.");
    seen.add(reference3.entityId);
  }
  return value;
}
function validateNeedsProfiles(value) {
  const profiles = needsData(value, ["satiety", "deficit"]);
  for (const raw of [profiles.satiety, profiles.deficit]) {
    const profile = needsData(raw, ["enabledModes", "hungerEverySeconds", "hungerDelta", "heal", "starvation"]);
    if (!Array.isArray(profile.enabledModes) || profile.enabledModes.length > 2 || Array.from(profile.enabledModes).some((mode) => mode !== "survival" && mode !== "creative") || new Set(profile.enabledModes).size !== profile.enabledModes.length || !finite4(profile.hungerEverySeconds, 1, 86400) || !finite4(profile.hungerDelta, -100, 100))
      throw new TypeError("Needs policy profile is invalid.");
    if (profile.heal !== void 0) {
      const heal = needsData(profile.heal, ["threshold", "everySeconds", "amount", "hungerCost"]);
      if (!finite4(heal.threshold) || !finite4(heal.everySeconds, 1, 86400) || !finite4(heal.amount, Number.EPSILON, 100) || !finite4(heal.hungerCost, Number.EPSILON, 100))
        throw new TypeError("Needs healing policy is invalid.");
    }
    if (profile.starvation !== void 0) {
      const starvation = needsData(profile.starvation, ["threshold", "everySeconds", "damage"]);
      if (!finite4(starvation.threshold) || !finite4(starvation.everySeconds, 1, 86400) || !finite4(starvation.damage, Number.EPSILON, 100))
        throw new TypeError("Needs starvation policy is invalid.");
    }
  }
  return value;
}
var phase = (seconds) => Math.round(seconds * 1e9) / 1e9;
function advanceNeedsEntry(entry, profile, seconds) {
  if (entry.lifecycle !== "alive" || !profile.enabledModes.includes(entry.mode.value)) return entry;
  const needs = { ...entry.needs };
  let health = entry.health;
  needs.hungerAccumulator = phase(needs.hungerAccumulator + seconds);
  const hungerSteps = Math.floor(needs.hungerAccumulator / profile.hungerEverySeconds);
  needs.hungerAccumulator = phase(needs.hungerAccumulator - hungerSteps * profile.hungerEverySeconds);
  needs.hunger = Math.max(0, Math.min(needs.maxHunger, needs.hunger + hungerSteps * profile.hungerDelta));
  const heal = profile.heal;
  if (heal && needs.hunger >= heal.threshold && health < entry.maxHealth) {
    needs.healingAccumulator = phase(needs.healingAccumulator + seconds);
    const steps = Math.min(
      Math.floor(needs.healingAccumulator / heal.everySeconds),
      Math.ceil((entry.maxHealth - health) / heal.amount),
      Math.floor((needs.hunger - heal.threshold) / heal.hungerCost) + 1
    );
    needs.healingAccumulator = phase(needs.healingAccumulator - steps * heal.everySeconds);
    health = Math.min(entry.maxHealth, health + steps * heal.amount);
    needs.hunger = Math.max(0, needs.hunger - steps * heal.hungerCost);
  } else needs.healingAccumulator = 0;
  const starvation = profile.starvation;
  if (starvation && needs.hunger === starvation.threshold) {
    needs.starvationAccumulator = phase(needs.starvationAccumulator + seconds);
    const steps = Math.min(
      Math.floor(needs.starvationAccumulator / starvation.everySeconds),
      Math.ceil(health / starvation.damage)
    );
    needs.starvationAccumulator = phase(needs.starvationAccumulator - steps * starvation.everySeconds);
    health = Math.max(0, health - steps * starvation.damage);
  } else needs.starvationAccumulator = 0;
  return { ...entry, needs, health, lifecycle: health === 0 ? "dead" : "alive" };
}

// packages/stdlib/src/server/gameplay/modules/needs-module.ts
var needsAddress = (partition) => ({
  componentId: NEEDS_COMPONENT,
  target: { kind: "world" },
  partition
});
function needsSeconds(value) {
  const input = needsData(value, ["seconds"]);
  if (typeof input.seconds !== "number" || !Number.isFinite(input.seconds) || input.seconds < 0 || input.seconds > 1)
    throw new TypeError("Needs step must be between 0 and 1 second.");
  return input.seconds;
}
function defineNeedsModule() {
  return {
    descriptor: {
      id: "seedlands:needs-module",
      version: "1.0.0",
      requires: [{ id: RULESET_COMPONENT, version: "1.0.0" }],
      provides: [{ id: NEEDS_CAPABILITY, version: "1.0.0" }],
      resources: [{ id: NEEDS_RESOURCE, operations: ["read", "write", "execute"] }],
      permissions: [
        { resource: NEEDS_RESOURCE, operations: ["read", "write", "execute"] },
        { resource: RULESET_RESOURCE, operations: ["read"] }
      ]
    },
    register(api) {
      const ruleset = api.requireCapability(RULESET_COMPONENT);
      api.provideCapability(
        NEEDS_CAPABILITY,
        Object.freeze({ partitions: NEEDS_PARTITIONS, operationId: "seedlands:advance-needs" })
      );
      api.registerState({
        id: NEEDS_COMPONENT,
        version: "1.0.0",
        resource: NEEDS_RESOURCE,
        partitions: NEEDS_PARTITIONS,
        validate(value) {
          try {
            validateNeedsPartition(value);
            return true;
          } catch {
            return false;
          }
        }
      });
      api.registerOperation({
        id: "seedlands:advance-needs",
        executionKind: "system",
        resource: NEEDS_RESOURCE,
        run(_context, input, state) {
          const policy = needsData(input, ["seconds", "ruleset", "profiles"]);
          const seconds = needsSeconds({ seconds: policy.seconds });
          const selectedRuleset = validateWorldRuleset(policy.ruleset, ruleset);
          const currentRuleset2 = validateWorldRuleset(
            state.read({ componentId: RULESET_COMPONENT, target: { kind: "world" } }),
            ruleset
          );
          if (JSON.stringify(currentRuleset2) !== JSON.stringify(selectedRuleset))
            throw new TypeError("Needs ruleset changed.");
          const profiles = validateNeedsProfiles(policy.profiles);
          let count = 0;
          for (let partition = 0; partition < NEEDS_PARTITIONS; partition++) {
            const address = needsAddress(partition);
            const before = validateNeedsPartition(state.read(address));
            const entries = before.entries.map(
              (entry) => advanceNeedsEntry(entry, profiles[entry.needs.hungerMeaning], seconds)
            );
            state.write(address, { ...before, entries });
            count += entries.length;
          }
          return { actors: count, seconds, rulesetRevision: selectedRuleset.revision };
        }
      });
      api.registerSystem({
        id: "seedlands:needs-system",
        operationId: "seedlands:advance-needs",
        cadence: "every-advance"
      });
    }
  };
}

// packages/stdlib/src/server/gameplay/modules/needs-rules-module.ts
function defineNeedsRulesModule(options) {
  const profiles = validateNeedsProfiles(options.profiles);
  const ownedProfiles = JSON.parse(JSON.stringify(profiles));
  return {
    descriptor: {
      id: options.moduleId,
      version: "1.0.0",
      requires: [
        { id: RULESET_COMPONENT, version: "1.0.0" },
        { id: NEEDS_CAPABILITY, version: "1.0.0" }
      ],
      permissions: [
        { resource: NEEDS_RESOURCE, operations: ["read", "execute"] },
        { resource: RULESET_RESOURCE, operations: ["read"] }
      ]
    },
    register(api) {
      const ruleset = api.requireCapability(RULESET_COMPONENT);
      api.requireCapability(NEEDS_CAPABILITY);
      api.registerRule({
        id: `${options.moduleId}/before`,
        operationId: "seedlands:advance-needs",
        stage: "before",
        apply(_context, input, state) {
          const seconds = needsSeconds(input);
          const current2 = validateWorldRuleset(
            state.read({ componentId: RULESET_COMPONENT, target: { kind: "world" } }),
            ruleset
          );
          return { input: { seconds, ruleset: current2, profiles: ownedProfiles } };
        }
      });
      api.registerRule({
        id: `${options.moduleId}/after`,
        operationId: "seedlands:advance-needs",
        stage: "after",
        apply(_context, input, state) {
          const policy = needsData(input, ["seconds", "ruleset", "profiles"]);
          validateWorldRuleset(policy.ruleset, ruleset);
          if (JSON.stringify(policy.profiles) !== JSON.stringify(ownedProfiles))
            return { reject: "needs-ruleset-policy-changed" };
          for (let partition = 0; partition < NEEDS_PARTITIONS; partition++) {
            const address = needsAddress(partition);
            const before = validateNeedsPartition(state.readOriginal(address));
            const after = validateNeedsPartition(state.read(address));
            if (before.entries.length !== after.entries.length) return { reject: "needs-membership-changed" };
            for (let index = 0; index < before.entries.length; index++) {
              const previous = before.entries[index], current2 = after.entries[index];
              const profile = ownedProfiles[previous.needs.hungerMeaning];
              if ((previous.lifecycle !== "alive" || !profile.enabledModes.includes(previous.mode.value)) && JSON.stringify(previous) !== JSON.stringify(current2))
                return { reject: "needs-exempt-actor-changed" };
            }
          }
        }
      });
    }
  };
}

// packages/stdlib/src/server/gameplay/modules/combat-module.ts
var actorContext = (context) => {
  if (context.kind !== "actor" || !context.originalActorId) throw new TypeError("Combat requires an actor context.");
  return context.originalActorId;
};
var entityTarget = (target) => {
  if (!target || typeof target !== "object") throw new TypeError("Combat requires an entity target.");
  const value = target;
  if (value.kind !== "entity" || typeof value.entityId !== "string")
    throw new TypeError("Combat requires an entity target.");
  return value.entityId;
};
function defineCombatModule() {
  return Object.freeze({
    descriptor: {
      id: "seedlands:combat-module",
      version: "1.0.0",
      provides: [{ id: COMBAT_CAPABILITY, version: "1.0.0" }],
      resources: [
        { id: COMBAT_RESOURCE, operations: ["read", "execute"] },
        { id: COMBAT_CLOCK_RESOURCE, operations: ["read", "execute"] }
      ],
      permissions: [
        { resource: COMBAT_RESOURCE, operations: ["read", "execute"] },
        { resource: COMBAT_CLOCK_RESOURCE, operations: ["read", "execute"] }
      ]
    },
    register(api) {
      api.provideCapability(COMBAT_CAPABILITY, combatCapability());
      api.registerState({
        id: COMBAT_ACTOR_COMPONENT,
        version: "1.0.0",
        resource: COMBAT_RESOURCE,
        validate(value) {
          try {
            validateCombatActorProjection(value);
            return true;
          } catch {
            return false;
          }
        }
      });
      api.registerState({
        id: COMBAT_WORLD_COMPONENT,
        version: "1.0.0",
        resource: COMBAT_CLOCK_RESOURCE,
        partitions: COMBAT_PARTITIONS,
        validate(value) {
          try {
            validateCombatWorldPartition(value);
            return true;
          } catch {
            return false;
          }
        }
      });
      api.registerOperation({
        id: COMBAT_REQUEST_OPERATION,
        resource: COMBAT_RESOURCE,
        run(context, input, state) {
          const actorId3 = actorContext(context);
          const targetId = entityTarget(context.target);
          const effective = validateCombatRequestEffectiveInput(input);
          if (effective.targetId !== targetId || actorId3 === targetId)
            throw new TypeError("Combat request target does not match its execution context.");
          const actor = validateCombatActorProjection(state.read(combatActorAddress(actorId3)));
          const target = validateCombatActorProjection(state.read(combatActorAddress(targetId)));
          if (actor.reference.entityId !== actorId3 || target.reference.entityId !== targetId)
            throw new TypeError("Combat actor projection identity is invalid.");
          if (actor.meleeDefinitionId === null) throw new TypeError("Combat actor has no configured melee definition.");
          if (actor.lifecycle !== "alive" || target.lifecycle !== "alive")
            throw new TypeError("Combat requires living actor projections.");
          return Object.freeze({
            version: 1,
            kind: "request",
            actorId: actorId3,
            targetId,
            definitionId: actor.meleeDefinitionId,
            rulesetRevision: effective.rulesetRevision
          });
        }
      });
      api.registerOperation({
        id: COMBAT_RESOLVE_OPERATION,
        resource: COMBAT_RESOURCE,
        run(context, input, state) {
          const actorId3 = actorContext(context);
          const targetId = entityTarget(context.target);
          const effective = validateCombatResolveEffectiveInput(input);
          const actor = validateCombatActorProjection(state.read(combatActorAddress(actorId3)));
          const target = validateCombatActorProjection(state.read(combatActorAddress(targetId)));
          if (actor.reference.entityId !== actorId3 || target.reference.entityId !== targetId || actor.pending?.token !== effective.token || actor.pending.targetId !== targetId)
            throw new TypeError("Combat pending projection does not match resolve context.");
          return Object.freeze({
            version: 1,
            kind: "resolve",
            actorId: actorId3,
            targetId,
            token: effective.token,
            damage: effective.damage,
            rulesetRevision: effective.rulesetRevision
          });
        }
      });
      api.registerOperation({
        id: COMBAT_ADVANCE_OPERATION,
        executionKind: "system",
        resource: COMBAT_CLOCK_RESOURCE,
        run(context, input, state) {
          if (context.kind !== "system" || context.target.kind !== "world")
            throw new TypeError("Combat advance requires its world clock.");
          const advance = validateCombatAdvanceInput(input);
          for (let partition = 0; partition < COMBAT_PARTITIONS; partition++)
            validateCombatWorldPartition(state.read(combatWorldAddress(partition)));
          return Object.freeze({ version: 1, kind: "advance", ...advance });
        }
      });
      api.registerSystem({
        id: COMBAT_SYSTEM,
        operationId: COMBAT_ADVANCE_OPERATION,
        cadence: "every-advance"
      });
    }
  });
}

// packages/stdlib/src/server/gameplay/modules/combat-rules-module.ts
var currentRuleset = (state, definition2) => validateWorldRuleset(state.read({ componentId: RULESET_COMPONENT, target: { kind: "world" } }), definition2);
var actorContext2 = (context) => {
  if (context.kind !== "actor" || !context.originalActorId)
    throw new TypeError("Combat rule requires an actor context.");
  const target = context.target;
  if (target?.kind !== "entity" || typeof target.entityId !== "string")
    throw new TypeError("Combat rule requires an entity target.");
  return { actorId: context.originalActorId, targetId: target.entityId };
};
var damageFor = (baseDamage, targetMode, profile) => profile.immuneTargetModes.includes(targetMode) ? 0 : Math.round(baseDamage * profile.damageMultiplier * 1e6) / 1e6;
function defineCombatRulesModule(options) {
  if (typeof options.moduleId !== "string" || !options.moduleId.trim())
    throw new TypeError("Combat Ruleset module ID is invalid.");
  const profile = validateCombatRulesProfile(options.profile);
  return Object.freeze({
    descriptor: {
      id: options.moduleId,
      version: "1.0.0",
      requires: [
        { id: COMBAT_CAPABILITY, version: "1.0.0" },
        { id: RULESET_COMPONENT, version: "1.0.0" }
      ],
      permissions: [
        { resource: COMBAT_RESOURCE, operations: ["read", "execute"] },
        { resource: RULESET_RESOURCE, operations: ["read"] }
      ]
    },
    register(api) {
      api.requireCapability(COMBAT_CAPABILITY);
      const ruleset = api.requireCapability(RULESET_COMPONENT);
      api.registerRule({
        id: `${options.moduleId}/request-before`,
        operationId: COMBAT_REQUEST_OPERATION,
        stage: "before",
        apply(context, input, state) {
          const request = validateCombatRequestInput(input);
          const { actorId: actorId3, targetId } = actorContext2(context);
          if (request.targetId !== targetId) throw new TypeError("Combat request target changed.");
          validateCombatActorProjection(state.read(combatActorAddress(actorId3)));
          validateCombatActorProjection(state.read(combatActorAddress(targetId)));
          const current2 = currentRuleset(state, ruleset);
          return { input: { targetId, rulesetRevision: current2.revision } };
        }
      });
      api.registerRule({
        id: `${options.moduleId}/request-after`,
        operationId: COMBAT_REQUEST_OPERATION,
        stage: "after",
        apply(context, input, state, candidate2) {
          const effective = validateCombatRequestEffectiveInput(input);
          const value = validateCombatCandidate(candidate2);
          const { actorId: actorId3, targetId } = actorContext2(context);
          const actor = validateCombatActorProjection(state.read(combatActorAddress(actorId3)));
          const target = validateCombatActorProjection(state.read(combatActorAddress(targetId)));
          const current2 = currentRuleset(state, ruleset);
          if (value.kind !== "request" || value.actorId !== actorId3 || value.targetId !== targetId || value.targetId !== effective.targetId || value.definitionId !== actor.meleeDefinitionId || value.rulesetRevision !== effective.rulesetRevision || value.rulesetRevision !== current2.revision || target.reference.entityId !== targetId)
            return { reject: "combat-request-candidate-mismatch" };
        }
      });
      api.registerRule({
        id: `${options.moduleId}/resolve-before`,
        operationId: COMBAT_RESOLVE_OPERATION,
        stage: "before",
        apply(context, input, state) {
          const request = validateCombatResolveInput(input);
          const { actorId: actorId3, targetId } = actorContext2(context);
          const actor = validateCombatActorProjection(state.read(combatActorAddress(actorId3)));
          const target = validateCombatActorProjection(state.read(combatActorAddress(targetId)));
          if (actor.pending?.token !== request.token || actor.pending.targetId !== targetId)
            throw new TypeError("Combat pending hit changed.");
          const current2 = currentRuleset(state, ruleset);
          return {
            input: {
              token: request.token,
              damage: damageFor(actor.pending.baseDamage, target.mode.value, profile),
              rulesetRevision: current2.revision
            }
          };
        }
      });
      api.registerRule({
        id: `${options.moduleId}/resolve-after`,
        operationId: COMBAT_RESOLVE_OPERATION,
        stage: "after",
        apply(context, input, state, candidate2) {
          const effective = validateCombatResolveEffectiveInput(input);
          const value = validateCombatCandidate(candidate2);
          const { actorId: actorId3, targetId } = actorContext2(context);
          const actor = validateCombatActorProjection(state.read(combatActorAddress(actorId3)));
          const target = validateCombatActorProjection(state.read(combatActorAddress(targetId)));
          const current2 = currentRuleset(state, ruleset);
          const expected = actor.pending ? damageFor(actor.pending.baseDamage, target.mode.value, profile) : Number.NaN;
          if (value.kind !== "resolve" || value.actorId !== actorId3 || value.targetId !== targetId || value.token !== effective.token || value.damage !== effective.damage || value.damage !== expected || value.rulesetRevision !== effective.rulesetRevision || value.rulesetRevision !== current2.revision)
            return { reject: "combat-resolve-candidate-mismatch" };
        }
      });
    }
  });
}

// packages/stdlib/src/server/gameplay/modules/station-candidates.ts
var gridWidth = (grid) => {
  if (grid.length === 4) return 2;
  if (grid.length === 9) return 3;
  throw new TypeError("Crafting grid must be an exact 2x2 or 3x3 grid.");
};
var shapedBounds = (pattern) => {
  if (!Array.isArray(pattern) || pattern.length !== 9)
    throw new TypeError("Shaped recipe pattern must be an exact 3x3 grid.");
  const occupied = pattern.flatMap((slot, index) => slot ? [[index % 3, Math.floor(index / 3)]] : []);
  if (!occupied.length) throw new TypeError("Shaped recipe requires ingredients.");
  const xs = occupied.map(([x2]) => x2), ys = occupied.map(([, y2]) => y2);
  return {
    left: Math.min(...xs),
    top: Math.min(...ys),
    width: Math.max(...xs) - Math.min(...xs) + 1,
    height: Math.max(...ys) - Math.min(...ys) + 1
  };
};
function stationRecipeFitsGrid(recipe, size) {
  if (recipe.kind === "shapeless") return recipe.inputs.length <= size * size;
  const bounds = shapedBounds(recipe.pattern);
  return bounds.width <= size && bounds.height <= size;
}
function matchesShapedStationRecipe(grid, recipe, items) {
  const candidate2 = validateGrid(grid, items);
  const width = gridWidth(candidate2);
  validateIdentity(recipe.id);
  const bounds = shapedBounds(recipe.pattern);
  validateOutputs(recipe.outputs, items);
  recipe.pattern.forEach((ingredient) => {
    if (ingredient) items.assertStack(ingredient);
  });
  if (bounds.width > width || bounds.height > width) return false;
  for (let offsetY = 0; offsetY <= width - bounds.height; offsetY += 1)
    for (let offsetX = 0; offsetX <= width - bounds.width; offsetX += 1) {
      const expected = Array.from({ length: candidate2.length }, () => null);
      recipe.pattern.forEach((ingredient, index) => {
        if (!ingredient) return;
        const x2 = index % 3 - bounds.left + offsetX;
        const y2 = Math.floor(index / 3) - bounds.top + offsetY;
        expected[y2 * width + x2] = ingredient;
      });
      if (expected.every(
        (ingredient, index) => ingredient === null ? candidate2[index] === null : candidate2[index] !== null && sameItemStackIdentity(candidate2[index], ingredient) && candidate2[index].count >= ingredient.count
      ))
        return true;
    }
  return false;
}
function matchesShapelessStationRecipe(grid, recipe, items) {
  const candidate2 = validateGrid(grid, items);
  const width = gridWidth(candidate2);
  validateIdentity(recipe.id);
  if (!Array.isArray(recipe.inputs) || recipe.inputs.length === 0)
    throw new TypeError("Shapeless station recipe inputs are required.");
  validateOutputs(recipe.outputs, items);
  recipe.inputs.forEach((input) => items.assertStack(input));
  if (!stationRecipeFitsGrid(recipe, width)) return false;
  return matchShapelessSlots(candidate2, recipe.inputs) !== null;
}
function createStationCraftCandidate(input) {
  if (!Array.isArray(input.output) || input.output.length === 0)
    throw new TypeError("Station output inventory must have positive capacity.");
  const output = new Inventory(input.output.length, input.output, input.items);
  const matches = input.recipe.kind === "shaped" ? matchesShapedStationRecipe(input.grid, input.recipe, input.items) : matchesShapelessStationRecipe(input.grid, input.recipe, input.items);
  if (!matches) return { success: false, reason: "recipe-mismatch" };
  for (const stack2 of input.recipe.outputs) {
    if (!output.add(stack2)) return { success: false, reason: "output-full" };
  }
  const grid = validateGrid(input.grid, input.items);
  if (input.recipe.kind === "shaped") consumeShaped(grid, input.recipe.pattern);
  else consumeShapeless(grid, input.recipe.inputs);
  return { success: true, grid, output: output.snapshot() };
}
function validateGrid(grid, items) {
  if (!Array.isArray(grid)) throw new TypeError("Crafting grid must be an array.");
  gridWidth(grid);
  return new Inventory(grid.length, grid, items).snapshot();
}
function validateIdentity(id2) {
  if (typeof id2 !== "string" || !id2.trim()) throw new TypeError("Station recipe identity is invalid.");
}
function validateOutputs(outputs, items) {
  if (!Array.isArray(outputs) || outputs.length === 0) throw new TypeError("Station recipe outputs are required.");
  outputs.forEach((stack2) => items.assertStack(stack2));
}
function consumeShaped(grid, pattern) {
  const width = gridWidth(grid), bounds = shapedBounds(pattern);
  for (let offsetY = 0; offsetY <= width - bounds.height; offsetY += 1)
    for (let offsetX = 0; offsetX <= width - bounds.width; offsetX += 1) {
      const indices = [];
      pattern.forEach((ingredient, index) => {
        if (!ingredient) return;
        const x2 = index % 3 - bounds.left + offsetX;
        const y2 = Math.floor(index / 3) - bounds.top + offsetY;
        indices.push([y2 * width + x2, ingredient]);
      });
      if (!indices.every(
        ([index, ingredient]) => grid[index] && sameItemStackIdentity(grid[index], ingredient) && grid[index].count >= ingredient.count
      ))
        continue;
      indices.forEach(([index, ingredient]) => {
        const slot = grid[index];
        grid[index] = slot.count === ingredient.count ? null : { ...slot, count: slot.count - ingredient.count };
      });
      return;
    }
}
function matchShapelessSlots(grid, inputs) {
  const occupied = grid.flatMap((stack2, slot) => stack2 ? [{ slot, stack: stack2 }] : []);
  if (occupied.length !== inputs.length) return null;
  const search = (index, remaining, matches) => {
    if (index === occupied.length) return matches;
    const entry = occupied[index];
    for (let ingredientIndex = 0; ingredientIndex < remaining.length; ingredientIndex += 1) {
      const ingredient = remaining[ingredientIndex];
      if (!sameItemStackIdentity(entry.stack, ingredient) || entry.stack.count < ingredient.count) continue;
      const result = search(
        index + 1,
        [...remaining.slice(0, ingredientIndex), ...remaining.slice(ingredientIndex + 1)],
        [...matches, { slot: entry.slot, ingredient }]
      );
      if (result) return result;
    }
    return null;
  };
  return search(0, inputs, []);
}
function consumeShapeless(grid, inputs) {
  const matches = matchShapelessSlots(grid, inputs);
  if (!matches) throw new Error("Shapeless recipe consumption requires a matched grid.");
  for (const { slot: index, ingredient } of matches) {
    const stack2 = grid[index];
    grid[index] = stack2.count === ingredient.count ? null : { ...stack2, count: stack2.count - ingredient.count };
  }
}

// packages/stdlib/src/server/gameplay/modules/inventory-cursor-settlement.ts
function frozenStack2(stack2) {
  return stack2 ? Object.freeze({
    ...stack2,
    ...stack2.instance ? { instance: Object.freeze({ ...stack2.instance }) } : {}
  }) : null;
}
function capacity(items, target, stack2) {
  if (target && !sameItemStackIdentity(target, stack2)) return 0;
  return items.require(stack2.itemId).stackLimit - (target?.count ?? 0);
}
function settleInventoryCursor(items, slots, rawCursor) {
  const cursor = validateInventoryCursor(rawCursor, items);
  const inventory = new Inventory(slots.length, slots, items).snapshot();
  const pending = [cursor.stack, ...cursor.craftingGrid].flatMap(
    (entry) => entry ? [{ ...entry, ...entry.instance ? { instance: { ...entry.instance } } : {} }] : []
  );
  if (!pending.length)
    return Object.freeze({ slots: Object.freeze(inventory.map(frozenStack2)), cursor, dropIntents: Object.freeze([]) });
  if (cursor.revision >= Number.MAX_SAFE_INTEGER) throw new RangeError("Inventory cursor revision exhausted.");
  const place = (stack2, slot) => {
    const target = inventory[slot];
    if (target && !sameItemStackIdentity(target, stack2)) return stack2;
    const moved = Math.min(stack2.count, Math.max(0, capacity(items, target, stack2)));
    if (!moved) return stack2;
    inventory[slot] = { ...stack2, count: (target?.count ?? 0) + moved };
    return stack2.count === moved ? null : { ...stack2, count: stack2.count - moved };
  };
  const drops = [];
  for (const [pendingIndex, pendingStack] of pending.entries()) {
    let stack2 = pendingStack;
    if (pendingIndex === 0 && cursor.stack && cursor.origin?.kind === "inventory" && cursor.origin.slot < inventory.length)
      stack2 = place(stack2, cursor.origin.slot);
    for (const emptyPass of [false, true])
      for (let slot = 0; slot < inventory.length && stack2; slot += 1) {
        const target = inventory[slot];
        if (emptyPass && target || !emptyPass && !target) continue;
        stack2 = place(stack2, slot);
      }
    if (stack2) drops.push(stack2);
  }
  return Object.freeze({
    slots: Object.freeze(inventory.map(frozenStack2)),
    cursor: Object.freeze({
      version: 1,
      revision: cursor.revision + 1,
      stack: null,
      origin: null,
      craftingGrid: Object.freeze([null, null, null, null])
    }),
    dropIntents: Object.freeze(drops.map((stack2) => frozenStack2(stack2)))
  });
}

// packages/stdlib/src/server/gameplay/modules/inventory-pointer-model.ts
var integer2 = (value, minimum = 0, maximum = Number.MAX_SAFE_INTEGER) => typeof value === "number" && Number.isSafeInteger(value) && value >= minimum && value <= maximum;
var same = (left, right) => JSON.stringify(left) === JSON.stringify(right);
function frozenStack3(stack2) {
  return stack2 ? Object.freeze({
    ...stack2,
    ...stack2.instance ? { instance: Object.freeze({ ...stack2.instance }) } : {}
  }) : null;
}
function stationSlots(component) {
  return component.kind === "workbench" ? [...component.grid] : component.kind === "chest" ? [...component.slots] : [component.furnace.input, component.furnace.fuel, component.furnace.output];
}
function current(state, ref) {
  const values = ref.kind === "inventory" ? state.slots : ref.kind === "crafting" ? state.craftingSlots : state.stationSlots;
  if (!values || ref.slot >= values.length) throw new Error("invalid-pointer-slot");
  return values[ref.slot] ?? null;
}
function write(state, ref, value) {
  const values = ref.kind === "inventory" ? state.slots : ref.kind === "crafting" ? state.craftingSlots : state.stationSlots;
  if (!values || ref.slot >= values.length) throw new Error("invalid-pointer-slot");
  values[ref.slot] = value ? { ...value, ...value.instance ? { instance: { ...value.instance } } : {} } : null;
}
function originFor(ref, station) {
  return ref.kind === "station" ? Object.freeze({ kind: "station", reference: Object.freeze({ ...station.reference }), slot: ref.slot }) : Object.freeze({ kind: ref.kind, slot: ref.slot });
}
function canPlaceStation(content, station, slot, stack2) {
  if (station.kind !== "furnace") return true;
  if (slot === 0) {
    const recipe = content.stations.codec.furnace.recipeForInput(stack2.itemId);
    return !!recipe && sameItemStackIdentity(recipe.input, stack2);
  }
  if (slot === 1) return !!content.stations.codec.furnace.fuel(stack2.itemId);
  return false;
}
function assertCanPlace(content, state, ref, stack2) {
  if (ref.kind === "station" && (!state.station || !canPlaceStation(content, state.station, ref.slot, stack2)))
    throw new Error("invalid-station-slot");
}
function capacity2(items, target, stack2) {
  if (target && !sameItemStackIdentity(target, stack2)) return 0;
  return items.require(stack2.itemId).stackLimit - (target?.count ?? 0);
}
function put(content, state, ref, count) {
  const stack2 = state.cursorStack;
  if (!stack2) return 0;
  assertCanPlace(content, state, ref, stack2);
  const target = current(state, ref);
  if (target && !sameItemStackIdentity(target, stack2)) throw new Error("destination-occupied");
  const moved = Math.min(count, stack2.count, Math.max(0, capacity2(content.items, target, stack2)));
  if (moved === 0) return 0;
  write(state, ref, { ...stack2, count: (target?.count ?? 0) + moved });
  state.cursorStack = stack2.count === moved ? null : { ...stack2, count: stack2.count - moved };
  if (!state.cursorStack) state.cursorOrigin = null;
  return moved;
}
function click(content, state, station, command) {
  const target = current(state, command.slot);
  if (!state.cursorStack) {
    if (!target) throw new Error("empty-source-slot");
    const count = command.button === 0 ? target.count : Math.ceil(target.count / 2);
    state.cursorStack = { ...target, count };
    state.cursorOrigin = originFor(command.slot, station);
    write(state, command.slot, count === target.count ? null : { ...target, count: target.count - count });
    return;
  }
  if (!target || sameItemStackIdentity(target, state.cursorStack)) {
    const moved = put(content, state, command.slot, command.button === 0 ? state.cursorStack.count : 1);
    if (!moved) throw new Error("destination-full");
    return;
  }
  assertCanPlace(content, state, command.slot, state.cursorStack);
  const previous = state.cursorStack;
  write(state, command.slot, previous);
  state.cursorStack = target;
  state.cursorOrigin = originFor(command.slot, station);
}
function distribute(content, state, command) {
  if (!state.cursorStack) throw new Error("cursor-empty");
  const unique = [];
  const seen = /* @__PURE__ */ new Set();
  for (const ref of command.targets) {
    const key2 = `${ref.kind}:${ref.slot}`;
    if (seen.has(key2)) continue;
    seen.add(key2);
    current(state, ref);
    assertCanPlace(content, state, ref, state.cursorStack);
    const target = current(state, ref);
    if (target && !sameItemStackIdentity(target, state.cursorStack)) throw new Error("destination-occupied");
    unique.push(ref);
  }
  const amount = command.button === 0 ? Math.floor(state.cursorStack.count / unique.length) : 1;
  if (amount < 1) throw new Error("insufficient-items");
  let moved = 0;
  for (const ref of unique) {
    if (!state.cursorStack) break;
    moved += put(content, state, ref, amount);
  }
  if (!moved) throw new Error("destination-full");
}
function destinations(actor, station, source) {
  if (station) {
    if (source.kind === "station") return actor.slots.map((_, slot) => ({ kind: "inventory", slot }));
    return stationSlots(station).map((_, slot) => ({ kind: "station", slot }));
  }
  if (source.kind === "crafting") return actor.slots.map((_, slot) => ({ kind: "inventory", slot }));
  if (source.kind !== "inventory") throw new Error("station-context-required");
  const start = source.slot < actor.equipment.hotbarSize ? actor.equipment.hotbarSize : 0;
  const end = source.slot < actor.equipment.hotbarSize ? actor.slots.length : actor.equipment.hotbarSize;
  return Array.from({ length: end - start }, (_, offset) => ({ kind: "inventory", slot: start + offset }));
}
function quickMove(content, actor, state, command) {
  if (state.cursorStack) throw new Error("cursor-not-empty");
  let source = current(state, command.slot);
  if (!source) throw new Error("empty-source-slot");
  const targets = destinations(actor, state.station, command.slot);
  let moved = 0;
  for (const emptyPass of [false, true]) {
    for (const ref of targets) {
      if (!source) break;
      if (ref.kind === command.slot.kind && ref.slot === command.slot.slot) continue;
      if (ref.kind === "station" && !canPlaceStation(content, state.station, ref.slot, source)) continue;
      const target = current(state, ref);
      if (emptyPass && target || !emptyPass && (!target || !sameItemStackIdentity(target, source))) continue;
      const count = Math.min(source.count, Math.max(0, capacity2(content.items, target, source)));
      if (!count) continue;
      write(state, ref, { ...source, count: (target?.count ?? 0) + count });
      source = source.count === count ? null : { ...source, count: source.count - count };
      moved += count;
    }
  }
  if (!moved) throw new Error("destination-full");
  write(state, command.slot, source);
}
function collect(content, state, command) {
  const cursor = state.cursorStack;
  if (!cursor) throw new Error("cursor-empty");
  const seed = current(state, command.slot);
  if (seed && !sameItemStackIdentity(seed, cursor)) throw new Error("collect-identity-mismatch");
  let count = cursor.count;
  const limit = content.items.require(cursor.itemId).stackLimit;
  const refs = [
    ...state.slots.map((_, slot) => ({ kind: "inventory", slot })),
    ...state.station ? [] : state.craftingSlots.map((_, slot) => ({ kind: "crafting", slot })),
    ...state.stationSlots?.map((_, slot) => ({ kind: "station", slot })) ?? []
  ];
  for (const ref of refs) {
    if (count >= limit) break;
    const stack2 = current(state, ref);
    if (!stack2 || !sameItemStackIdentity(stack2, cursor)) continue;
    const taken = Math.min(stack2.count, limit - count);
    count += taken;
    write(state, ref, stack2.count === taken ? null : { ...stack2, count: stack2.count - taken });
  }
  if (count === cursor.count) throw new Error("no-collectable-items");
  state.cursorStack = { ...cursor, count };
}
function hotbar(content, state, command) {
  if (state.cursorStack) throw new Error("cursor-not-empty");
  if (command.hotbarSlot >= state.slots.length) throw new Error("invalid-hotbar-slot");
  const hotbarRef = { kind: "inventory", slot: command.hotbarSlot };
  if (command.slot.kind === "inventory" && command.slot.slot === command.hotbarSlot) throw new Error("same-slot");
  const source = current(state, command.slot);
  const target = current(state, hotbarRef);
  if (target && command.slot.kind === "station") assertCanPlace(content, state, command.slot, target);
  if (command.slot.kind === "station" && state.station?.kind === "furnace" && command.slot.slot === 2 && target)
    throw new Error("furnace-output-is-read-only");
  write(state, command.slot, target);
  write(state, hotbarRef, source);
}
function matchingRecipe(content, grid) {
  if (!content.stations) throw new Error("station-content-unavailable");
  return content.stations.listRecipes().find(
    (recipe) => recipe.kind === "shaped" ? matchesShapedStationRecipe(grid, recipe, content.items) : matchesShapelessStationRecipe(grid, recipe, content.items)
  );
}
function craft(content, state, command) {
  if (state.station && (state.station.kind !== "workbench" || !state.stationSlots))
    throw new Error("station-is-not-workbench");
  if (!command.batch && state.cursorStack && state.cursorStack.count >= content.items.require(state.cursorStack.itemId).stackLimit)
    throw new Error("cursor-full");
  let grid = state.station ? state.stationSlots : state.craftingSlots;
  let output = command.batch ? state.slots : [state.cursorStack];
  let crafted = 0;
  for (let attempt = 0; attempt < 1024; attempt += 1) {
    const recipe = matchingRecipe(content, grid);
    if (!recipe) break;
    const result = createStationCraftCandidate({ items: content.items, recipe, grid, output });
    if (!result.success) {
      if (!crafted) throw new Error(result.reason);
      break;
    }
    grid = result.grid;
    output = result.output;
    crafted += 1;
    if (!command.batch) break;
  }
  if (!crafted) throw new Error("recipe-mismatch");
  if (state.station) state.stationSlots = grid;
  else state.craftingSlots = grid;
  if (command.batch) state.slots = output;
  else {
    if (output.length !== 1 || !output[0]) throw new Error("unsupported-craft-output");
    state.cursorStack = output[0];
    state.cursorOrigin = null;
  }
  state.crafted = crafted;
}
function close(content, state, station) {
  const origin = state.cursorOrigin;
  if (state.cursorStack && origin?.kind === "inventory" && origin.slot < state.slots.length) {
    const target = state.slots[origin.slot];
    if (!target || sameItemStackIdentity(target, state.cursorStack))
      put(content, state, { kind: "inventory", slot: origin.slot }, state.cursorStack.count);
  } else if (state.cursorStack && origin?.kind === "station" && station && same(origin.reference, station.reference) && state.stationSlots && origin.slot < state.stationSlots.length) {
    const target = state.stationSlots[origin.slot];
    if (!target || sameItemStackIdentity(target, state.cursorStack)) {
      const count = Math.min(state.cursorStack.count, capacity2(content.items, target, state.cursorStack));
      if (count > 0) {
        write(
          state,
          { kind: "station", slot: origin.slot },
          { ...state.cursorStack, count: (target?.count ?? 0) + count }
        );
        state.cursorStack = state.cursorStack.count === count ? null : { ...state.cursorStack, count: state.cursorStack.count - count };
        if (!state.cursorStack) state.cursorOrigin = null;
      }
    }
  }
  const settled = settleInventoryCursor(content.items, state.slots, {
    version: 1,
    revision: 0,
    stack: state.cursorStack,
    origin: state.cursorOrigin,
    craftingGrid: state.craftingSlots
  });
  state.slots = [...settled.slots];
  state.drops.push(...settled.dropIntents.map((stack2) => ({ ...stack2 })));
  state.cursorStack = null;
  state.cursorOrigin = null;
  state.craftingSlots = [...settled.cursor.craftingGrid];
}
function finalizeStation(content, previous, values) {
  if (same(stationSlots(previous), values)) return previous;
  let next;
  if (previous.kind === "workbench") next = { ...previous, revision: previous.revision + 1, grid: values };
  else if (previous.kind === "chest") next = { ...previous, revision: previous.revision + 1, slots: values };
  else {
    const furnace = { ...previous.furnace, input: values[0], fuel: values[1], output: values[2] };
    const active = furnace.activeRecipeId ? content.stations.codec.furnace.recipe(furnace.activeRecipeId) : void 0;
    if (active && (!furnace.input || !sameItemStackIdentity(furnace.input, active.input) || furnace.input.count < active.input.count)) {
      furnace.activeRecipeId = null;
      furnace.progressSeconds = 0;
    }
    next = { ...previous, revision: previous.revision + 1, furnace };
  }
  if (next.revision > Number.MAX_SAFE_INTEGER) throw new RangeError("Station revision exhausted.");
  return content.stations.codec.decode(next, previous.entityId);
}
function buildInventoryPointerCandidate(content, request) {
  const input = validateInventoryPointerInput(request.input);
  const actor = request.actor;
  if (actor.lifecycle !== "alive") throw new Error("actor-dead");
  if (!same(input.actor, actor.reference)) throw new Error("stale-actor-reference");
  if (input.expectedInventoryRevision !== actor.inventoryRevision) throw new Error("stale-inventory-revision");
  if (!integer2(actor.inventoryRevision) || actor.inventoryRevision >= Number.MAX_SAFE_INTEGER)
    throw new RangeError("Inventory revision exhausted.");
  const cursor = validateInventoryCursor(actor.cursor, content.items);
  const station = request.station;
  if (Boolean(input.station) !== Boolean(station)) throw new Error("station-context-mismatch");
  if (station) {
    if (!content.stations || !same(input.station.reference, station.reference))
      throw new Error("stale-station-reference");
    if (input.station.expectedRevision !== station.component.revision) throw new Error("stale-station-revision");
    if (station.component.revision >= Number.MAX_SAFE_INTEGER) throw new RangeError("Station revision exhausted.");
  }
  const usesStation = "slot" in input.command && input.command.slot.kind === "station" || input.command.kind === "distribute" && input.command.targets.some((target) => target.kind === "station");
  if (usesStation && !station) throw new Error("station-context-required");
  const usesPersonalCrafting = "slot" in input.command && input.command.slot.kind === "crafting" || input.command.kind === "distribute" && input.command.targets.some((target) => target.kind === "crafting");
  if (usesPersonalCrafting && station) throw new Error("invalid-pointer-slot");
  const state = {
    slots: new Inventory(actor.slots.length, actor.slots, content.items).snapshot(),
    craftingSlots: [...cursor.craftingGrid],
    cursorStack: cursor.stack ? { ...cursor.stack, ...cursor.stack.instance ? { instance: { ...cursor.stack.instance } } : {} } : null,
    cursorOrigin: cursor.origin,
    station: station?.component ?? null,
    stationSlots: station ? stationSlots(station.component) : null,
    drops: [],
    crafted: 0
  };
  const before = JSON.stringify([
    state.slots,
    state.craftingSlots,
    state.cursorStack,
    state.cursorOrigin,
    state.stationSlots
  ]);
  switch (input.command.kind) {
    case "click":
      click(content, state, station, input.command);
      break;
    case "distribute":
      distribute(content, state, input.command);
      break;
    case "quick-move":
      quickMove(content, actor, state, input.command);
      break;
    case "collect":
      collect(content, state, input.command);
      break;
    case "hotbar":
      if (input.command.hotbarSlot >= actor.equipment.hotbarSize) throw new Error("invalid-hotbar-slot");
      hotbar(content, state, input.command);
      break;
    case "craft":
      craft(content, state, input.command);
      break;
    case "close":
      close(content, state, station);
      break;
    case "drop": {
      if (!state.cursorStack) throw new Error("cursor-empty");
      const count = input.command.button === 0 ? state.cursorStack.count : 1;
      state.drops.push({ ...state.cursorStack, count });
      state.cursorStack = state.cursorStack.count === count ? null : { ...state.cursorStack, count: state.cursorStack.count - count };
      if (!state.cursorStack) state.cursorOrigin = null;
      break;
    }
  }
  const changed = before !== JSON.stringify([state.slots, state.craftingSlots, state.cursorStack, state.cursorOrigin, state.stationSlots]);
  if (changed && cursor.revision >= Number.MAX_SAFE_INTEGER)
    throw new RangeError("Inventory cursor revision exhausted.");
  const nextStation = station && state.stationSlots ? finalizeStation(content, station.component, state.stationSlots) : null;
  const inventoryRevision = actor.inventoryRevision + Number(changed);
  const nextCursor = Object.freeze({
    version: 1,
    revision: cursor.revision + Number(changed),
    stack: frozenStack3(state.cursorStack),
    origin: state.cursorStack ? state.cursorOrigin : null,
    craftingGrid: Object.freeze(state.craftingSlots.map(frozenStack3))
  });
  const result = Object.freeze({
    version: 1,
    success: true,
    kind: "pointer",
    actorId: actor.reference.entityId,
    inventoryRevision,
    cursorRevision: nextCursor.revision,
    ...nextStation && nextStation.revision !== station?.component.revision ? { stationRevision: nextStation.revision } : {},
    ...state.crafted ? { crafted: state.crafted } : {}
  });
  return Object.freeze({
    version: 1,
    kind: "pointer",
    actorId: actor.reference.entityId,
    actorReference: actor.reference,
    inventoryRevision,
    slots: Object.freeze(state.slots.map(frozenStack3)),
    cursor: nextCursor,
    stationReference: station?.reference ?? null,
    station: nextStation,
    dropIntents: Object.freeze(state.drops.map((stack2) => frozenStack3(stack2))),
    changed,
    result
  });
}

// packages/stdlib/src/server/gameplay/modules/inventory-actions-module.ts
function actorId(context) {
  if (context.kind !== "actor" || !context.originalActorId) throw new TypeError("Inventory action requires an actor.");
  return context.originalActorId;
}
function entityTarget2(target) {
  if (!target || typeof target !== "object") throw new TypeError("Inventory action requires an entity target.");
  const value = target;
  if (value.kind !== "entity" || typeof value.entityId !== "string")
    throw new TypeError("Inventory action requires an entity target.");
  return value.entityId;
}
function defineInventoryActionsModule() {
  return Object.freeze({
    descriptor: {
      id: "seedlands:inventory-actions-module",
      version: "1.0.0",
      requires: [
        { id: "seedlands:inventory", version: "1.0.0" },
        ...GAMEPLAY_CONTENT_CAPABILITIES.map((id2) => ({ id: id2, version: "1.0.0" }))
      ],
      provides: [{ id: INVENTORY_ACTIONS_CAPABILITY, version: "1.0.0" }],
      resources: [{ id: INVENTORY_ITEM_RESOURCE, operations: ["read", "execute"] }],
      permissions: [
        { resource: INVENTORY_RESOURCE, operations: ["read", "write", "execute"] },
        { resource: INVENTORY_ITEM_RESOURCE, operations: ["read", "execute"] }
      ]
    },
    register(api) {
      const itemCapability = api.requireCapability("seedlands:items");
      const contentCapabilities = gameplayContentFromRegistration(api);
      const content = () => {
        const resolved = contentCapabilities;
        if (resolved.recipes.items !== resolved.items)
          throw new TypeError("Inventory action content registries do not match.");
        for (const item of resolved.items.list())
          if (!itemCapability.has(item.id))
            throw new TypeError(`Inventory action item capability is missing ${item.id}.`);
        return resolved;
      };
      api.provideCapability(INVENTORY_ACTIONS_CAPABILITY, inventoryActionsCapability());
      api.registerState({
        id: INVENTORY_ACTOR_COMPONENT,
        version: "1.0.0",
        resource: INVENTORY_RESOURCE,
        validate(value) {
          try {
            validateInventoryActorProjection(value, content().items);
            return true;
          } catch {
            return false;
          }
        }
      });
      api.registerState({
        id: INVENTORY_ITEM_COMPONENT,
        version: "1.0.0",
        resource: INVENTORY_ITEM_RESOURCE,
        validate(value) {
          try {
            validateInventoryWorldItemProjection(value, content().items);
            return true;
          } catch {
            return false;
          }
        }
      });
      const operations = [
        { kind: "select", id: INVENTORY_SELECT_OPERATION },
        { kind: "move", id: INVENTORY_MOVE_OPERATION },
        { kind: "consume", id: INVENTORY_CONSUME_OPERATION },
        { kind: "craft", id: INVENTORY_CRAFT_OPERATION },
        { kind: "drop", id: INVENTORY_DROP_OPERATION }
      ];
      for (const operation of operations)
        api.registerOperation({
          id: operation.id,
          resource: INVENTORY_RESOURCE,
          run(context, input, state) {
            const boundActorId = actorId(context);
            if (entityTarget2(context.target) !== boundActorId)
              throw new TypeError("Inventory target must match the bound actor.");
            const actor = state.read(inventoryActorAddress(boundActorId));
            const result = operation.kind === "move" && input !== null && typeof input === "object" && !Array.isArray(input) && Object.hasOwn(input, "command") ? buildInventoryPointerCandidate(content(), { actor, input }) : buildInventoryActionCandidate(content(), { kind: operation.kind, actor, input });
            if (result.actorId !== boundActorId)
              throw new TypeError("Inventory actor projection does not match the bound actor.");
            return result;
          }
        });
      api.registerOperation({
        id: INVENTORY_PICKUP_OPERATION,
        resource: INVENTORY_ITEM_RESOURCE,
        run(context, input, state) {
          const boundActorId = actorId(context);
          const itemId = entityTarget2(context.target);
          const actor = state.read(inventoryActorAddress(boundActorId));
          const item = state.read(inventoryItemAddress(itemId));
          const candidate2 = buildInventoryActionCandidate(content(), { kind: "pickup", actor, item, input });
          if (candidate2.actorId !== boundActorId)
            throw new TypeError("Inventory actor projection does not match the bound actor.");
          if (candidate2.pickupIntent?.reference.entityId !== itemId)
            throw new TypeError("Inventory pickup target does not match its projection.");
          return candidate2;
        }
      });
    }
  });
}

// packages/stdlib/src/server/gameplay/modules/station-action-model.ts
var STATION_ACTOR_COMPONENT = "seedlands:station-actor";
var STATION_INSTANCE_COMPONENT = "seedlands:station-instance";
var STATION_ACTOR_RESOURCE = "seedlands.station-actor";
var STATION_RESOURCE = "seedlands.station";
var STATION_TRANSFER_OPERATION = "seedlands:station-transfer";
var STATION_CRAFT_OPERATION = "seedlands:station-craft";
var stationActorAddress = (entityId) => ({
  componentId: STATION_ACTOR_COMPONENT,
  target: { kind: "entity", entityId }
});
var stationInstanceAddress = (entityId) => ({
  componentId: STATION_INSTANCE_COMPONENT,
  target: { kind: "entity", entityId }
});
var record5 = (raw) => {
  if (!raw || typeof raw !== "object" || Array.isArray(raw)) throw new TypeError("Station value must be an object.");
  return raw;
};
var integer3 = (value, min, max) => typeof value === "number" && Number.isSafeInteger(value) && value >= min && value <= max;
function validateStationActor(raw, content) {
  const source = record5(raw);
  const { mode, ...base } = source;
  if (mode !== "survival" && mode !== "creative") throw new TypeError("Invalid station actor mode.");
  return { ...validateInventoryActorProjection(base, content.items), mode };
}
function validateStationProjection(raw, content) {
  if (!content.stations) throw new TypeError("World has no station content.");
  const value = record5(raw), reference3 = record5(value.reference);
  if (value.version !== 1 || typeof reference3.entityId !== "string" || !reference3.entityId.trim() || !integer3(reference3.epoch, 1, Number.MAX_SAFE_INTEGER) || !integer3(reference3.lifetime, 1, Number.MAX_SAFE_INTEGER) || !Array.isArray(value.position) || value.position.length !== 3 || !value.position.every((x2) => integer3(x2, -3e7, 3e7)))
    throw new TypeError("Invalid station projection.");
  return {
    version: 1,
    reference: { entityId: reference3.entityId, epoch: reference3.epoch, lifetime: reference3.lifetime },
    position: [...value.position],
    component: content.stations.codec.decode(value.component, reference3.entityId)
  };
}
function buildStationActionCandidate(content, request) {
  const actor = validateStationActor(request.actor, content), station = validateStationProjection(request.station, content), input = record5(request.input);
  if (actor.lifecycle !== "alive") throw new Error("actor-dead");
  if (!integer3(input.expectedStationRevision, 0, Number.MAX_SAFE_INTEGER) || input.expectedStationRevision !== station.component.revision)
    throw new Error("stale-station-revision");
  if (station.component.revision === Number.MAX_SAFE_INTEGER) throw new RangeError("Station revision exhausted.");
  let slots = new Inventory(actor.slots.length, actor.slots, content.items).snapshot();
  let next;
  if (request.kind === "craft") {
    if (Object.keys(input).some((key2) => !["expectedStationRevision", "recipeId"].includes(key2)) || typeof input.recipeId !== "string")
      throw new TypeError("Invalid station craft input.");
    if (station.component.kind !== "workbench") throw new Error("station-is-not-workbench");
    const recipe = content.stations.recipe(input.recipeId);
    if (!recipe) throw new Error("unknown-station-recipe");
    const result = createStationCraftCandidate({
      items: content.items,
      recipe,
      grid: station.component.grid,
      output: slots
    });
    if (!result.success) throw new Error(result.reason);
    slots = result.output;
    next = { ...station.component, grid: result.grid };
  } else {
    if (Object.keys(input).some(
      (key2) => !["expectedStationRevision", "from", "actorSlot", "stationSlot", "count"].includes(key2)
    ) || input.from !== "actor" && input.from !== "station")
      throw new TypeError("Invalid station transfer input.");
    const component = station.component;
    const contents = component.kind === "workbench" ? [...component.grid] : component.kind === "chest" ? [...component.slots] : [component.furnace.input, component.furnace.fuel, component.furnace.output];
    if (!integer3(input.actorSlot, 0, slots.length - 1) || !integer3(input.stationSlot, 0, contents.length - 1))
      throw new TypeError("Invalid station transfer slot.");
    if (component.kind === "furnace" && input.from === "actor" && input.stationSlot === 2)
      throw new Error("furnace-output-is-read-only");
    const from = input.from === "actor" ? slots : contents, to = input.from === "actor" ? contents : slots;
    const fromIndex = input.from === "actor" ? input.actorSlot : input.stationSlot, toIndex = input.from === "actor" ? input.stationSlot : input.actorSlot;
    const source = from[fromIndex], target = to[toIndex];
    if (!source) throw new Error("empty-source-slot");
    const count = input.count ?? source.count;
    if (!integer3(count, 1, source.count)) throw new TypeError("Invalid station transfer count.");
    if (target && !sameItemStackIdentity(source, target)) throw new Error("destination-occupied");
    if ((target?.count ?? 0) + count > content.items.require(source.itemId).stackLimit)
      throw new Error("destination-full");
    if (component.kind === "furnace" && input.from === "actor") {
      const furnace = content.stations.codec.furnace;
      const recipe = furnace.recipeForInput(source.itemId);
      if (input.stationSlot === 0 && (!recipe || !sameItemStackIdentity(source, recipe.input)))
        throw new Error("invalid-furnace-input");
      if (input.stationSlot === 1 && !furnace.fuel(source.itemId)) throw new Error("invalid-furnace-fuel");
    }
    from[fromIndex] = source.count === count ? null : { ...source, count: source.count - count };
    to[toIndex] = { ...source, count: (target?.count ?? 0) + count };
    if (component.kind === "workbench") next = { ...component, grid: contents };
    else if (component.kind === "chest") next = { ...component, slots: contents };
    else {
      const furnace = { ...component.furnace, input: contents[0], fuel: contents[1], output: contents[2] };
      const active = furnace.activeRecipeId ? content.stations.codec.furnace.recipe(furnace.activeRecipeId) : void 0;
      if (active && (!furnace.input || !sameItemStackIdentity(furnace.input, active.input) || furnace.input.count < active.input.count)) {
        furnace.activeRecipeId = null;
        furnace.progressSeconds = 0;
      }
      next = { ...component, furnace };
    }
  }
  next = content.stations.codec.decode({ ...next, revision: station.component.revision + 1 });
  return {
    version: 1,
    kind: request.kind,
    actorReference: actor.reference,
    stationReference: station.reference,
    slots: new Inventory(slots.length, slots, content.items).snapshot(),
    station: next,
    result: {
      version: 1,
      success: true,
      kind: request.kind,
      actorId: actor.reference.entityId,
      stationId: station.reference.entityId,
      stationRevision: next.revision
    }
  };
}

// packages/stdlib/src/server/gameplay/modules/block-actions-module.ts
var actorId2 = (context) => {
  if (context.kind !== "actor" || !context.originalActorId) throw new TypeError("Block action requires an actor.");
  return context.originalActorId;
};
var targetActor = (target) => {
  if (!target || typeof target !== "object") throw new TypeError("Block cancel requires an entity target.");
  const value = target;
  if (value.kind !== "entity" || typeof value.entityId !== "string")
    throw new TypeError("Block cancel requires an entity target.");
  return value.entityId;
};
var targetPosition = (target) => {
  if (!target || typeof target !== "object") throw new TypeError("Block action requires a voxel target.");
  const value = target;
  if (value.kind !== "voxel") throw new TypeError("Block action requires a voxel target.");
  return validateBlockPosition(value.position, "Block authorization target");
};
function defineBlockActionsModule(options = {}) {
  return Object.freeze({
    descriptor: {
      id: "seedlands:block-actions-module",
      version: "1.0.0",
      requires: [
        ...options.stations ? [{ id: "seedlands:station-actions", version: "1.0.0" }] : [],
        ...options.media ? [{ id: MEDIA_PLAYBACK_CAPABILITY, version: "1.0.0" }] : [],
        ...GAMEPLAY_CONTENT_CAPABILITIES.map((id2) => ({ id: id2, version: "1.0.0" }))
      ],
      provides: [{ id: BLOCK_ACTIONS_CAPABILITY, version: "1.0.0" }],
      resources: [
        { id: BLOCK_ACTOR_RESOURCE, operations: ["read", "execute"] },
        { id: BLOCK_VOXEL_RESOURCE, operations: ["read", "execute"] },
        { id: BLOCK_CLOCK_RESOURCE, operations: ["read", "execute"] }
      ],
      permissions: [
        ...options.stations ? [{ resource: STATION_RESOURCE, operations: ["execute"] }] : [],
        ...options.media ? [{ resource: MEDIA_PLAYBACK_RESOURCE, operations: ["execute"] }] : [],
        { resource: BLOCK_ACTOR_RESOURCE, operations: ["read", "execute"] },
        { resource: BLOCK_VOXEL_RESOURCE, operations: ["read", "execute"] },
        { resource: BLOCK_CLOCK_RESOURCE, operations: ["read", "execute"] }
      ]
    },
    register(api) {
      const itemCapability = api.requireCapability("seedlands:items");
      const contentCapabilities = gameplayContentFromRegistration(api);
      const content = () => {
        const resolved = contentCapabilities;
        for (const item of resolved.items.list())
          if (!itemCapability.has(item.id)) throw new TypeError(`Block content item capability is missing ${item.id}.`);
        return resolved;
      };
      api.provideCapability(BLOCK_ACTIONS_CAPABILITY, blockActionsCapability());
      api.registerState({
        id: BLOCK_ACTOR_COMPONENT,
        version: "1.0.0",
        resource: BLOCK_ACTOR_RESOURCE,
        validate(value) {
          try {
            validateBlockActorProjection(value, content().items);
            return true;
          } catch {
            return false;
          }
        }
      });
      api.registerState({
        id: BLOCK_VOXEL_COMPONENT,
        version: "1.0.0",
        resource: BLOCK_VOXEL_RESOURCE,
        validate(value) {
          try {
            validateBlockVoxelProjection(value);
            return true;
          } catch {
            return false;
          }
        }
      });
      api.registerState({
        id: BLOCK_WORLD_COMPONENT,
        version: "1.0.0",
        resource: BLOCK_CLOCK_RESOURCE,
        partitions: BLOCK_PARTITIONS,
        validate(value) {
          try {
            validateBlockWorldProjection(value);
            return true;
          } catch {
            return false;
          }
        }
      });
      for (const operation of [
        { kind: "begin", id: BLOCK_BEGIN_OPERATION },
        { kind: "place", id: BLOCK_PLACE_OPERATION },
        { kind: "finish", id: BLOCK_FINISH_OPERATION }
      ])
        api.registerOperation({
          id: operation.id,
          resource: BLOCK_VOXEL_RESOURCE,
          run(context, input, state) {
            const boundActorId = actorId2(context);
            const position4 = targetPosition(context.target);
            const result = buildBlockActionCandidate(content(), {
              kind: operation.kind,
              actor: state.read(blockActorAddress(boundActorId)),
              voxel: state.read(blockVoxelAddress(position4)),
              input
            });
            if (result.actorId !== boundActorId || !result.position || !samePosition2(result.position, position4))
              throw new TypeError("Block candidate identity does not match its execution context.");
            return result;
          }
        });
      api.registerOperation({
        id: BLOCK_CANCEL_OPERATION,
        resource: BLOCK_ACTOR_RESOURCE,
        run(context, input, state) {
          const boundActorId = actorId2(context);
          if (targetActor(context.target) !== boundActorId)
            throw new TypeError("Block cancel target must match the bound actor.");
          const result = buildBlockActionCandidate(content(), {
            kind: "cancel",
            actor: state.read(blockActorAddress(boundActorId)),
            input
          });
          if (result.actorId !== boundActorId)
            throw new TypeError("Block actor projection does not match the bound actor.");
          return result;
        }
      });
      api.registerOperation({
        id: BLOCK_ADVANCE_OPERATION,
        executionKind: "system",
        resource: BLOCK_CLOCK_RESOURCE,
        run(context, input, state) {
          if (context.kind !== "system" || context.target.kind !== "world")
            throw new TypeError("Block advance requires its world clock.");
          const advance = validateBlockAdvanceInput(input);
          const entries = [];
          let previous = "";
          for (let partition = 0; partition < BLOCK_PARTITIONS; partition++) {
            const projection = validateBlockWorldProjection(state.read(blockWorldAddress(partition)));
            if (projection.partition !== partition)
              throw new TypeError("Block world projection partition does not match its address.");
            for (const entry of projection.entries) {
              if (entry.reference.entityId <= previous)
                throw new TypeError("Block world projections are duplicated or globally unsorted.");
              previous = entry.reference.entityId;
              entries.push(entry);
            }
          }
          buildBlockAdvanceUpdates(entries, advance);
          return Object.freeze({ version: 1, kind: "advance", ...advance });
        }
      });
      api.registerSystem({ id: BLOCK_SYSTEM, operationId: BLOCK_ADVANCE_OPERATION, cadence: "every-advance" });
    }
  });
}
var samePosition2 = (left, right) => left.length === right.length && left.every((value, index) => value === right[index]);
var fail4 = (reason) => {
  throw new Error(reason);
};
var freezeSlots3 = (items, slots) => Object.freeze(slots.map((slot) => slot ? cloneBlockStack(items, slot, true) : null));
function actorCandidate(items, input) {
  return Object.freeze({
    version: 1,
    kind: input.kind,
    actorId: input.actor.reference.entityId,
    actorReference: cloneBlockReference(input.actor.reference),
    position: input.position ? validateBlockPosition(input.position) : null,
    slots: input.slots,
    breakAction: input.breakAction ? validateBlockBreakAction(input.breakAction) : null,
    voxelEdit: input.voxelEdit ? Object.freeze({
      position: validateBlockPosition(input.voxelEdit.position),
      fromVoxel: input.voxelEdit.fromVoxel,
      toVoxel: input.voxelEdit.toVoxel
    }) : null,
    dropIntent: input.dropIntent ? Object.freeze({
      position: Object.freeze([...input.dropIntent.position]),
      stack: cloneBlockStack(items, input.dropIntent.stack, false)
    }) : null,
    result: Object.freeze({
      version: 1,
      success: true,
      kind: input.kind,
      actorId: input.actor.reference.entityId,
      ...input.requiredSeconds === void 0 ? {} : { requiredSeconds: input.requiredSeconds }
    })
  });
}
function buildBlockActionCandidate(content, request) {
  const actor = validateBlockActorProjection(request.actor, content.items);
  const inventory = createInventoryCandidate(content.items, actor.slots);
  const slots = () => freezeSlots3(content.items, inventory.snapshot());
  if (request.kind === "cancel") {
    if (request.input !== void 0) throw new TypeError("Block cancel input must be omitted.");
    return actorCandidate(content.items, { kind: "cancel", actor, position: null, slots: slots(), breakAction: null });
  }
  if (actor.lifecycle !== "alive") fail4("actor-dead");
  const target = validateBlockVoxelProjection(request.voxel);
  if (request.kind === "begin") {
    const effective2 = validateBlockBeginEffectiveInput(request.input);
    if (!samePosition2(target.position, effective2.position) || target.voxel !== effective2.expectedVoxel)
      fail4("block-target-changed");
    if (actor.mode.revision !== effective2.modeRevision || actor.mode.value === "creative" !== effective2.creative)
      fail4("block-mode-changed");
    if (effective2.creative)
      return actorCandidate(content.items, {
        kind: "begin",
        actor,
        position: target.position,
        slots: slots(),
        breakAction: null,
        voxelEdit: { position: target.position, fromVoxel: target.voxel, toVoxel: Voxel.Air },
        requiredSeconds: 0
      });
    const current3 = actor.breakAction;
    const retained = current3 && current3.voxel === target.voxel && samePosition2(current3.position, target.position);
    const next = retained ? current3 : Object.freeze({
      position: validateBlockPosition(target.position),
      voxel: target.voxel,
      elapsedSeconds: 0,
      requiredSeconds: effective2.requiredSeconds
    });
    return actorCandidate(content.items, {
      kind: "begin",
      actor,
      position: target.position,
      slots: slots(),
      breakAction: next,
      requiredSeconds: next.requiredSeconds
    });
  }
  if (request.kind === "place") {
    const effective2 = validateBlockPlaceEffectiveInput(request.input);
    if (!samePosition2(target.position, effective2.position) || target.voxel !== effective2.expectedVoxel)
      fail4("block-target-changed");
    if (actor.mode.revision !== effective2.modeRevision) fail4("block-mode-changed");
    const place = content.items.capability(effective2.itemId, "place");
    if (!place || place.voxel !== effective2.placedVoxel) fail4("item-not-placeable");
    if (actor.mode.value === "creative") {
      if (effective2.consumeCount !== 0 || actor.creativeCatalog.hotbar[actor.creativeCatalog.selectedSlot] !== effective2.itemId)
        fail4("block-selection-changed");
    } else {
      const selected = inventory.slot(actor.equipment.selectedSlot);
      if (effective2.consumeCount !== 1 || selected?.itemId !== effective2.itemId || !inventory.removeFromSlot(actor.equipment.selectedSlot, 1))
        fail4("block-selection-changed");
    }
    return actorCandidate(content.items, {
      kind: "place",
      actor,
      position: target.position,
      slots: slots(),
      breakAction: actor.breakAction,
      voxelEdit: { position: target.position, fromVoxel: target.voxel, toVoxel: effective2.placedVoxel }
    });
  }
  const effective = validateBlockFinishEffectiveInput(request.input, content.items);
  const current2 = actor.breakAction;
  if (!current2) throw new Error("no-break-action");
  if (!samePosition2(target.position, effective.position) || !samePosition2(current2.position, target.position) || target.voxel !== effective.expectedVoxel || current2.voxel !== target.voxel)
    fail4("block-target-changed");
  if (actor.mode.revision !== effective.modeRevision || actor.mode.value === "creative" !== effective.creative)
    fail4("block-mode-changed");
  if (current2.elapsedSeconds + Number.EPSILON < current2.requiredSeconds) fail4("break-not-ready");
  if (effective.toolWear === 1) {
    const slot = actor.equipment.selectedSlot;
    const selected = inventory.slot(slot);
    if (!selected?.instance || !content.items.capability(selected.itemId, "mine"))
      throw new Error("invalid-mining-tool-wear");
    const next = inventory.snapshot();
    next[slot] = selected.instance.durability === 1 ? null : {
      ...selected,
      instance: { durability: selected.instance.durability - 1 }
    };
    inventory.replace(next);
  }
  const dropIntent = effective.drop ? { position: target.position.map((value) => value + 0.5), stack: effective.drop } : void 0;
  return actorCandidate(content.items, {
    kind: "finish",
    actor,
    position: target.position,
    slots: slots(),
    breakAction: null,
    voxelEdit: { position: target.position, fromVoxel: target.voxel, toVoxel: Voxel.Air },
    dropIntent
  });
}
function buildBlockAdvanceUpdates(rawEntries, rawInput) {
  if (!Array.isArray(rawEntries) || rawEntries.length > BLOCK_PARTITIONS * BLOCK_PARTITION_SIZE)
    throw new TypeError("Block advance entries are invalid.");
  const input = validateBlockAdvanceInput(rawInput);
  const cancellations = new Set(input.cancelActorIds);
  const seen = /* @__PURE__ */ new Set();
  const updates = [];
  for (const raw of rawEntries) {
    const entry = blockData(raw, ["reference", "breakAction"], "Block advance entry");
    const reference3 = cloneBlockReference(entry.reference);
    if (seen.has(reference3.entityId)) throw new TypeError("Block advance actor is duplicated.");
    seen.add(reference3.entityId);
    if (entry.breakAction === null) continue;
    const previous = validateBlockBreakAction(entry.breakAction);
    const cancelled = cancellations.delete(reference3.entityId);
    const elapsedSeconds = Math.min(
      previous.requiredSeconds,
      (Math.round(previous.elapsedSeconds * 1e9) + Math.round(input.seconds * 1e9)) / 1e9
    );
    const next = cancelled ? null : validateBlockBreakAction({
      position: previous.position,
      voxel: previous.voxel,
      elapsedSeconds,
      requiredSeconds: previous.requiredSeconds,
      ...previous.origin ? { origin: previous.origin } : {}
    });
    updates.push(
      Object.freeze({
        reference: reference3,
        previous,
        next,
        ready: Boolean(next && next.elapsedSeconds + Number.EPSILON >= next.requiredSeconds)
      })
    );
  }
  if (cancellations.size) fail4("unknown-cancel-actor");
  return Object.freeze(updates);
}

// packages/stdlib/src/server/gameplay/modules/mining-tool-policy.ts
function validateRequirement(requirement) {
  if (requirement.preferredTool !== null && requirement.preferredTool !== "axe" && requirement.preferredTool !== "pickaxe" && requirement.preferredTool !== "shovel" || !Number.isSafeInteger(requirement.minimumTier) || requirement.minimumTier < 0 || requirement.minimumTier > 0 && requirement.preferredTool === null)
    throw new TypeError("Mining tool requirement is invalid.");
}
function snapshotStack(stack2) {
  return Object.freeze({
    itemId: stack2.itemId,
    count: stack2.count,
    ...stack2.instance ? { instance: Object.freeze({ durability: stack2.instance.durability }) } : {}
  });
}
function createMiningToolUseCandidate(items, selectedStackOrNull, requirement) {
  validateRequirement(requirement);
  const selected = selectedStackOrNull === null ? null : items.normalizeStack(selectedStackOrNull);
  const mine = selected ? items.capability(selected.itemId, "mine") : void 0;
  if (requirement.minimumTier > 0 && (!mine || mine.tool !== requirement.preferredTool || (mine.tier ?? 0) < requirement.minimumTier))
    throw new Error("mining-tool-requirement-not-met");
  const multiplier = mine?.tool === requirement.preferredTool ? mine.multiplier : 1;
  let nextStack = selected === null ? null : snapshotStack(selected);
  if (selected && mine && items.require(selected.itemId).durability) {
    const durability = selected.instance.durability;
    nextStack = durability === 1 ? null : snapshotStack({
      itemId: selected.itemId,
      count: selected.count,
      instance: { durability: durability - 1 }
    });
  }
  return Object.freeze({ multiplier, nextStack });
}

// packages/stdlib/src/server/gameplay/modules/block-rules-module.ts
var actorTarget = (context) => {
  if (context.kind !== "actor" || !context.originalActorId || context.target.kind !== "voxel")
    throw new TypeError("Block rule requires an actor and voxel target.");
  return Object.freeze({
    actorId: context.originalActorId,
    position: validateBlockPosition(context.target.position, "Block rule target")
  });
};
var samePosition3 = (left, right) => left.every((value, index) => value === right[index]);
var sameData = (left, right) => JSON.stringify(left) === JSON.stringify(right);
function snapshotDefinition2(raw) {
  const hasTier = typeof raw === "object" && raw !== null && Object.hasOwn(raw, "minimumTier");
  const value = blockData(
    raw,
    ["voxel", "hardnessSeconds", "preferredTool", "drop", "replaceable", ...hasTier ? ["minimumTier"] : []],
    "Block rule definition"
  );
  if (typeof value.voxel !== "number" || !Number.isSafeInteger(value.voxel) || value.voxel < 0 || value.voxel > 65535)
    throw new TypeError("Block rule voxel is invalid.");
  if (value.hardnessSeconds !== null && (typeof value.hardnessSeconds !== "number" || !Number.isFinite(value.hardnessSeconds) || Number(value.hardnessSeconds.toFixed(6)) <= 0 || value.hardnessSeconds > 1e6))
    throw new TypeError("Block rule hardness is invalid.");
  if (value.preferredTool !== null && value.preferredTool !== "axe" && value.preferredTool !== "pickaxe" && value.preferredTool !== "shovel")
    throw new TypeError("Block rule preferred tool is invalid.");
  if (hasTier && (typeof value.minimumTier !== "number" || !Number.isSafeInteger(value.minimumTier) || value.minimumTier < 0 || value.minimumTier > 0 && value.preferredTool === null))
    throw new TypeError("Block rule minimum tool tier is invalid.");
  if (typeof value.replaceable !== "boolean") throw new TypeError("Block rule replaceability is invalid.");
  let drop = null;
  if (value.drop !== null) {
    const hasInstance = typeof value.drop === "object" && value.drop !== null && Object.hasOwn(value.drop, "instance");
    const stack2 = blockData(
      value.drop,
      hasInstance ? ["itemId", "count", "instance"] : ["itemId", "count"],
      "Block rule drop"
    );
    if (!isItemId(stack2.itemId) || typeof stack2.count !== "number" || !Number.isSafeInteger(stack2.count) || stack2.count <= 0)
      throw new TypeError("Block rule drop identity or count is invalid.");
    let instance;
    if (hasInstance) {
      const state = blockData(stack2.instance, ["durability"], "Block rule drop instance");
      if (typeof state.durability !== "number" || !Number.isSafeInteger(state.durability) || state.durability <= 0)
        throw new TypeError("Block rule drop durability is invalid.");
      instance = Object.freeze({ durability: state.durability });
    }
    drop = Object.freeze({ itemId: stack2.itemId, count: stack2.count, ...instance ? { instance } : {} });
  }
  return Object.freeze({
    voxel: value.voxel,
    ...hasTier ? { minimumTier: value.minimumTier } : {},
    hardnessSeconds: value.hardnessSeconds,
    preferredTool: value.preferredTool,
    drop,
    replaceable: value.replaceable
  });
}
function defineBlockRulesModule(options) {
  const moduleId = options.moduleId;
  if (!moduleId?.trim()) throw new TypeError("Block Rules module ID is invalid.");
  const definitions3 = /* @__PURE__ */ new Map();
  if (!Array.isArray(options.voxelDefinitions)) throw new TypeError("Block Rules requires explicit voxel definitions.");
  for (const raw of options.voxelDefinitions) {
    const definition3 = snapshotDefinition2(raw);
    if (definitions3.has(definition3.voxel)) throw new TypeError(`Duplicate Block rule voxel: ${definition3.voxel}`);
    definitions3.set(definition3.voxel, definition3);
  }
  const definition2 = (voxel2) => {
    const value = definitions3.get(voxel2);
    if (!value) throw new RangeError(`Unknown Block rule voxel: ${voxel2}`);
    return value;
  };
  return Object.freeze({
    descriptor: {
      id: moduleId,
      version: "1.0.0",
      requires: [
        { id: BLOCK_ACTIONS_CAPABILITY, version: "1.0.0" },
        ...GAMEPLAY_CONTENT_CAPABILITIES.map((id2) => ({ id: id2, version: "1.0.0" }))
      ],
      provides: [{ id: BLOCK_RULES_CAPABILITY, version: "1.0.0" }],
      permissions: [
        { resource: BLOCK_ACTOR_RESOURCE, operations: ["read", "execute"] },
        { resource: BLOCK_VOXEL_RESOURCE, operations: ["read", "execute"] }
      ]
    },
    register(api) {
      api.requireCapability(BLOCK_ACTIONS_CAPABILITY);
      const contentCapabilities = gameplayContentFromRegistration(api);
      const content = () => contentCapabilities;
      api.provideCapability(
        BLOCK_RULES_CAPABILITY,
        Object.freeze({
          moduleId,
          definitions: Object.freeze([...definitions3.values()])
        })
      );
      const current2 = (context, state) => {
        const target = actorTarget(context);
        const actor = validateBlockActorProjection(state.read(blockActorAddress(target.actorId)), content().items);
        if (!positionsInRange(actor.position, voxelCenter([...target.position]), 5)) throw new Error("out-of-range");
        const voxel2 = validateBlockVoxelProjection(state.read(blockVoxelAddress(target.position)));
        if (actor.reference.entityId !== target.actorId || !samePosition3(voxel2.position, target.position))
          throw new TypeError("Block rule projection identity changed.");
        return { target, actor, voxel: voxel2 };
      };
      const rawTarget = (context, input) => {
        const raw = validateBlockTargetInput(input);
        const target = actorTarget(context);
        if (!samePosition3(raw.position, target.position)) throw new TypeError("Block rule input target changed.");
        return raw.position;
      };
      const deriveBegin = (context, input, state) => {
        rawTarget(context, input);
        const { actor, voxel: voxel2 } = current2(context, state);
        if (actor.lifecycle !== "alive") throw new Error("actor-dead");
        const gameplay = definition2(voxel2.voxel);
        if (gameplay.hardnessSeconds === null) throw new Error("unbreakable");
        if (actor.mode.value === "creative")
          return Object.freeze({
            position: voxel2.position,
            expectedVoxel: voxel2.voxel,
            creative: true,
            requiredSeconds: 0,
            modeRevision: actor.mode.revision
          });
        const selected = actor.slots[actor.equipment.selectedSlot];
        const { multiplier } = createMiningToolUseCandidate(content().items, selected, {
          preferredTool: gameplay.preferredTool,
          minimumTier: gameplay.minimumTier ?? 0
        });
        return Object.freeze({
          position: voxel2.position,
          expectedVoxel: voxel2.voxel,
          creative: false,
          requiredSeconds: Number((gameplay.hardnessSeconds / multiplier).toFixed(6)),
          modeRevision: actor.mode.revision
        });
      };
      const derivePlace = (context, input, state) => {
        rawTarget(context, input);
        const { actor, voxel: voxel2 } = current2(context, state);
        if (actor.lifecycle !== "alive") throw new Error("actor-dead");
        if (!definition2(voxel2.voxel).replaceable) throw new Error("target-occupied");
        const creative = actor.mode.value === "creative";
        const selected = creative ? actor.creativeCatalog.hotbar[actor.creativeCatalog.selectedSlot] : actor.slots[actor.equipment.selectedSlot]?.itemId;
        if (!selected) throw new Error("no-selected-item");
        const place = content().items.capability(selected, "place");
        if (!place) throw new Error("item-not-placeable");
        return Object.freeze({
          position: voxel2.position,
          expectedVoxel: voxel2.voxel,
          placedVoxel: place.voxel,
          itemId: selected,
          consumeCount: creative ? 0 : 1,
          modeRevision: actor.mode.revision
        });
      };
      const deriveFinish = (context, input, state) => {
        rawTarget(context, input);
        const { actor, voxel: voxel2 } = current2(context, state);
        if (actor.lifecycle !== "alive") throw new Error("actor-dead");
        if (!actor.breakAction || !samePosition3(actor.breakAction.position, voxel2.position))
          throw new Error("no-break-action");
        const gameplay = definition2(voxel2.voxel);
        const creative = actor.mode.value === "creative";
        let toolWear = 0;
        if (!creative) {
          const selected = actor.slots[actor.equipment.selectedSlot];
          const policy = createMiningToolUseCandidate(content().items, selected, {
            preferredTool: gameplay.preferredTool,
            minimumTier: gameplay.minimumTier ?? 0
          });
          if (gameplay.hardnessSeconds === null || Number((gameplay.hardnessSeconds / policy.multiplier).toFixed(6)) !== actor.breakAction.requiredSeconds)
            throw new Error("mining-tool-changed");
          toolWear = sameData(selected, policy.nextStack) ? 0 : 1;
        }
        return Object.freeze({
          position: voxel2.position,
          expectedVoxel: voxel2.voxel,
          creative,
          toolWear,
          drop: creative || gameplay.drop === null ? null : content().items.normalizeStack(gameplay.drop),
          modeRevision: actor.mode.revision
        });
      };
      const register = (kind, operationId, derive) => {
        api.registerRule({
          id: `${moduleId}/${kind}-before`,
          operationId,
          stage: "before",
          apply(context, input, state) {
            if (context.kind !== "actor") throw new TypeError("Block rule requires actor execution.");
            return { input: derive(context, input, state) };
          }
        });
        api.registerRule({
          id: `${moduleId}/${kind}-after`,
          operationId,
          stage: "after",
          apply(context, input, state, candidate2) {
            if (context.kind !== "actor") return { reject: "block-candidate-context-mismatch" };
            const effective = kind === "begin" ? validateBlockBeginEffectiveInput(input) : kind === "place" ? validateBlockPlaceEffectiveInput(input) : validateBlockFinishEffectiveInput(input, content().items);
            const expectedInput = derive(context, { position: effective.position }, state);
            if (!sameData(effective, expectedInput)) return { reject: `block-${kind}-policy-mismatch` };
            const { actor, voxel: voxel2 } = current2(context, state);
            const expected = buildBlockActionCandidate(content(), { kind, actor, voxel: voxel2, input: effective });
            if (!sameData(candidate2, expected)) return { reject: `block-${kind}-candidate-mismatch` };
          }
        });
      };
      register("begin", BLOCK_BEGIN_OPERATION, deriveBegin);
      register("place", BLOCK_PLACE_OPERATION, derivePlace);
      register("finish", BLOCK_FINISH_OPERATION, deriveFinish);
      api.registerRule({
        id: `${moduleId}/cancel-after`,
        operationId: BLOCK_CANCEL_OPERATION,
        stage: "after",
        apply(context, input, state, candidate2) {
          if (context.kind !== "actor" || input !== void 0) return { reject: "block-cancel-context-mismatch" };
          const actor = validateBlockActorProjection(
            state.read(blockActorAddress(context.originalActorId)),
            content().items
          );
          const expected = buildBlockActionCandidate(content(), { kind: "cancel", actor, input: void 0 });
          if (!sameData(candidate2, expected)) return { reject: "block-cancel-candidate-mismatch" };
        }
      });
    }
  });
}

// packages/stdlib/src/server/gameplay/modules/furnace-world-model.ts
var FURNACE_WORLD_COMPONENT = "seedlands:furnace-world";
var FURNACE_RESOURCE = "seedlands.furnace-clock";
var FURNACE_ADVANCE_OPERATION = "seedlands:furnace-advance";
var FURNACE_SYSTEM = "seedlands:furnace-system";
var FURNACE_PARTITIONS = 8;
var FURNACE_PARTITION_SIZE = 128;
var furnaceWorldAddress = (partition) => ({
  componentId: FURNACE_WORLD_COMPONENT,
  target: { kind: "world" },
  partition
});
function validateFurnacePartition(raw, content) {
  const value = raw;
  if (!value || value.version !== 1 || typeof value.partition !== "number" || !Number.isSafeInteger(value.partition) || value.partition < 0 || value.partition >= FURNACE_PARTITIONS || !Array.isArray(value.entries) || value.entries.length > FURNACE_PARTITION_SIZE)
    throw new TypeError("Invalid furnace world partition.");
  const entries = value.entries.map((entry) => validateStationProjection(entry, content));
  let previous = "";
  for (const entry of entries) {
    if (entry.component.kind !== "furnace" || entry.reference.entityId <= previous)
      throw new TypeError("Invalid furnace membership order.");
    previous = entry.reference.entityId;
  }
  return { version: 1, partition: value.partition, entries };
}
function furnaceSeconds(raw) {
  const input = raw;
  if (!input || typeof input !== "object" || Object.keys(input).some((key2) => key2 !== "seconds") || typeof input.seconds !== "number" || !Number.isFinite(input.seconds) || input.seconds < 0 || input.seconds > 1)
    throw new TypeError("Furnace logical step must be 0..1 seconds.");
  return input.seconds;
}
function buildFurnaceWorldCandidate(entries, seconds, content) {
  const updates = [];
  let previous = "";
  for (const entry of entries) {
    if (entry.reference.entityId <= previous || entry.component.kind !== "furnace")
      throw new TypeError("Invalid furnace world membership.");
    previous = entry.reference.entityId;
    const advanced = advanceFurnaceCandidate(entry.component.furnace, seconds, content.stations.codec.furnace);
    if (JSON.stringify(advanced.snapshot) === JSON.stringify(entry.component.furnace)) continue;
    if (entry.component.revision === Number.MAX_SAFE_INTEGER) throw new RangeError("Furnace revision exhausted.");
    updates.push({
      ...entry,
      component: content.stations.codec.decode({
        ...entry.component,
        revision: entry.component.revision + 1,
        furnace: advanced.snapshot
      })
    });
  }
  return { version: 1, kind: "furnace-advance", seconds, updates };
}

// packages/stdlib/src/server/gameplay/modules/station-actions-module.ts
function defineStationActionsModule() {
  return Object.freeze({
    descriptor: {
      id: "seedlands:station-actions-module",
      version: "1.0.0",
      requires: GAMEPLAY_CONTENT_CAPABILITIES.map((id2) => ({ id: id2, version: "1.0.0" })),
      provides: [{ id: "seedlands:station-actions", version: "1.0.0" }],
      resources: [STATION_RESOURCE, STATION_ACTOR_RESOURCE, FURNACE_RESOURCE].map((id2) => ({
        id: id2,
        operations: ["read", "execute"]
      })),
      permissions: [STATION_RESOURCE, STATION_ACTOR_RESOURCE, FURNACE_RESOURCE].map((resource) => ({
        resource,
        operations: ["read", "execute"]
      }))
    },
    register(api) {
      const contentCapabilities = gameplayContentFromRegistration(api);
      const content = () => {
        const value = contentCapabilities;
        if (!value.stations) throw new TypeError("Station actions require explicit station content.");
        return value;
      };
      api.onDefinitionsReady(content);
      api.registerState({
        id: FURNACE_WORLD_COMPONENT,
        version: "1.0.0",
        resource: FURNACE_RESOURCE,
        partitions: FURNACE_PARTITIONS,
        validate(raw) {
          try {
            validateFurnacePartition(raw, content());
            return true;
          } catch {
            return false;
          }
        }
      });
      api.registerOperation({
        id: FURNACE_ADVANCE_OPERATION,
        executionKind: "system",
        resource: FURNACE_RESOURCE,
        run(context, input, state) {
          if (context.kind !== "system" || context.target.kind !== "world")
            throw new TypeError("Furnace advance requires world system execution.");
          const seconds = furnaceSeconds(input), entries = [];
          for (let partition = 0; partition < FURNACE_PARTITIONS; partition++) {
            const projection = validateFurnacePartition(state.read(furnaceWorldAddress(partition)), content());
            if (projection.partition !== partition) throw new TypeError("Furnace partition address mismatch.");
            entries.push(...projection.entries);
          }
          return buildFurnaceWorldCandidate(entries, seconds, content());
        }
      });
      api.registerSystem({ id: FURNACE_SYSTEM, operationId: FURNACE_ADVANCE_OPERATION, cadence: "every-advance" });
      api.provideCapability(
        "seedlands:station-actions",
        Object.freeze({
          transferOperationId: STATION_TRANSFER_OPERATION,
          craftOperationId: STATION_CRAFT_OPERATION,
          actorComponentId: STATION_ACTOR_COMPONENT,
          stationComponentId: STATION_INSTANCE_COMPONENT
        })
      );
      api.registerState({
        id: STATION_ACTOR_COMPONENT,
        version: "1.0.0",
        resource: STATION_ACTOR_RESOURCE,
        validate(raw) {
          try {
            validateStationActor(raw, content());
            return true;
          } catch {
            return false;
          }
        }
      });
      api.registerState({
        id: STATION_INSTANCE_COMPONENT,
        version: "1.0.0",
        resource: STATION_RESOURCE,
        validate(raw) {
          try {
            validateStationProjection(raw, content());
            return true;
          } catch {
            return false;
          }
        }
      });
      for (const [kind, id2] of [
        ["transfer", STATION_TRANSFER_OPERATION],
        ["craft", STATION_CRAFT_OPERATION]
      ])
        api.registerOperation({
          id: id2,
          resource: STATION_RESOURCE,
          run(context, input, state) {
            if (context.kind !== "actor" || context.target.kind !== "entity")
              throw new TypeError("Station interaction requires an actor and station entity.");
            const actor = state.read(stationActorAddress(context.originalActorId));
            const station = state.read(stationInstanceAddress(context.target.entityId));
            const pointer = input !== null && typeof input === "object" && !Array.isArray(input) && Object.hasOwn(input, "command");
            const candidate2 = pointer ? buildInventoryPointerCandidate(content(), { actor, station, input }) : buildStationActionCandidate(content(), { kind, actor, station, input });
            if (pointer && candidate2.result.kind !== "pointer")
              throw new TypeError("Station pointer candidate kind is invalid.");
            if (pointer && input.command.kind === "craft" !== (kind === "craft"))
              throw new TypeError("Station pointer operation kind is invalid.");
            if (candidate2.actorReference.entityId !== context.originalActorId || candidate2.stationReference?.entityId !== context.target.entityId)
              throw new TypeError("Station projection identity mismatch.");
            return candidate2;
          }
        });
    }
  });
}

// packages/stdlib/src/server/gameplay/modules/forage-model.ts
var FORAGE_MODULE_ID = "seedlands:forage-module";
var FORAGE_CAPABILITY = "seedlands:forage";
var FORAGE_WORLD_COMPONENT = "seedlands:forage-world";
var FORAGE_RESOURCE = "seedlands.forage-clock";
var FORAGE_ADVANCE_OPERATION = "seedlands:forage-advance";
var FORAGE_SYSTEM = "seedlands:forage-system";
var FORAGE_HORIZONTAL_RADIUS = 4;
var FORAGE_VERTICAL_MIN = 0;
var FORAGE_VERTICAL_MAX = 8;
var FORAGE_MAX_DROPS = 16;
var forageWorldAddress = () => ({
  componentId: FORAGE_WORLD_COMPONENT,
  target: { kind: "world" }
});
function forageSeconds(raw, configuration) {
  const value = raw;
  if (!value || typeof value !== "object" || Object.keys(value).some((entry) => entry !== "seconds") || value.seconds !== configuration.intervalSeconds)
    throw new TypeError("Forage maturity step must match its configured interval.");
  return configuration.intervalSeconds;
}
var position3 = (raw, label, integer4) => {
  if (!Array.isArray(raw) || raw.length !== 3 || !raw.every(Number.isFinite))
    throw new TypeError(`Forage ${label} is invalid.`);
  if (integer4 && !raw.every(Number.isSafeInteger)) throw new TypeError(`Forage ${label} must contain safe integers.`);
  return [raw[0], raw[1], raw[2]];
};
var reference2 = (raw) => {
  const value = raw;
  if (!value || typeof value.entityId !== "string" || !value.entityId.trim() || !Number.isSafeInteger(value.epoch) || value.epoch <= 0 || !Number.isSafeInteger(value.lifetime) || value.lifetime <= 0)
    throw new TypeError("Forage observer reference is invalid.");
  return { entityId: value.entityId, epoch: value.epoch, lifetime: value.lifetime };
};
function validateForageConfiguration(raw, items) {
  if (!raw || typeof raw !== "object" || !Number.isSafeInteger(raw.sourceVoxel) || raw.sourceVoxel <= 0 || typeof raw.intervalSeconds !== "number" || !Number.isFinite(raw.intervalSeconds) || raw.intervalSeconds <= 0)
    throw new TypeError("Forage configuration is invalid.");
  const intervalUnits = Math.round(raw.intervalSeconds * 1e9);
  if (!Number.isSafeInteger(intervalUnits) || intervalUnits <= 0 || intervalUnits / 1e9 !== raw.intervalSeconds)
    throw new RangeError("Forage interval exceeds logical schedule precision or range.");
  const drop = items ? items.normalizeStack(raw.drop) : raw.drop;
  if (!drop || typeof drop.itemId !== "string" || !drop.itemId.trim() || !Number.isSafeInteger(drop.count) || drop.count <= 0)
    throw new TypeError("Forage drop is invalid.");
  if (items) {
    const definition2 = items.require(drop.itemId);
    if (definition2.itemType !== "food" || !items.capability(drop.itemId, "consume"))
      throw new TypeError("Forage drop must reference consumable food content.");
  }
  return Object.freeze({
    sourceVoxel: raw.sourceVoxel,
    drop: Object.freeze({ ...drop }),
    intervalSeconds: raw.intervalSeconds
  });
}
function validateForageWorldProjection(raw) {
  const value = raw;
  if (!value || value.version !== 1 || !Array.isArray(value.observers) || !Array.isArray(value.sources))
    throw new TypeError("Forage world projection is invalid.");
  if (value.observers.length > 128 || value.sources.length > FORAGE_MAX_DROPS)
    throw new RangeError("Forage projection exceeds its bounded membership.");
  const observers = value.observers.map((rawObserver) => ({
    reference: reference2(rawObserver?.reference),
    position: position3(rawObserver?.position, "observer position", false)
  }));
  const byId = /* @__PURE__ */ new Map();
  let previous = "";
  for (const observer of observers) {
    if (observer.reference.entityId <= previous || byId.has(observer.reference.entityId))
      throw new TypeError("Forage observers must be unique and sorted.");
    previous = observer.reference.entityId;
    byId.set(observer.reference.entityId, observer);
  }
  const seen = /* @__PURE__ */ new Set();
  const sources = value.sources.map((rawSource) => {
    if (!rawSource || typeof rawSource.observerId !== "string" || !byId.has(rawSource.observerId))
      throw new TypeError("Forage source observer is invalid.");
    const source = position3(rawSource.position, "source position", true);
    const sourceKey = source.join(",");
    if (seen.has(sourceKey)) throw new TypeError("Forage source positions must be unique.");
    seen.add(sourceKey);
    const observer = byId.get(rawSource.observerId);
    const feetY = Math.floor(observer.position[1]);
    if (Math.abs(source[0] - Math.floor(observer.position[0])) > FORAGE_HORIZONTAL_RADIUS || Math.abs(source[2] - Math.floor(observer.position[2])) > FORAGE_HORIZONTAL_RADIUS || source[1] < feetY + FORAGE_VERTICAL_MIN || source[1] > feetY + FORAGE_VERTICAL_MAX)
      throw new TypeError("Forage source lies outside its observer window.");
    return { observerId: rawSource.observerId, position: source };
  });
  return { version: 1, observers, sources };
}
function buildForageCandidate(raw, configuration) {
  const projection = validateForageWorldProjection(raw);
  const config = validateForageConfiguration(configuration);
  const observers = new Map(projection.observers.map((observer) => [observer.reference.entityId, observer]));
  return {
    version: 1,
    kind: "forage-spawn",
    drops: projection.sources.map(({ observerId, position: source }) => ({
      observerReference: { ...observers.get(observerId).reference },
      source: [...source],
      position: [source[0] + 0.5, source[1] - 0.5, source[2] + 0.5],
      stack: cloneItemStack(config.drop)
    }))
  };
}

// packages/stdlib/src/server/gameplay/modules/forage-module.ts
function defineForageModule(input) {
  const supplied = validateForageConfiguration(input);
  return Object.freeze({
    descriptor: {
      id: FORAGE_MODULE_ID,
      version: "1.0.0",
      requires: [{ id: "seedlands:items", version: "1.0.0" }],
      provides: [{ id: FORAGE_CAPABILITY, version: "1.0.0" }],
      resources: [{ id: FORAGE_RESOURCE, operations: ["read", "execute"] }],
      permissions: [{ resource: FORAGE_RESOURCE, operations: ["read", "execute"] }]
    },
    register(api) {
      const items = api.requireCapability("seedlands:items");
      let configuration;
      const resolve = () => configuration ??= validateForageConfiguration(supplied, items);
      api.onDefinitionsReady(resolve);
      api.provideCapability(FORAGE_CAPABILITY, Object.freeze({ resolve }));
      api.registerState({
        id: FORAGE_WORLD_COMPONENT,
        version: "1.0.0",
        resource: FORAGE_RESOURCE,
        validate(value) {
          try {
            validateForageWorldProjection(value);
            return true;
          } catch {
            return false;
          }
        }
      });
      api.registerOperation({
        id: FORAGE_ADVANCE_OPERATION,
        executionKind: "system",
        resource: FORAGE_RESOURCE,
        run(context, input2, state) {
          if (context.kind !== "system" || context.systemId !== FORAGE_SYSTEM || context.target.kind !== "world")
            throw new TypeError("Forage advance requires its registered world system.");
          const configuration2 = resolve();
          forageSeconds(input2, configuration2);
          return buildForageCandidate(state.read(forageWorldAddress()), configuration2);
        }
      });
      api.registerSystem({
        id: FORAGE_SYSTEM,
        operationId: FORAGE_ADVANCE_OPERATION,
        intervalSeconds: supplied.intervalSeconds
      });
    }
  });
}

// packages/stdlib/src/world/voxel-light.ts
function voxelEmission(voxel2, semantics) {
  const composed = semantics?.get(voxel2);
  if (composed) return composed.emission;
  switch (voxel2) {
    case Voxel.Glowstone:
    case Voxel.Lava:
    case Voxel.Fire:
    case Voxel.JackOLantern:
      return 15;
    case Voxel.Lantern:
    case Voxel.Torch:
      return 14;
    case Voxel.LitFurnace:
      return 13;
    case Voxel.LitRedstoneOre:
      return 9;
    default:
      return 0;
  }
}
function voxelLightCost(voxel2, semantics) {
  const composed = semantics?.get(voxel2);
  if (composed) return composed.lightCost;
  if (voxel2 === Voxel.Water || voxel2 === Voxel.Leaves || voxel2 === Voxel.Ice) return 2;
  if (!isSolid(voxel2) || voxel2 === Voxel.Glass || voxel2 === Voxel.Slab || voxel2 === Voxel.WoodStairs || voxel2 === Voxel.CobblestoneStairs || voxel2 === Voxel.Fence || voxel2 === Voxel.Ladder || voxel2 === Voxel.Sign || voxel2 === Voxel.Cake || voxel2 === Voxel.Bed || voxel2 === Voxel.Lantern || voxel2 === Voxel.Torch || voxel2 === Voxel.Spawner)
    return 1;
  return 16;
}

// packages/stdlib/src/world/mesh-render-category.ts
var cutoutMaterials = /* @__PURE__ */ new Set([
  FaceMaterial.Leaves,
  FaceMaterial.Glass,
  FaceMaterial.Sapling,
  FaceMaterial.TallGrass,
  FaceMaterial.Flower,
  FaceMaterial.Mushroom,
  FaceMaterial.SugarCane,
  FaceMaterial.DeadBush,
  FaceMaterial.RedFlower,
  FaceMaterial.RedMushroom,
  FaceMaterial.Fire,
  FaceMaterial.Ladder,
  FaceMaterial.Rail,
  FaceMaterial.PoweredRail,
  FaceMaterial.DetectorRail
]);
var renderCategoryForMaterial = (material) => material === FaceMaterial.Water || material === FaceMaterial.Ice ? "transparent" : cutoutMaterials.has(material) ? "cutout" : material === FaceMaterial.LanternGlow || material === FaceMaterial.Lava || material === FaceMaterial.TorchFlame ? "emissive" : "opaque";

// playbooks/classic/src/structures.ts
var CLASSIC_WOODEN_DOOR_LEGACY_STORAGE_ID = 52;
var CLASSIC_WOODEN_DOOR_FIRST_VARIANT_STORAGE_ID = 89;
var classicWoodenDoorOrientations = Object.freeze(["north", "east", "south", "west"]);
var classicWoodenDoorClosedStateForBearing = (bearing) => {
  if (!classicWoodenDoorOrientations.includes(bearing)) throw new TypeError("Classic wooden door bearing is invalid.");
  return `${bearing}-closed`;
};
var doorVariantStorageId = (orientationIndex, open, role) => CLASSIC_WOODEN_DOOR_FIRST_VARIANT_STORAGE_ID + orientationIndex * 4 + Number(open) * 2 + Number(role === "upper");
var classicWoodenDoorVariants = Object.freeze(
  classicWoodenDoorOrientations.flatMap(
    (orientation, orientationIndex) => [false, true].flatMap((open) => {
      const stateId = `${orientation}-${open ? "open" : "closed"}`;
      return ["lower", "upper"].map(
        (role) => Object.freeze({
          storageId: doorVariantStorageId(orientationIndex, open, role),
          orientation,
          open,
          role,
          stateId
        })
      );
    })
  )
);
var variantFor = (orientation, open, role) => {
  const variant = classicWoodenDoorVariants.find(
    (candidate2) => candidate2.orientation === orientation && candidate2.open === open && candidate2.role === role
  );
  if (!variant) throw new Error(`Classic wooden door variant is missing: ${orientation}/${String(open)}/${role}`);
  return variant.storageId;
};
var classicWoodenDoorDefinition = defineStructureDefinitionV1({
  version: 1,
  id: "seedlands:wooden-door",
  rootRole: "lower",
  initialState: "north-closed",
  parts: [
    { role: "lower", offset: [0, 0, 0] },
    { role: "upper", offset: [0, 1, 0] }
  ],
  states: classicWoodenDoorOrientations.flatMap(
    (orientation) => [false, true].map((open) => ({
      id: `${orientation}-${open ? "open" : "closed"}`,
      variants: {
        lower: variantFor(orientation, open, "lower"),
        upper: variantFor(orientation, open, "upper")
      },
      collision: {
        lower: open ? "passable" : "blocking",
        upper: open ? "passable" : "blocking"
      }
    }))
  ),
  transitions: classicWoodenDoorOrientations.flatMap((orientation) => [
    { id: "toggle", from: `${orientation}-closed`, to: `${orientation}-open` },
    { id: "toggle", from: `${orientation}-open`, to: `${orientation}-closed` }
  ]),
  legacyStates: [
    {
      stateId: "north-closed",
      variants: { lower: CLASSIC_WOODEN_DOOR_LEGACY_STORAGE_ID, upper: CLASSIC_WOODEN_DOOR_LEGACY_STORAGE_ID }
    }
  ],
  support: { role: "lower", offset: [0, -1, 0], requirement: "solid" },
  variantDescriptorKind: "registered-structure",
  placementItemId: "seedlands:wooden-door",
  dropOwnerRole: "lower",
  drop: { itemId: "seedlands:wooden-door", count: 1 }
});
var classicWoodenDoorLegacyCompatibility = Object.freeze({
  storageId: CLASSIC_WOODEN_DOOR_LEGACY_STORAGE_ID,
  definitionId: classicWoodenDoorDefinition.id,
  defaultStateId: "north-closed",
  rootRole: "lower",
  pairedRole: "upper",
  pairedOffset: Object.freeze([0, 1, 0]),
  requiresUniqueVerticalPair: true
});
var classicStructureDefinitions = Object.freeze([classicWoodenDoorDefinition]);
var classicStructureDefinitionModule = defineStructureDefinitionModule({
  moduleId: "seedlands:overworld-structures",
  definitions: classicStructureDefinitions
});

// playbooks/classic/src/blocks.ts
var definitions = Object.freeze({
  [9]: {
    voxel: 9,
    hardnessSeconds: 0.45,
    preferredTool: null,
    drop: { itemId: "glowstone-block", count: 1 },
    replaceable: false
  },
  [10]: {
    voxel: 10,
    hardnessSeconds: 0.45,
    preferredTool: null,
    drop: { itemId: "lantern", count: 1 },
    replaceable: false
  },
  [0]: { voxel: 0, hardnessSeconds: null, preferredTool: null, drop: null, replaceable: true },
  [1]: {
    voxel: 1,
    hardnessSeconds: 0.35,
    preferredTool: "shovel",
    drop: { itemId: "dirt-block", count: 1 },
    replaceable: false
  },
  [2]: {
    voxel: 2,
    hardnessSeconds: 0.35,
    preferredTool: "shovel",
    drop: { itemId: "dirt-block", count: 1 },
    replaceable: false
  },
  [3]: {
    voxel: 3,
    minimumTier: 1,
    hardnessSeconds: 2.4,
    preferredTool: "pickaxe",
    drop: { itemId: "cobblestone", count: 1 },
    replaceable: false
  },
  [4]: {
    voxel: 4,
    hardnessSeconds: 1.2,
    preferredTool: "axe",
    drop: { itemId: "wood-block", count: 1 },
    replaceable: false
  },
  [5]: {
    voxel: 5,
    hardnessSeconds: 0.2,
    preferredTool: "axe",
    drop: { itemId: "berry", count: 1 },
    replaceable: false
  },
  [6]: {
    voxel: 6,
    hardnessSeconds: 0.3,
    preferredTool: "shovel",
    drop: { itemId: "sand-block", count: 1 },
    replaceable: false
  },
  [7]: { voxel: 7, hardnessSeconds: null, preferredTool: null, drop: null, replaceable: false },
  [8]: { voxel: 8, hardnessSeconds: null, preferredTool: null, drop: null, replaceable: true },
  [11]: {
    voxel: 11,
    hardnessSeconds: 1.2,
    preferredTool: "axe",
    drop: { itemId: "workbench", count: 1 },
    replaceable: false
  },
  [12]: {
    voxel: 12,
    hardnessSeconds: 1.2,
    preferredTool: "axe",
    drop: { itemId: "chest", count: 1 },
    replaceable: false
  },
  [13]: {
    voxel: 13,
    hardnessSeconds: 2.4,
    preferredTool: "pickaxe",
    drop: { itemId: "furnace", count: 1 },
    replaceable: false
  },
  [14]: {
    voxel: 14,
    hardnessSeconds: 2.8,
    preferredTool: "pickaxe",
    minimumTier: 1,
    drop: { itemId: "coal", count: 1 },
    replaceable: false
  },
  [17]: {
    voxel: 17,
    hardnessSeconds: 2,
    preferredTool: "pickaxe",
    minimumTier: 1,
    drop: { itemId: "cobblestone", count: 1 },
    replaceable: false
  },
  [19]: {
    voxel: 19,
    hardnessSeconds: 3,
    preferredTool: "pickaxe",
    minimumTier: 3,
    drop: { itemId: "gold-ore", count: 1 },
    replaceable: false
  },
  [20]: {
    voxel: 20,
    hardnessSeconds: 3,
    preferredTool: "pickaxe",
    minimumTier: 3,
    drop: { itemId: "diamond", count: 1 },
    replaceable: false
  },
  [21]: {
    voxel: 21,
    hardnessSeconds: 3,
    preferredTool: "pickaxe",
    minimumTier: 2,
    drop: { itemId: "iron-block", count: 1 },
    replaceable: false
  },
  [22]: {
    voxel: 22,
    hardnessSeconds: 3,
    preferredTool: "pickaxe",
    minimumTier: 3,
    drop: { itemId: "gold-block", count: 1 },
    replaceable: false
  },
  [23]: {
    voxel: 23,
    hardnessSeconds: 3,
    preferredTool: "pickaxe",
    minimumTier: 3,
    drop: { itemId: "diamond-block", count: 1 },
    replaceable: false
  },
  [24]: {
    voxel: 24,
    hardnessSeconds: 1.6,
    preferredTool: "pickaxe",
    minimumTier: 1,
    drop: { itemId: "sandstone", count: 1 },
    replaceable: false
  },
  [25]: {
    voxel: 25,
    hardnessSeconds: 2.2,
    preferredTool: "pickaxe",
    minimumTier: 1,
    drop: { itemId: "stone-bricks", count: 1 },
    replaceable: false
  },
  [26]: {
    voxel: 26,
    hardnessSeconds: 0.6,
    preferredTool: "shovel",
    drop: { itemId: "dirt-block", count: 1 },
    replaceable: false
  },
  [27]: { voxel: 27, hardnessSeconds: null, preferredTool: null, drop: null, replaceable: true },
  [28]: {
    voxel: 28,
    hardnessSeconds: 10,
    preferredTool: "pickaxe",
    minimumTier: 4,
    drop: { itemId: "obsidian", count: 1 },
    replaceable: false
  },
  [29]: { voxel: 29, hardnessSeconds: null, preferredTool: null, drop: null, replaceable: true },
  [30]: {
    voxel: 30,
    hardnessSeconds: 0.01,
    preferredTool: null,
    drop: { itemId: "tnt", count: 1 },
    replaceable: false
  },
  [31]: {
    voxel: 31,
    hardnessSeconds: 0.05,
    preferredTool: null,
    drop: { itemId: "sapling", count: 1 },
    replaceable: true
  },
  [32]: {
    voxel: 32,
    hardnessSeconds: 0.05,
    preferredTool: null,
    drop: { itemId: "wheat-seeds", count: 1 },
    replaceable: true
  },
  [33]: {
    voxel: 33,
    hardnessSeconds: 0.05,
    preferredTool: null,
    drop: { itemId: "flower", count: 1 },
    replaceable: true
  },
  [34]: {
    voxel: 34,
    hardnessSeconds: 0.05,
    preferredTool: null,
    drop: { itemId: "mushroom", count: 1 },
    replaceable: true
  },
  [35]: {
    voxel: 35,
    hardnessSeconds: 0.1,
    preferredTool: null,
    drop: { itemId: "sugar-cane", count: 1 },
    replaceable: true
  },
  [36]: {
    voxel: 36,
    hardnessSeconds: 0.4,
    preferredTool: null,
    drop: { itemId: "cactus", count: 1 },
    replaceable: false
  },
  [37]: { voxel: 37, hardnessSeconds: null, preferredTool: null, drop: null, replaceable: false },
  [38]: { voxel: 38, hardnessSeconds: null, preferredTool: null, drop: null, replaceable: false },
  [39]: {
    voxel: 39,
    hardnessSeconds: 0.7,
    preferredTool: "pickaxe",
    drop: { itemId: "rail", count: 1 },
    replaceable: true
  },
  [40]: {
    voxel: 40,
    hardnessSeconds: 0.7,
    preferredTool: "pickaxe",
    drop: { itemId: "powered-rail", count: 1 },
    replaceable: true
  },
  [41]: {
    voxel: 41,
    hardnessSeconds: 0.7,
    preferredTool: "pickaxe",
    drop: { itemId: "detector-rail", count: 1 },
    replaceable: true
  },
  [42]: { voxel: 42, hardnessSeconds: null, preferredTool: null, drop: null, replaceable: false },
  [43]: {
    voxel: 43,
    hardnessSeconds: 0.6,
    preferredTool: "shovel",
    drop: { itemId: "gravel", count: 1 },
    replaceable: false
  },
  [44]: {
    voxel: 44,
    hardnessSeconds: 3,
    preferredTool: "pickaxe",
    minimumTier: 2,
    drop: { itemId: "blue-dye", count: 4 },
    replaceable: false
  },
  [45]: {
    voxel: 45,
    hardnessSeconds: 0.6,
    preferredTool: "shovel",
    drop: { itemId: "clay", count: 4 },
    replaceable: false
  },
  [46]: { voxel: 46, hardnessSeconds: 0.5, preferredTool: "pickaxe", drop: null, replaceable: false },
  [47]: {
    voxel: 47,
    hardnessSeconds: 0.3,
    preferredTool: "shovel",
    drop: { itemId: "snowball", count: 4 },
    replaceable: false
  },
  [48]: {
    voxel: 48,
    hardnessSeconds: 3,
    preferredTool: "pickaxe",
    minimumTier: 2,
    drop: { itemId: "lapis-block", count: 1 },
    replaceable: false
  },
  ...Object.fromEntries(
    [
      [49, "slab"],
      [50, "wood-stairs"],
      [51, "cobblestone-stairs"],
      [52, "wooden-door"],
      [53, "ladder"],
      [54, "torch"],
      [55, "bed"],
      [56, "sign"],
      [57, "fence"],
      [58, "cake"]
    ].map(([voxel2, itemId]) => [
      voxel2,
      { voxel: voxel2, hardnessSeconds: 0.7, preferredTool: null, drop: { itemId, count: 1 }, replaceable: false }
    ])
  ),
  ...Object.fromEntries(
    [
      [59, "dead-bush", 0.05, null],
      [60, "wool", 0.8, null],
      [61, "red-flower", 0.05, null],
      [62, "red-mushroom", 0.05, null],
      [63, "bricks", 2, "pickaxe"],
      [64, "bookshelf", 1.5, "axe"],
      [65, "mossy-cobblestone", 2, "pickaxe"],
      [66, "note-block", 1.2, "axe"],
      [67, "jukebox", 2, "axe"],
      [68, "pumpkin", 1, "axe"],
      [69, "jack-o-lantern", 1, "axe"],
      [70, "trapdoor", 1, "axe"],
      [71, "furnace", 2.4, "pickaxe"],
      [72, "redstone-dust", 3, "pickaxe"],
      [73, "redstone-dust", 3, "pickaxe"]
    ].map(([voxel2, itemId, hardnessSeconds, preferredTool]) => [
      voxel2,
      {
        voxel: voxel2,
        hardnessSeconds,
        preferredTool,
        drop: { itemId, count: voxel2 >= 72 ? 4 : 1 },
        replaceable: voxel2 === 59 || voxel2 === 61 || voxel2 === 62
      }
    ])
  ),
  ...Object.fromEntries(
    woolVoxelColors.slice(1).map(([id2, , voxel2]) => [
      voxel2,
      {
        voxel: voxel2,
        hardnessSeconds: 0.8,
        preferredTool: null,
        drop: { itemId: `${id2}-wool`, count: 1 },
        replaceable: false
      }
    ])
  ),
  [18]: { voxel: 18, hardnessSeconds: 0.3, preferredTool: null, drop: null, replaceable: false },
  [16]: {
    voxel: 16,
    hardnessSeconds: 1.2,
    preferredTool: "axe",
    drop: { itemId: "plank", count: 1 },
    replaceable: false
  },
  [15]: {
    voxel: 15,
    hardnessSeconds: 3.2,
    preferredTool: "pickaxe",
    minimumTier: 2,
    drop: { itemId: "raw-iron", count: 1 },
    replaceable: false
  }
});
var overworldBlocks = Object.freeze(
  [
    ...Object.values(definitions),
    ...classicWoodenDoorVariants.map(({ storageId }) => ({
      voxel: storageId,
      hardnessSeconds: 0.7,
      preferredTool: null,
      drop: null,
      replaceable: false
    }))
  ].map(
    (definition2) => Object.freeze({ ...definition2, drop: definition2.drop ? Object.freeze({ ...definition2.drop }) : null })
  )
);
var classicVoxelName = new Map(
  Object.entries(Voxel).map(([name, storageId]) => [storageId, name])
);
var materialForFace = (storageId, axis, positive) => faceMaterialFor(storageId, axis, positive) ?? FaceMaterial.Stone;
var overworldVoxelSemantics = Object.freeze([
  ...Array.from({ length: 89 }, (_, storageId) => {
    const name = classicVoxelName.get(storageId);
    if (!name) throw new Error(`Classic voxel ID is missing: ${storageId}`);
    return Object.freeze({
      id: `seedlands:classic/${name.replace(/[A-Z]/g, (letter) => `-${letter.toLowerCase()}`).replace(/^-/, "")}`,
      storageId,
      solid: isSolid(storageId),
      targetable: isTargetable(storageId),
      renderable: isRenderable(storageId),
      meshKind: hasVoxelModelGeometry(storageId) ? "model" : storageId === Voxel.Water ? "water" : storageId === Voxel.Glass ? "glass" : storageId === Voxel.Ice ? "ice" : "cube",
      emission: voxelEmission(storageId),
      lightCost: voxelLightCost(storageId),
      faceMaterials: [
        materialForFace(storageId, 0, false),
        materialForFace(storageId, 0, true),
        materialForFace(storageId, 1, false),
        materialForFace(storageId, 1, true),
        materialForFace(storageId, 2, false),
        materialForFace(storageId, 2, true)
      ],
      materialCategories: Object.freeze(
        [
          .../* @__PURE__ */ new Set([
            materialForFace(storageId, 0, false),
            materialForFace(storageId, 0, true),
            materialForFace(storageId, 1, false),
            materialForFace(storageId, 1, true),
            materialForFace(storageId, 2, false),
            materialForFace(storageId, 2, true)
          ])
        ].map((material) => [material, renderCategoryForMaterial(material)])
      )
    });
  }),
  ...classicWoodenDoorVariants.map(
    ({ storageId, orientation, open, role }) => Object.freeze({
      id: `seedlands:classic/wooden-door/${orientation}/${open ? "open" : "closed"}/${role}`,
      storageId,
      solid: !open,
      targetable: true,
      renderable: true,
      // Public V1 does not yet admit Pack model geometry above the legacy 0-88 palette.
      meshKind: "cube",
      emission: 0,
      lightCost: 1,
      faceMaterials: Object.freeze([
        FaceMaterial.WoodenDoor,
        FaceMaterial.WoodenDoor,
        FaceMaterial.WoodenDoor,
        FaceMaterial.WoodenDoor,
        FaceMaterial.WoodenDoor,
        FaceMaterial.WoodenDoor
      ]),
      materialCategories: Object.freeze([
        Object.freeze([FaceMaterial.WoodenDoor, renderCategoryForMaterial(FaceMaterial.WoodenDoor)])
      ])
    })
  )
]);

// playbooks/classic/src/portable-items.ts
var portableItems = [
  { id: "paper", name: "\u7EB8", itemType: "resource", stackLimit: 64, capabilities: [] },
  { id: "redstone-dust", name: "\u7EA2\u77F3\u7C89", itemType: "resource", stackLimit: 64, capabilities: [] },
  { id: "compass", name: "\u6307\u5357\u9488", itemType: "resource", stackLimit: 1, capabilities: [] },
  { id: "clock", name: "\u65F6\u949F", itemType: "resource", stackLimit: 1, capabilities: [] },
  { id: "map", name: "\u5730\u56FE", itemType: "resource", stackLimit: 1, capabilities: [] },
  { id: "flint-and-steel", name: "\u6253\u706B\u77F3", itemType: "tool", stackLimit: 1, durability: { max: 65 }, capabilities: [] },
  {
    id: "mushroom-stew",
    name: "\u8611\u83C7\u7172",
    itemType: "food",
    stackLimit: 1,
    capabilities: [{ type: "consume", healthRestore: 5, hungerRestore: 5 }]
  },
  { id: "painting", name: "\u753B", itemType: "resource", stackLimit: 64, capabilities: [] },
  {
    id: "golden-apple",
    name: "\u91D1\u82F9\u679C",
    itemType: "food",
    stackLimit: 1,
    capabilities: [{ type: "consume", healthRestore: 10, hungerRestore: 10 }]
  },
  { id: "sign", name: "\u544A\u793A\u724C", itemType: "block", stackLimit: 16, capabilities: [{ type: "place", voxel: 56 }] },
  { id: "wooden-door", name: "\u6728\u95E8", itemType: "block", stackLimit: 64, capabilities: [] },
  { id: "snowball", name: "\u96EA\u7403", itemType: "resource", stackLimit: 16, capabilities: [] },
  { id: "brick", name: "\u7EA2\u7816", itemType: "resource", stackLimit: 64, capabilities: [] },
  { id: "clay", name: "\u9ECF\u571F", itemType: "resource", stackLimit: 64, capabilities: [] },
  { id: "book", name: "\u4E66", itemType: "resource", stackLimit: 64, capabilities: [] },
  { id: "sugar", name: "\u7CD6", itemType: "resource", stackLimit: 64, capabilities: [] },
  {
    id: "cake",
    name: "\u86CB\u7CD5",
    itemType: "block",
    stackLimit: 1,
    capabilities: [{ type: "place", voxel: 58 }]
  },
  {
    id: "cookie",
    name: "\u66F2\u5947",
    itemType: "food",
    stackLimit: 64,
    capabilities: [{ type: "consume", healthRestore: 1, hungerRestore: 1 }]
  },
  { id: "cocoa-beans", name: "\u53EF\u53EF\u8C46", itemType: "resource", stackLimit: 64, capabilities: [] },
  { id: "record-13", name: "\u5531\u7247 13", itemType: "resource", stackLimit: 1, capabilities: [] },
  { id: "record-cat", name: "\u5531\u7247 Cat", itemType: "resource", stackLimit: 1, capabilities: [] }
];

// playbooks/classic/src/remaining-block-items.ts
var remainingBlockItems = [
  ["dead-bush", "\u67AF\u704C\u6728", 59],
  ["wool-block", "\u7F8A\u6BDB\u5757", 60],
  ["red-flower", "\u7EA2\u82B1", 61],
  ["red-mushroom", "\u7EA2\u8611\u83C7", 62],
  ["bricks", "\u7816\u5757", 63],
  ["bookshelf", "\u4E66\u67B6", 64],
  ["mossy-cobblestone", "\u82D4\u77F3", 65],
  ["note-block", "\u97F3\u7B26\u76D2", 66],
  ["jukebox", "\u5531\u7247\u673A", 67],
  ["pumpkin", "\u5357\u74DC", 68],
  ["jack-o-lantern", "\u5357\u74DC\u706F", 69],
  ["trapdoor", "\u6D3B\u677F\u95E8", 70],
  ["lit-furnace", "\u71C3\u70E7\u7194\u7089", 71],
  ["redstone-ore", "\u7EA2\u77F3\u77FF", 72],
  ["lit-redstone-ore", "\u53D1\u5149\u7EA2\u77F3\u77FF", 73]
].map(([id2, name, voxel2]) => ({
  id: id2,
  name,
  itemType: "block",
  stackLimit: 64,
  capabilities: [{ type: "place", voxel: voxel2 }]
}));

// playbooks/classic/src/items.ts
var overworldItems = [
  ...portableItems,
  ...remainingBlockItems,
  ...recipeClosureItems,
  ...woolColors.map(([id2, name]) => ({
    id: `${id2}-dye`,
    name: `${name}\u67D3\u6599`,
    itemType: "resource",
    stackLimit: 64,
    capabilities: []
  })),
  {
    id: "glowstone-block",
    name: "\u8F89\u5149\u77F3",
    itemType: "block",
    stackLimit: 64,
    capabilities: [{ type: "place", voxel: 9 }]
  },
  {
    id: "lantern",
    name: "\u706F\u7B3C",
    itemType: "block",
    stackLimit: 64,
    capabilities: [{ type: "place", voxel: 10 }]
  },
  {
    id: "dirt-block",
    name: "\u6CE5\u571F\u5757",
    itemType: "block",
    stackLimit: 64,
    capabilities: [{ type: "place", voxel: 2 }]
  },
  {
    id: "stone-block",
    name: "\u77F3\u5757",
    itemType: "block",
    stackLimit: 64,
    capabilities: [{ type: "place", voxel: 3 }]
  },
  {
    id: "wood-block",
    name: "\u539F\u6728",
    itemType: "block",
    stackLimit: 64,
    capabilities: [{ type: "place", voxel: 4 }]
  },
  {
    id: "sand-block",
    name: "\u6C99\u5757",
    itemType: "block",
    stackLimit: 64,
    capabilities: [{ type: "place", voxel: 6 }]
  },
  {
    id: "berry",
    name: "\u6D46\u679C",
    itemType: "food",
    stackLimit: 64,
    capabilities: [{ type: "consume", healthRestore: 4, hungerRestore: 4 }]
  },
  {
    id: "apple",
    name: "\u82F9\u679C",
    itemType: "food",
    stackLimit: 64,
    capabilities: [{ type: "consume", healthRestore: 4, hungerRestore: 4 }]
  },
  {
    id: "bread",
    name: "\u9762\u5305",
    itemType: "food",
    stackLimit: 64,
    capabilities: [{ type: "consume", healthRestore: 5, hungerRestore: 5 }]
  },
  {
    id: "raw-porkchop",
    name: "\u751F\u732A\u6392",
    itemType: "food",
    stackLimit: 64,
    capabilities: [{ type: "consume", healthRestore: 3, hungerRestore: 3 }]
  },
  {
    id: "cooked-porkchop",
    name: "\u719F\u732A\u6392",
    itemType: "food",
    stackLimit: 64,
    capabilities: [{ type: "consume", healthRestore: 8, hungerRestore: 8 }]
  },
  {
    id: "raw-fish",
    name: "\u751F\u9C7C",
    itemType: "food",
    stackLimit: 64,
    capabilities: [{ type: "consume", healthRestore: 2, hungerRestore: 2 }]
  },
  {
    id: "cooked-fish",
    name: "\u719F\u9C7C",
    itemType: "food",
    stackLimit: 64,
    capabilities: [{ type: "consume", healthRestore: 5, hungerRestore: 5 }]
  },
  { id: "wheat", name: "\u5C0F\u9EA6", itemType: "resource", stackLimit: 64, capabilities: [] },
  { id: "wheat-seeds", name: "\u5C0F\u9EA6\u79CD\u5B50", itemType: "resource", stackLimit: 64, capabilities: [] },
  {
    id: "plank",
    name: "\u6728\u677F",
    itemType: "block",
    stackLimit: 64,
    capabilities: [{ type: "place", voxel: 16 }]
  },
  { id: "cobblestone", name: "\u5706\u77F3", itemType: "block", stackLimit: 64, capabilities: [{ type: "place", voxel: 17 }] },
  { id: "glass", name: "\u73BB\u7483", itemType: "block", stackLimit: 64, capabilities: [{ type: "place", voxel: 18 }] },
  { id: "gold-ore", name: "\u91D1\u77FF\u77F3", itemType: "block", stackLimit: 64, capabilities: [{ type: "place", voxel: 19 }] },
  {
    id: "diamond-ore",
    name: "\u94BB\u77F3\u77FF\u77F3",
    itemType: "block",
    stackLimit: 64,
    capabilities: [{ type: "place", voxel: 20 }]
  },
  { id: "iron-block", name: "\u94C1\u5757", itemType: "block", stackLimit: 64, capabilities: [{ type: "place", voxel: 21 }] },
  { id: "gold-block", name: "\u91D1\u5757", itemType: "block", stackLimit: 64, capabilities: [{ type: "place", voxel: 22 }] },
  {
    id: "diamond-block",
    name: "\u94BB\u77F3\u5757",
    itemType: "block",
    stackLimit: 64,
    capabilities: [{ type: "place", voxel: 23 }]
  },
  { id: "gold-ingot", name: "\u91D1\u952D", itemType: "resource", stackLimit: 64, capabilities: [] },
  { id: "diamond", name: "\u94BB\u77F3", itemType: "resource", stackLimit: 64, capabilities: [] },
  { id: "sandstone", name: "\u7802\u5CA9", itemType: "block", stackLimit: 64, capabilities: [{ type: "place", voxel: 24 }] },
  {
    id: "stone-bricks",
    name: "\u77F3\u7816",
    itemType: "block",
    stackLimit: 64,
    capabilities: [{ type: "place", voxel: 25 }]
  },
  {
    id: "gold-pickaxe",
    name: "\u91D1\u9550",
    itemType: "tool",
    stackLimit: 1,
    durability: { max: 32 },
    capabilities: [{ type: "mine", tool: "pickaxe", tier: 1, multiplier: 12 }]
  },
  {
    id: "diamond-pickaxe",
    name: "\u94BB\u77F3\u9550",
    itemType: "tool",
    stackLimit: 1,
    durability: { max: 1561 },
    capabilities: [{ type: "mine", tool: "pickaxe", tier: 4, multiplier: 8 }]
  },
  {
    id: "stone-axe",
    name: "\u77F3\u65A7",
    itemType: "tool",
    stackLimit: 1,
    durability: { max: 132 },
    capabilities: [{ type: "mine", tool: "axe", tier: 2, multiplier: 4 }]
  },
  {
    id: "iron-axe",
    name: "\u94C1\u65A7",
    itemType: "tool",
    stackLimit: 1,
    durability: { max: 250 },
    capabilities: [{ type: "mine", tool: "axe", tier: 3, multiplier: 6 }]
  },
  {
    id: "gold-axe",
    name: "\u91D1\u65A7",
    itemType: "tool",
    stackLimit: 1,
    durability: { max: 32 },
    capabilities: [{ type: "mine", tool: "axe", tier: 1, multiplier: 12 }]
  },
  {
    id: "diamond-axe",
    name: "\u94BB\u77F3\u65A7",
    itemType: "tool",
    stackLimit: 1,
    durability: { max: 1561 },
    capabilities: [{ type: "mine", tool: "axe", tier: 4, multiplier: 8 }]
  },
  {
    id: "stone-sword",
    name: "\u77F3\u5251",
    itemType: "tool",
    stackLimit: 1,
    durability: { max: 132 },
    capabilities: [{ type: "melee", definitionId: "stone-sword" }]
  },
  {
    id: "iron-sword",
    name: "\u94C1\u5251",
    itemType: "tool",
    stackLimit: 1,
    durability: { max: 250 },
    capabilities: [{ type: "melee", definitionId: "iron-sword" }]
  },
  {
    id: "gold-sword",
    name: "\u91D1\u5251",
    itemType: "tool",
    stackLimit: 1,
    durability: { max: 32 },
    capabilities: [{ type: "melee", definitionId: "gold-sword" }]
  },
  {
    id: "diamond-sword",
    name: "\u94BB\u77F3\u5251",
    itemType: "tool",
    stackLimit: 1,
    durability: { max: 1561 },
    capabilities: [{ type: "melee", definitionId: "diamond-sword" }]
  },
  {
    id: "wood-shovel",
    name: "\u6728\u9539",
    itemType: "tool",
    stackLimit: 1,
    durability: { max: 60 },
    capabilities: [{ type: "mine", tool: "shovel", tier: 1, multiplier: 2 }]
  },
  {
    id: "stone-shovel",
    name: "\u77F3\u9539",
    itemType: "tool",
    stackLimit: 1,
    durability: { max: 132 },
    capabilities: [{ type: "mine", tool: "shovel", tier: 2, multiplier: 4 }]
  },
  {
    id: "iron-shovel",
    name: "\u94C1\u9539",
    itemType: "tool",
    stackLimit: 1,
    durability: { max: 250 },
    capabilities: [{ type: "mine", tool: "shovel", tier: 3, multiplier: 6 }]
  },
  {
    id: "gold-shovel",
    name: "\u91D1\u9539",
    itemType: "tool",
    stackLimit: 1,
    durability: { max: 32 },
    capabilities: [{ type: "mine", tool: "shovel", tier: 1, multiplier: 12 }]
  },
  {
    id: "diamond-shovel",
    name: "\u94BB\u77F3\u9539",
    itemType: "tool",
    stackLimit: 1,
    durability: { max: 1561 },
    capabilities: [{ type: "mine", tool: "shovel", tier: 4, multiplier: 8 }]
  },
  {
    id: "wood-hoe",
    name: "\u6728\u9504",
    itemType: "tool",
    stackLimit: 1,
    durability: { max: 60 },
    capabilities: [{ type: "till" }]
  },
  {
    id: "stone-hoe",
    name: "\u77F3\u9504",
    itemType: "tool",
    stackLimit: 1,
    durability: { max: 132 },
    capabilities: [{ type: "till" }]
  },
  {
    id: "iron-hoe",
    name: "\u94C1\u9504",
    itemType: "tool",
    stackLimit: 1,
    durability: { max: 250 },
    capabilities: [{ type: "till" }]
  },
  {
    id: "gold-hoe",
    name: "\u91D1\u9504",
    itemType: "tool",
    stackLimit: 1,
    durability: { max: 32 },
    capabilities: [{ type: "till" }]
  },
  {
    id: "diamond-hoe",
    name: "\u94BB\u77F3\u9504",
    itemType: "tool",
    stackLimit: 1,
    durability: { max: 1561 },
    capabilities: [{ type: "till" }]
  },
  { id: "charcoal", name: "\u6728\u70AD", itemType: "resource", stackLimit: 64, capabilities: [] },
  { id: "stick", name: "\u6728\u68CD", itemType: "resource", stackLimit: 64, capabilities: [] },
  {
    id: "wood-axe",
    name: "\u6728\u65A7",
    itemType: "tool",
    stackLimit: 1,
    durability: { max: 60 },
    capabilities: [{ type: "mine", tool: "axe", tier: 1, multiplier: 3 }]
  },
  {
    id: "stone-pickaxe",
    name: "\u77F3\u9550",
    itemType: "tool",
    stackLimit: 1,
    durability: { max: 132 },
    capabilities: [{ type: "mine", tool: "pickaxe", tier: 2, multiplier: 4 }]
  },
  {
    id: "wood-sword",
    name: "\u6728\u5251",
    itemType: "tool",
    stackLimit: 1,
    capabilities: [{ type: "melee", definitionId: "wood-sword" }]
  },
  { id: "workbench", name: "\u5DE5\u4F5C\u53F0", itemType: "block", stackLimit: 64, capabilities: [{ type: "place", voxel: 11 }] },
  { id: "chest", name: "\u7BB1\u5B50", itemType: "block", stackLimit: 64, capabilities: [{ type: "place", voxel: 12 }] },
  { id: "furnace", name: "\u7089\u4F53", itemType: "block", stackLimit: 64, capabilities: [{ type: "place", voxel: 13 }] },
  { id: "coal", name: "\u7164", itemType: "resource", stackLimit: 64, capabilities: [] },
  { id: "raw-iron", name: "\u94C1\u77FF\u77F3", itemType: "block", stackLimit: 64, capabilities: [{ type: "place", voxel: 15 }] },
  { id: "iron-ingot", name: "\u94C1\u952D", itemType: "resource", stackLimit: 64, capabilities: [] },
  {
    id: "wood-pickaxe",
    name: "\u6728\u9550",
    itemType: "tool",
    stackLimit: 1,
    durability: { max: 60 },
    capabilities: [{ type: "mine", tool: "pickaxe", tier: 1, multiplier: 2 }]
  },
  {
    id: "iron-pickaxe",
    name: "\u94C1\u9550",
    itemType: "tool",
    stackLimit: 1,
    durability: { max: 250 },
    capabilities: [{ type: "mine", tool: "pickaxe", tier: 3, multiplier: 6 }]
  },
  { id: "leather", name: "\u76AE\u9769", itemType: "resource", stackLimit: 64, capabilities: [] },
  { id: "bowl", name: "\u7897", itemType: "resource", stackLimit: 64, capabilities: [] },
  {
    id: "bucket",
    name: "\u6876",
    itemType: "resource",
    stackLimit: 16,
    capabilities: [{ type: "fluid-container", fluid: "empty" }]
  },
  {
    id: "water-bucket",
    name: "\u6C34\u6876",
    itemType: "resource",
    stackLimit: 1,
    capabilities: [{ type: "fluid-container", fluid: "water" }]
  },
  { id: "shears", name: "\u526A\u5200", itemType: "tool", stackLimit: 1, durability: { max: 238 }, capabilities: [] },
  { id: "minecart", name: "\u77FF\u8F66", itemType: "resource", stackLimit: 1, capabilities: [] },
  { id: "chest-minecart", name: "\u8FD0\u8F93\u77FF\u8F66", itemType: "resource", stackLimit: 1, capabilities: [] },
  { id: "furnace-minecart", name: "\u52A8\u529B\u77FF\u8F66", itemType: "resource", stackLimit: 1, capabilities: [] },
  { id: "boat", name: "\u8239", itemType: "resource", stackLimit: 1, capabilities: [] },
  { id: "string", name: "\u7EBF", itemType: "resource", stackLimit: 64, capabilities: [] },
  { id: "feather", name: "\u7FBD\u6BDB", itemType: "resource", stackLimit: 64, capabilities: [] },
  { id: "flint", name: "\u71E7\u77F3", itemType: "resource", stackLimit: 64, capabilities: [] },
  {
    id: "wool",
    name: "\u7F8A\u6BDB",
    itemType: "block",
    stackLimit: 64,
    capabilities: [{ type: "place", voxel: 60 }]
  },
  { id: "ink-sac", name: "\u58A8\u56CA", itemType: "resource", stackLimit: 64, capabilities: [] },
  { id: "rotten-flesh", name: "\u8150\u8089", itemType: "resource", stackLimit: 64, capabilities: [] },
  { id: "bone", name: "\u9AA8\u5934", itemType: "resource", stackLimit: 64, capabilities: [] },
  { id: "gunpowder", name: "\u706B\u836F", itemType: "resource", stackLimit: 64, capabilities: [] },
  { id: "slimeball", name: "\u9ECF\u6DB2\u7403", itemType: "resource", stackLimit: 64, capabilities: [] },
  { id: "bed", name: "\u5E8A", itemType: "block", stackLimit: 1, capabilities: [{ type: "place", voxel: 55 }] },
  { id: "saddle", name: "\u978D", itemType: "resource", stackLimit: 1, capabilities: [] },
  { id: "milk-bucket", name: "\u5976\u6876", itemType: "food", stackLimit: 1, capabilities: [] },
  { id: "egg", name: "\u9E21\u86CB", itemType: "resource", stackLimit: 16, capabilities: [] },
  { id: "fishing-rod", name: "\u9493\u9C7C\u7AFF", itemType: "tool", stackLimit: 1, durability: { max: 65 }, capabilities: [] },
  { id: "rail", name: "\u94C1\u8F68", itemType: "block", stackLimit: 64, capabilities: [{ type: "place", voxel: 39 }] },
  {
    id: "powered-rail",
    name: "\u52A8\u529B\u94C1\u8F68",
    itemType: "block",
    stackLimit: 64,
    capabilities: [{ type: "place", voxel: 40 }]
  },
  {
    id: "detector-rail",
    name: "\u63A2\u6D4B\u94C1\u8F68",
    itemType: "block",
    stackLimit: 64,
    capabilities: [{ type: "place", voxel: 41 }]
  },
  {
    id: "lava-bucket",
    name: "\u7194\u5CA9\u6876",
    itemType: "resource",
    stackLimit: 1,
    capabilities: [{ type: "fluid-container", fluid: "lava" }]
  },
  { id: "obsidian", name: "\u9ED1\u66DC\u77F3", itemType: "block", stackLimit: 64, capabilities: [{ type: "place", voxel: 28 }] },
  { id: "tnt", name: "TNT", itemType: "block", stackLimit: 64, capabilities: [{ type: "place", voxel: 30 }] },
  { id: "sapling", name: "\u6811\u82D7", itemType: "block", stackLimit: 64, capabilities: [{ type: "place", voxel: 31 }] },
  { id: "flower", name: "\u82B1", itemType: "block", stackLimit: 64, capabilities: [{ type: "place", voxel: 33 }] },
  { id: "mushroom", name: "\u8611\u83C7", itemType: "block", stackLimit: 64, capabilities: [{ type: "place", voxel: 34 }] },
  { id: "sugar-cane", name: "\u7518\u8517", itemType: "block", stackLimit: 64, capabilities: [{ type: "place", voxel: 35 }] },
  { id: "cactus", name: "\u4ED9\u4EBA\u638C", itemType: "block", stackLimit: 64, capabilities: [{ type: "place", voxel: 36 }] },
  { id: "gravel", name: "\u7802\u783E", itemType: "block", stackLimit: 64, capabilities: [{ type: "place", voxel: 43 }] },
  {
    id: "lapis-ore",
    name: "\u9752\u91D1\u77F3\u77FF\u77F3",
    itemType: "block",
    stackLimit: 64,
    capabilities: [{ type: "place", voxel: 44 }]
  },
  { id: "clay-block", name: "\u9ECF\u571F\u5757", itemType: "block", stackLimit: 64, capabilities: [{ type: "place", voxel: 45 }] },
  { id: "ice", name: "\u51B0", itemType: "block", stackLimit: 64, capabilities: [{ type: "place", voxel: 46 }] },
  { id: "snow-block", name: "\u96EA\u5757", itemType: "block", stackLimit: 64, capabilities: [{ type: "place", voxel: 47 }] },
  {
    id: "lapis-block",
    name: "\u9752\u91D1\u77F3\u5757",
    itemType: "block",
    stackLimit: 64,
    capabilities: [{ type: "place", voxel: 48 }]
  },
  { id: "arrow", name: "\u7BAD", itemType: "resource", stackLimit: 64, capabilities: [] },
  {
    id: "bow",
    name: "\u5F13",
    itemType: "tool",
    stackLimit: 1,
    durability: { max: 384 },
    capabilities: [{ type: "ranged", ammunitionItemId: "arrow", damage: 4, speed: 16, lifetimeSeconds: 5 }]
  },
  ...[
    ["leather", "\u76AE\u9769", "leather", 55, { helmet: 1, chestplate: 3, leggings: 2, boots: 1 }],
    ["iron", "\u94C1", "iron-ingot", 165, { helmet: 2, chestplate: 6, leggings: 5, boots: 2 }],
    ["gold", "\u91D1", "gold-ingot", 77, { helmet: 2, chestplate: 5, leggings: 3, boots: 1 }],
    ["diamond", "\u94BB\u77F3", "diamond", 363, { helmet: 3, chestplate: 8, leggings: 6, boots: 3 }]
  ].flatMap(
    ([tier, tierName, , durability, points]) => [
      ["helmet", "\u5934\u76D4"],
      ["chestplate", "\u80F8\u7532"],
      ["leggings", "\u62A4\u817F"],
      ["boots", "\u9774\u5B50"]
    ].map(([slot, slotName]) => ({
      id: `${tier}-${slot}`,
      name: `${tierName}${slotName}`,
      itemType: "armor",
      stackLimit: 1,
      durability: { max: durability },
      capabilities: [{ type: "armor", slot, points: points[slot] }]
    }))
  )
];

// playbooks/classic/src/combat.ts
var step = (damage, windupSeconds, hitSeconds, recoverySeconds) => Object.freeze({ damage, windupSeconds, hitSeconds, recoverySeconds });
var overworldMeleeDefinitions = [
  { id: "unarmed", range: 3, steps: [step(4, 0, 0.01, 0.49)] },
  {
    id: "wood-sword",
    range: 3,
    steps: [step(5, 0.18, 0.08, 0.24), step(7, 0.14, 0.08, 0.38)]
  },
  {
    id: "stone-sword",
    range: 3,
    steps: [step(6, 0.18, 0.08, 0.24), step(8, 0.14, 0.08, 0.38)]
  },
  {
    id: "iron-sword",
    range: 3,
    steps: [step(7, 0.18, 0.08, 0.24), step(9, 0.14, 0.08, 0.38)]
  },
  {
    id: "gold-sword",
    range: 3,
    steps: [step(5, 0.16, 0.08, 0.2), step(7, 0.12, 0.08, 0.32)]
  },
  {
    id: "diamond-sword",
    range: 3,
    steps: [step(8, 0.18, 0.08, 0.24), step(10, 0.14, 0.08, 0.38)]
  },
  { id: "zombie-claw", range: 1.5, steps: [step(3, 0.3, 0.1, 0.7)] },
  { id: "spider-bite", range: 1.6, steps: [step(2, 0.2, 0.1, 0.5)] },
  { id: "creeper-bump", range: 1.4, steps: [step(1, 0.4, 0.1, 0.8)] },
  { id: "slime-bump", range: 1.2, steps: [step(2, 0.25, 0.1, 0.65)] }
];

// playbooks/classic/src/actors.ts
var overworldActorProfiles = [
  {
    archetype: "chicken",
    entityType: "creature",
    maxHealth: 4,
    navigation: { speed: 1.8, perceptionRange: 8 },
    disposition: "passive",
    spawnWeight: 10,
    spawnBiomes: ["plains", "forest"],
    deathDrop: { itemId: "feather", count: 1 }
  },
  {
    archetype: "cow",
    entityType: "creature",
    maxHealth: 10,
    navigation: { speed: 2, perceptionRange: 10 },
    disposition: "passive",
    spawnWeight: 8,
    spawnBiomes: ["plains", "forest"],
    deathDrop: { itemId: "leather", count: 1 }
  },
  {
    archetype: "pig",
    entityType: "creature",
    maxHealth: 10,
    navigation: { speed: 2, perceptionRange: 10 },
    disposition: "passive",
    spawnWeight: 10,
    spawnBiomes: ["plains", "forest", "wet"],
    deathDrop: { itemId: "raw-porkchop", count: 1 }
  },
  {
    archetype: "pig-zombie",
    entityType: "creature",
    maxHealth: 20,
    navigation: { speed: 2.3, perceptionRange: 12 },
    disposition: "neutral",
    meleeDefinitionId: "zombie-claw",
    deathDrop: { itemId: "gold-ingot", count: 1 }
  },
  {
    archetype: "sheep",
    entityType: "creature",
    maxHealth: 8,
    navigation: { speed: 2, perceptionRange: 10 },
    disposition: "passive",
    spawnWeight: 12,
    spawnBiomes: ["plains", "forest", "cold"],
    deathDrop: { itemId: "wool", count: 1 }
  },
  {
    archetype: "squid",
    entityType: "creature",
    maxHealth: 10,
    navigation: { speed: 1.4, perceptionRange: 8 },
    disposition: "passive",
    spawnWeight: 6,
    spawnBiomes: ["wet"],
    deathDrop: { itemId: "ink-sac", count: 1 }
  },
  {
    archetype: "wolf",
    entityType: "creature",
    maxHealth: 8,
    navigation: { speed: 2.4, perceptionRange: 12 },
    disposition: "neutral",
    spawnWeight: 4,
    spawnBiomes: ["forest", "cold"]
  },
  {
    archetype: "zombie",
    entityType: "creature",
    maxHealth: 20,
    navigation: { speed: 2.3, perceptionRange: 12 },
    disposition: "hostile",
    spawnWeight: 10,
    meleeDefinitionId: "zombie-claw",
    deathDrop: { itemId: "rotten-flesh", count: 1 }
  },
  {
    archetype: "skeleton",
    entityType: "creature",
    maxHealth: 20,
    navigation: { speed: 2.4, perceptionRange: 16 },
    disposition: "hostile",
    spawnWeight: 10,
    deathDrop: { itemId: "bone", count: 1 }
  },
  {
    archetype: "spider",
    entityType: "creature",
    maxHealth: 16,
    navigation: { speed: 2.8, perceptionRange: 12 },
    disposition: "hostile",
    spawnWeight: 10,
    meleeDefinitionId: "spider-bite",
    deathDrop: { itemId: "string", count: 1 }
  },
  {
    archetype: "creeper",
    entityType: "creature",
    maxHealth: 20,
    navigation: { speed: 2.3, perceptionRange: 12 },
    disposition: "hostile",
    spawnWeight: 8,
    meleeDefinitionId: "creeper-bump",
    deathDrop: { itemId: "gunpowder", count: 1 }
  },
  {
    archetype: "slime",
    entityType: "creature",
    maxHealth: 16,
    navigation: { speed: 2, perceptionRange: 10 },
    disposition: "hostile",
    spawnWeight: 3,
    spawnBiomes: ["wet"],
    meleeDefinitionId: "slime-bump",
    deathDrop: { itemId: "slimeball", count: 1 }
  }
];
var overworldDefaultPlayerMeleeDefinitionId = "unarmed";

// packages/stdlib/src/world/chunk-generation.ts
function makeChunk(seed, cx, cy, cz, changes, generatorVersion = GENERATOR_VERSION) {
  const data2 = new Uint16Array(CHUNK_SIZE ** 3);
  const ox = cx * CHUNK_SIZE, oy = cy * CHUNK_SIZE, oz = cz * CHUNK_SIZE;
  const macroCache = /* @__PURE__ */ new Map();
  const queryMacro = (x2, z) => {
    const key2 = chunkKey(x2, 0, z);
    let context = macroCache.get(key2);
    if (!context) {
      context = macroAt(seed, x2, z, generatorVersion);
      macroCache.set(key2, context);
    }
    return context;
  };
  for (let z = 0; z < CHUNK_SIZE; z += 1)
    for (let x2 = 0; x2 < CHUNK_SIZE; x2 += 1) {
      const context = queryMacro(ox + x2, oz + z);
      for (let y2 = 0; y2 < CHUNK_SIZE; y2 += 1)
        data2[voxelIndex(x2, y2, z)] = baseVoxel(seed, ox + x2, oy + y2, oz + z, context, queryMacro, generatorVersion);
    }
  for (const [x2, y2, z, value] of changes) {
    if (Math.floor(x2 / CHUNK_SIZE) === cx && Math.floor(y2 / CHUNK_SIZE) === cy && Math.floor(z / CHUNK_SIZE) === cz) {
      const lx = (x2 % CHUNK_SIZE + CHUNK_SIZE) % CHUNK_SIZE, ly = (y2 % CHUNK_SIZE + CHUNK_SIZE) % CHUNK_SIZE, lz = (z % CHUNK_SIZE + CHUNK_SIZE) % CHUNK_SIZE;
      data2[voxelIndex(lx, ly, lz)] = value;
    }
  }
  return data2;
}

// playbooks/classic/src/worldgen.ts
var classicWorldgenIdentity = Object.freeze({
  id: "seedlands:classic-worldgen",
  implementationVersion: "11.0.0",
  configurationIdentity: "seedlands:classic-terrain-g2-g11",
  supportedGeneratorVersions: Object.freeze([2, 3, 4, 5, 6, 7, 8, 9, 10, 11]),
  artifactIdentity: "seedlands:overworld@1.0.0"
});
function isCompatibleClassicWorldgenIdentity(candidate2, generatorVersion) {
  if (candidate2.id !== classicWorldgenIdentity.id || candidate2.artifactIdentity !== classicWorldgenIdentity.artifactIdentity || !Number.isSafeInteger(generatorVersion) || generatorVersion < 2 || generatorVersion > 10)
    return false;
  const maximumVersion = candidate2.supportedGeneratorVersions.at(-1);
  if (!Number.isSafeInteger(maximumVersion) || maximumVersion < generatorVersion || maximumVersion > 10) return false;
  const expectedVersions = Array.from({ length: maximumVersion - 1 }, (_, index) => index + 2);
  return candidate2.implementationVersion === `${maximumVersion}.0.0` && candidate2.configurationIdentity === `seedlands:classic-terrain-g2-g${maximumVersion}` && candidate2.supportedGeneratorVersions.length === expectedVersions.length && candidate2.supportedGeneratorVersions.every((version2, index) => version2 === expectedVersions[index]);
}
function createClassicWorldgenProvider(generateChunk = makeChunk, sampleMacro = macroAt) {
  const macroColumns = /* @__PURE__ */ new Map();
  const queryMacro = (seed, generatorVersion, x2, z) => {
    const key2 = [seed, generatorVersion, x2, z].join(":");
    const cached = macroColumns.get(key2);
    if (cached) return cached;
    const context = sampleMacro(seed, x2, z, generatorVersion);
    if (macroColumns.size >= 4096) macroColumns.clear();
    macroColumns.set(key2, context);
    return context;
  };
  return Object.freeze({
    identity: classicWorldgenIdentity,
    acceptsStoredIdentity: isCompatibleClassicWorldgenIdentity,
    generate(input) {
      const { seed, generatorVersion, coordinate, epoch, revision: revision2 } = input;
      return {
        coordinate,
        provider: classicWorldgenIdentity,
        generatorVersion,
        epoch,
        revision: revision2,
        voxels: generateChunk(seed, coordinate.x, coordinate.y, coordinate.z, [], generatorVersion)
      };
    },
    sampleVoxel({ seed, generatorVersion, x: x2, y: y2, z }) {
      const sampleColumn = (qx, qz) => queryMacro(seed, generatorVersion, qx, qz);
      return baseVoxel(seed, x2, y2, z, sampleColumn(x2, z), sampleColumn, generatorVersion);
    }
  });
}
var classicWorldgenProvider = createClassicWorldgenProvider();

// playbooks/classic/src/legacy-composition-identities.ts
var CAPTURED_KERNEL_MIGRATION_IDENTITY = '{"definitionMap":{"capabilities":[{"id":"seedlands:actor-modes","moduleId":"seedlands:mode-module","version":"1.0.0"},{"id":"seedlands:actor-profiles","moduleId":"seedlands:overworld-content","version":"1.0.0"},{"id":"seedlands:behavior-registry","moduleId":"seedlands:behavior-registry-module","version":"1.0.0"},{"id":"seedlands:block-actions","moduleId":"seedlands:block-actions-module","version":"1.0.0"},{"id":"seedlands:block-rules","moduleId":"seedlands:overworld-block-rules","version":"1.0.0"},{"id":"seedlands:combat","moduleId":"seedlands:combat-module","version":"1.0.0"},{"id":"seedlands:crafting-match","moduleId":"seedlands:recipe-crafting-module","version":"1.0.0"},{"id":"seedlands:feeding","moduleId":"seedlands:feeding-actions-module","version":"1.0.0"},{"id":"seedlands:forage","moduleId":"seedlands:forage-module","version":"1.0.0"},{"id":"seedlands:gameplay-content","moduleId":"seedlands:overworld-content","version":"1.0.0"},{"id":"seedlands:inventory","moduleId":"seedlands:inventory-module","version":"1.0.0"},{"id":"seedlands:inventory-actions","moduleId":"seedlands:inventory-actions-module","version":"1.0.0"},{"id":"seedlands:items","moduleId":"seedlands:overworld-content","version":"1.0.0"},{"id":"seedlands:needs","moduleId":"seedlands:needs-module","version":"1.0.0"},{"id":"seedlands:station-actions","moduleId":"seedlands:station-actions-module","version":"1.0.0"},{"id":"seedlands:world-ruleset","moduleId":"seedlands:ruleset-module","version":"1.0.0"}],"items":[{"id":"seedlands:berry","storageId":"berry"},{"id":"seedlands:chest","storageId":"chest"},{"id":"seedlands:coal","storageId":"coal"},{"id":"seedlands:dirt-block","storageId":"dirt-block"},{"id":"seedlands:furnace","storageId":"furnace"},{"id":"seedlands:glowstone-block","storageId":"glowstone-block"},{"id":"seedlands:iron-ingot","storageId":"iron-ingot"},{"id":"seedlands:iron-pickaxe","storageId":"iron-pickaxe"},{"id":"seedlands:lantern","storageId":"lantern"},{"id":"seedlands:plank","storageId":"plank"},{"id":"seedlands:raw-iron","storageId":"raw-iron"},{"id":"seedlands:sand-block","storageId":"sand-block"},{"id":"seedlands:stone-block","storageId":"stone-block"},{"id":"seedlands:stone-pickaxe","storageId":"stone-pickaxe"},{"id":"seedlands:wood-axe","storageId":"wood-axe"},{"id":"seedlands:wood-block","storageId":"wood-block"},{"id":"seedlands:wood-pickaxe","storageId":"wood-pickaxe"},{"id":"seedlands:wood-sword","storageId":"wood-sword"},{"id":"seedlands:workbench","storageId":"workbench"}],"lifecycles":[],"modules":[{"id":"seedlands:behavior-registry-module","packId":"seedlands:overworld","version":"1.0.0"},{"id":"seedlands:combat-module","packId":"seedlands:overworld","version":"1.0.0"},{"id":"seedlands:recipe-crafting-module","packId":"seedlands:overworld","version":"1.0.0"},{"id":"seedlands:ruleset-module","packId":"seedlands:overworld","version":"1.0.0"},{"id":"seedlands:needs-module","packId":"seedlands:overworld","version":"1.0.0"},{"id":"seedlands:overworld-combat-rules","packId":"seedlands:overworld","version":"1.0.0"},{"id":"seedlands:overworld-content","packId":"seedlands:overworld","version":"1.0.0"},{"id":"seedlands:feeding-actions-module","packId":"seedlands:overworld","version":"1.0.0"},{"id":"seedlands:forage-module","packId":"seedlands:overworld","version":"1.0.0"},{"id":"seedlands:inventory-module","packId":"seedlands:overworld","version":"1.0.0"},{"id":"seedlands:mode-module","packId":"seedlands:overworld","version":"1.0.0"},{"id":"seedlands:overworld-needs-rules","packId":"seedlands:overworld","version":"1.0.0"},{"id":"seedlands:station-actions-module","packId":"seedlands:overworld","version":"1.0.0"},{"id":"seedlands:block-actions-module","packId":"seedlands:overworld","version":"1.0.0"},{"id":"seedlands:inventory-actions-module","packId":"seedlands:overworld","version":"1.0.0"},{"id":"seedlands:overworld-feeding-rules","packId":"seedlands:overworld","version":"1.0.0"},{"id":"seedlands:overworld-block-rules","packId":"seedlands:overworld","version":"1.0.0"}],"operations":[{"executionKind":"system","id":"seedlands:advance-combat","moduleId":"seedlands:combat-module","resource":"seedlands.combat-clock"},{"executionKind":"system","id":"seedlands:advance-needs","moduleId":"seedlands:needs-module","resource":"seedlands.needs"},{"executionKind":"system","id":"seedlands:block-advance","moduleId":"seedlands:block-actions-module","resource":"seedlands.block-clock"},{"executionKind":"actor","id":"seedlands:block-begin","moduleId":"seedlands:block-actions-module","resource":"seedlands.block-voxel"},{"executionKind":"actor","id":"seedlands:block-cancel","moduleId":"seedlands:block-actions-module","resource":"seedlands.block-actor"},{"executionKind":"actor","id":"seedlands:block-finish","moduleId":"seedlands:block-actions-module","resource":"seedlands.block-voxel"},{"executionKind":"actor","id":"seedlands:block-place","moduleId":"seedlands:block-actions-module","resource":"seedlands.block-voxel"},{"executionKind":"actor","id":"seedlands:consume-world-item","moduleId":"seedlands:feeding-actions-module","resource":"seedlands.feeding-item"},{"executionKind":"system","id":"seedlands:forage-advance","moduleId":"seedlands:forage-module","resource":"seedlands.forage-clock"},{"executionKind":"system","id":"seedlands:furnace-advance","moduleId":"seedlands:station-actions-module","resource":"seedlands.furnace-clock"},{"executionKind":"actor","id":"seedlands:inventory-consume","moduleId":"seedlands:inventory-actions-module","resource":"seedlands.inventory"},{"executionKind":"actor","id":"seedlands:inventory-craft","moduleId":"seedlands:inventory-actions-module","resource":"seedlands.inventory"},{"executionKind":"actor","id":"seedlands:inventory-drop","moduleId":"seedlands:inventory-actions-module","resource":"seedlands.inventory"},{"executionKind":"actor","id":"seedlands:inventory-move","moduleId":"seedlands:inventory-actions-module","resource":"seedlands.inventory"},{"executionKind":"actor","id":"seedlands:inventory-pickup","moduleId":"seedlands:inventory-actions-module","resource":"seedlands.inventory-item"},{"executionKind":"actor","id":"seedlands:inventory-select","moduleId":"seedlands:inventory-actions-module","resource":"seedlands.inventory"},{"executionKind":"actor","id":"seedlands:inventory-transfer","moduleId":"seedlands:inventory-module","resource":"seedlands.inventory"},{"executionKind":"actor","id":"seedlands:request-combat","moduleId":"seedlands:combat-module","resource":"seedlands.combat"},{"executionKind":"actor","id":"seedlands:resolve-combat","moduleId":"seedlands:combat-module","resource":"seedlands.combat"},{"executionKind":"actor","id":"seedlands:set-creative-catalog","moduleId":"seedlands:mode-module","resource":"seedlands.mode"},{"executionKind":"actor","id":"seedlands:set-flight","moduleId":"seedlands:mode-module","resource":"seedlands.mode"},{"executionKind":"actor","id":"seedlands:set-mode","moduleId":"seedlands:mode-module","resource":"seedlands.mode"},{"executionKind":"actor","id":"seedlands:station-craft","moduleId":"seedlands:station-actions-module","resource":"seedlands.station"},{"executionKind":"actor","id":"seedlands:station-transfer","moduleId":"seedlands:station-actions-module","resource":"seedlands.station"}],"packs":[{"id":"seedlands:overworld","version":"1.0.0"}],"recipes":[{"id":"seedlands:lantern","storageId":"lantern"},{"id":"seedlands:planks","storageId":"planks"},{"id":"seedlands:stone-pickaxe","storageId":"stone-pickaxe"},{"id":"seedlands:wood-axe","storageId":"wood-axe"},{"id":"seedlands:wood-sword","storageId":"wood-sword"},{"id":"seedlands:workbench","storageId":"workbench"}],"resources":[{"id":"seedlands.block-actor","operations":["read","execute"]},{"id":"seedlands.block-clock","operations":["read","execute"]},{"id":"seedlands.block-voxel","operations":["read","execute"]},{"id":"seedlands.combat","operations":["read","execute"]},{"id":"seedlands.combat-clock","operations":["read","execute"]},{"id":"seedlands.feeding-actor","operations":["read","execute"]},{"id":"seedlands.feeding-item","operations":["read","execute"]},{"id":"seedlands.forage-clock","operations":["read","execute"]},{"id":"seedlands.furnace-clock","operations":["read","execute"]},{"id":"seedlands.inventory","operations":["read","write","execute"]},{"id":"seedlands.inventory-item","operations":["read","execute"]},{"id":"seedlands.mode","operations":["read","write","execute"]},{"id":"seedlands.needs","operations":["read","write","execute"]},{"id":"seedlands.ruleset","operations":["read"]},{"id":"seedlands.station","operations":["read","execute"]},{"id":"seedlands.station-actor","operations":["read","execute"]}],"rules":[{"id":"seedlands:overworld-block-rules/begin-before","moduleId":"seedlands:overworld-block-rules","operationId":"seedlands:block-begin","stage":"before"},{"id":"seedlands:overworld-block-rules/finish-before","moduleId":"seedlands:overworld-block-rules","operationId":"seedlands:block-finish","stage":"before"},{"id":"seedlands:overworld-block-rules/place-before","moduleId":"seedlands:overworld-block-rules","operationId":"seedlands:block-place","stage":"before"},{"id":"seedlands:overworld-combat-rules/request-before","moduleId":"seedlands:overworld-combat-rules","operationId":"seedlands:request-combat","stage":"before"},{"id":"seedlands:overworld-combat-rules/resolve-before","moduleId":"seedlands:overworld-combat-rules","operationId":"seedlands:resolve-combat","stage":"before"},{"id":"seedlands:overworld-feeding-rules/before","moduleId":"seedlands:overworld-feeding-rules","operationId":"seedlands:consume-world-item","stage":"before"},{"id":"seedlands:overworld-needs-rules/before","moduleId":"seedlands:overworld-needs-rules","operationId":"seedlands:advance-needs","stage":"before"},{"id":"seedlands:overworld-block-rules/begin-after","moduleId":"seedlands:overworld-block-rules","operationId":"seedlands:block-begin","stage":"after"},{"id":"seedlands:overworld-block-rules/cancel-after","moduleId":"seedlands:overworld-block-rules","operationId":"seedlands:block-cancel","stage":"after"},{"id":"seedlands:overworld-block-rules/finish-after","moduleId":"seedlands:overworld-block-rules","operationId":"seedlands:block-finish","stage":"after"},{"id":"seedlands:overworld-block-rules/place-after","moduleId":"seedlands:overworld-block-rules","operationId":"seedlands:block-place","stage":"after"},{"id":"seedlands:overworld-combat-rules/request-after","moduleId":"seedlands:overworld-combat-rules","operationId":"seedlands:request-combat","stage":"after"},{"id":"seedlands:overworld-combat-rules/resolve-after","moduleId":"seedlands:overworld-combat-rules","operationId":"seedlands:resolve-combat","stage":"after"},{"id":"seedlands:overworld-feeding-rules/after","moduleId":"seedlands:overworld-feeding-rules","operationId":"seedlands:consume-world-item","stage":"after"},{"id":"seedlands:overworld-needs-rules/after","moduleId":"seedlands:overworld-needs-rules","operationId":"seedlands:advance-needs","stage":"after"}],"stateCodecs":[{"id":"seedlands:actor-mode","moduleId":"seedlands:mode-module","resource":"seedlands.mode","version":"1.0.0"},{"id":"seedlands:actor-needs","moduleId":"seedlands:needs-module","partitions":5,"resource":"seedlands.needs","version":"1.0.0"},{"id":"seedlands:block-actor","moduleId":"seedlands:block-actions-module","resource":"seedlands.block-actor","version":"1.0.0"},{"id":"seedlands:block-voxel","moduleId":"seedlands:block-actions-module","resource":"seedlands.block-voxel","version":"1.0.0"},{"id":"seedlands:block-world","moduleId":"seedlands:block-actions-module","partitions":8,"resource":"seedlands.block-clock","version":"1.0.0"},{"id":"seedlands:combat-actor","moduleId":"seedlands:combat-module","resource":"seedlands.combat","version":"1.0.0"},{"id":"seedlands:combat-world","moduleId":"seedlands:combat-module","partitions":5,"resource":"seedlands.combat-clock","version":"1.0.0"},{"id":"seedlands:feeding-actor","moduleId":"seedlands:feeding-actions-module","resource":"seedlands.feeding-actor","version":"1.0.0"},{"id":"seedlands:feeding-item","moduleId":"seedlands:feeding-actions-module","resource":"seedlands.feeding-item","version":"1.0.0"},{"id":"seedlands:forage-world","moduleId":"seedlands:forage-module","resource":"seedlands.forage-clock","version":"1.0.0"},{"id":"seedlands:furnace-world","moduleId":"seedlands:station-actions-module","partitions":8,"resource":"seedlands.furnace-clock","version":"1.0.0"},{"id":"seedlands:inventory","moduleId":"seedlands:inventory-module","resource":"seedlands.inventory","version":"1.0.0"},{"id":"seedlands:inventory-actor","moduleId":"seedlands:inventory-actions-module","resource":"seedlands.inventory","version":"1.0.0"},{"id":"seedlands:inventory-item","moduleId":"seedlands:inventory-actions-module","resource":"seedlands.inventory-item","version":"1.0.0"},{"id":"seedlands:station-actor","moduleId":"seedlands:station-actions-module","resource":"seedlands.station-actor","version":"1.0.0"},{"id":"seedlands:station-instance","moduleId":"seedlands:station-actions-module","resource":"seedlands.station","version":"1.0.0"},{"id":"seedlands:world-ruleset","moduleId":"seedlands:ruleset-module","resource":"seedlands.ruleset","version":"1.0.0"}],"systems":[{"definition":{"after":[],"before":[],"cadence":"every-advance","id":"seedlands:block-system","operationId":"seedlands:block-advance"},"moduleId":"seedlands:block-actions-module"},{"definition":{"after":[],"before":[],"cadence":"every-advance","id":"seedlands:combat-system","operationId":"seedlands:advance-combat"},"moduleId":"seedlands:combat-module"},{"definition":{"after":[],"before":[],"cadence":"interval","id":"seedlands:forage-system","intervalSeconds":120,"operationId":"seedlands:forage-advance"},"moduleId":"seedlands:forage-module"},{"definition":{"after":[],"before":[],"cadence":"every-advance","id":"seedlands:furnace-system","operationId":"seedlands:furnace-advance"},"moduleId":"seedlands:station-actions-module"},{"definition":{"after":[],"before":[],"cadence":"every-advance","id":"seedlands:needs-system","operationId":"seedlands:advance-needs"},"moduleId":"seedlands:needs-module"}]},"packLock":[{"id":"seedlands:overworld","integrity":{"algorithm":"sha256","entryDigest":"924d61fc72f253c85e191caa79f1c7ff51f83bc6237ad613a7c0c5595c2c169f","manifestDigest":"e3c199e87d101672c1635d481771972edbf39deb43c336063ab3753d0b01bb89","resources":[]},"version":"1.0.0"}],"playbookId":"seedlands:overworld","version":1}';
var capturedIdentity = (manifestDigest, entryDigest, includeBehaviorRegistry) => {
  const identity5 = JSON.parse(CAPTURED_KERNEL_MIGRATION_IDENTITY);
  const pack2 = identity5.packLock[0];
  return {
    ...identity5,
    packLock: [
      {
        ...pack2,
        integrity: { ...pack2.integrity, manifestDigest, entryDigest }
      }
    ],
    definitionMap: includeBehaviorRegistry ? identity5.definitionMap : {
      ...identity5.definitionMap,
      modules: identity5.definitionMap.modules.filter(({ id: id2 }) => id2 !== "seedlands:behavior-registry-module"),
      capabilities: identity5.definitionMap.capabilities.filter(({ id: id2 }) => id2 !== "seedlands:behavior-registry")
    }
  };
};
var classicGameplaySnapshotPredecessors = defineGameplaySnapshotPredecessorsV1([
  {
    gameplayVersions: [1, 2, 3, 4],
    identity: capturedIdentity(
      "e3c199e87d101672c1635d481771972edbf39deb43c336063ab3753d0b01bb89",
      "924d61fc72f253c85e191caa79f1c7ff51f83bc6237ad613a7c0c5595c2c169f",
      true
    )
  },
  {
    gameplayVersions: [4],
    identity: capturedIdentity(
      "05bc5e57bb6cfd4ed0e2da821f8b6e803bb7e3676453988a131a4b8524c066dd",
      "4a773fe7225f13ef018def0a930b469aa82e558fdebc5172b7ef602ed8e148e2",
      true
    )
  },
  {
    gameplayVersions: [4],
    identity: capturedIdentity(
      "05bc5e57bb6cfd4ed0e2da821f8b6e803bb7e3676453988a131a4b8524c066dd",
      "7583373d53f9cb3f2447bf40478eb9f8d817adc80060effa385633ecaacf5e6a",
      false
    )
  },
  {
    gameplayVersions: [4],
    identity: capturedIdentity(
      "74d0a1a50d2812053fa442ae00137d285dd6b80954c3e21d788053eb2ec243f2",
      "a0822ae7e3ae985c47db22deee54d77f788a0cd72eece3f4a4c46a4c6037eee6",
      false
    )
  }
]);
var classicKernelMigrationCompositionIdentity = classicGameplaySnapshotPredecessors[0].identity;

// playbooks/classic/src/retired-actors-migration.ts
var RETIRED_ARCHETYPES = /* @__PURE__ */ new Set(["grazer", "night-stalker", "settler"]);
var RETIRED_MELEE_DEFINITIONS = /* @__PURE__ */ new Set(["night-stalker-claw"]);
var REPORT_ID = "seedlands:classic-retired-actors-v1";
var PRE_MEDIA_MANIFEST_DIGEST = "8c85965878299e56d918bdc89302789d38a26d3a04a1d924fe4e885daca3fae4";
var PRE_MEDIA_ENTRY_DIGEST = "9a22f2d679b8a00bba8a66658457de477c1b05500cf353fb7ed368c6d69bf12a";
var PRESENTATION_DIGEST = "a1e379e5e8a9d5f5d41ef7ce204863af0d0cfe41b9e3081e138d87d2517d9f5b";
var MEDIA_MODULE_ID = "seedlands:overworld-media";
var MEDIA_CAPABILITY_ID = "seedlands:media-playback";
var MEDIA_RESOURCE_ID = "seedlands.media-playback";
var MEDIA_STATE_ID = "seedlands:media-playback-device";
var MEDIA_OPERATION_IDS = /* @__PURE__ */ new Set([
  "seedlands:media-activate",
  "seedlands:media-eject",
  "seedlands:media-insert",
  "seedlands:media-insert-and-activate",
  "seedlands:media-stop",
  "seedlands:media-switch"
]);
var record6 = (value) => value && typeof value === "object" && !Array.isArray(value) ? value : null;
var rows = (value) => Array.isArray(value) && value.every((entry) => record6(entry) !== null) ? value : null;
var idOf = (value) => typeof value.id === "string" ? value.id : null;
var actorIdOf = (value) => typeof value.entityId === "string" ? value.entityId : null;
var canonicalData = (input) => {
  let budget = 262144;
  const active = /* @__PURE__ */ new Set();
  const visit = (value, depth) => {
    if (--budget < 0 || depth > 24) throw new TypeError("Classic migration identity exceeds limits.");
    if (value === null || typeof value === "boolean") return JSON.stringify(value);
    if (typeof value === "string") {
      budget -= value.length;
      return JSON.stringify(value);
    }
    if (typeof value === "number" && Number.isFinite(value)) return JSON.stringify(value);
    if (!value || typeof value !== "object" || active.has(value))
      throw new TypeError("Classic migration identity is invalid.");
    const keys = Object.keys(value).sort();
    if (Array.isArray(value) && (keys.length !== value.length || Reflect.ownKeys(value).length !== value.length + 1))
      throw new TypeError("Classic migration identity array is invalid.");
    active.add(value);
    const result = Array.isArray(value) ? `[${value.map((entry) => visit(entry, depth + 1)).join(",")}]` : `{${keys.map((key2) => `${JSON.stringify(key2)}:${visit(value[key2], depth + 1)}`).join(",")}}`;
    active.delete(value);
    return result;
  };
  try {
    return visit(input, 0);
  } catch {
    return null;
  }
};
var isRetiredEntity = (value) => (value.type === "creature" || value.type === "npc") && typeof value.archetype === "string" && RETIRED_ARCHETYPES.has(value.archetype);
var isPreMediaClassicSource = (snapshot, targetComposition) => {
  const source = record6(snapshot.composition);
  const target = record6(targetComposition);
  const definitionMap = record6(target?.definitionMap);
  const packLock = rows(target?.packLock);
  const modules = rows(definitionMap?.modules);
  const capabilities = rows(definitionMap?.capabilities);
  const resources = rows(definitionMap?.resources);
  const stateCodecs = rows(definitionMap?.stateCodecs);
  const operations = rows(definitionMap?.operations);
  if (!source || !target || target.playbookId !== "seedlands:overworld" || packLock?.length !== 1 || packLock[0]?.id !== "seedlands:overworld" || packLock[0]?.version !== "1.0.0" || !definitionMap || !modules || !capabilities || !resources || !stateCodecs || !operations)
    return false;
  const expected = {
    ...target,
    packLock: [
      {
        ...packLock[0],
        integrity: {
          algorithm: "sha256",
          manifestDigest: PRE_MEDIA_MANIFEST_DIGEST,
          entryDigest: PRE_MEDIA_ENTRY_DIGEST,
          resources: [{ path: "playbooks/classic/presentation.json", digest: PRESENTATION_DIGEST }]
        }
      }
    ],
    definitionMap: {
      ...definitionMap,
      modules: modules.filter(({ id: id2 }) => id2 !== MEDIA_MODULE_ID),
      capabilities: capabilities.filter(({ id: id2 }) => id2 !== MEDIA_CAPABILITY_ID),
      resources: resources.filter(({ id: id2 }) => id2 !== MEDIA_RESOURCE_ID),
      stateCodecs: stateCodecs.filter(({ id: id2 }) => id2 !== MEDIA_STATE_ID),
      operations: operations.filter(({ id: id2 }) => !MEDIA_OPERATION_IDS.has(String(id2)))
    }
  };
  const sourceIdentity = canonicalData(source);
  return sourceIdentity !== null && sourceIdentity === canonicalData(expected);
};
var referencesRetiredActor = (value, retiredIds) => typeof value.actorId === "string" && retiredIds.has(value.actorId) || typeof value.targetEntityId === "string" && retiredIds.has(value.targetEntityId) || record6(value.actorIdentity) !== null && retiredIds.has(record6(value.actorIdentity).entityId) || record6(value.targetIdentity) !== null && retiredIds.has(record6(value.targetIdentity).entityId);
var cleanCharacter = (value, retiredIds, retiredActionIds) => {
  const next = { ...value };
  const targets = rows(value.targets);
  if (targets) next.targets = targets.filter((target) => !retiredIds.has(String(target.targetId)));
  if (typeof value.executionTargetId === "string" && retiredIds.has(value.executionTargetId))
    delete next.executionTargetId;
  if (typeof value.lastThreatEntityId === "string" && retiredIds.has(value.lastThreatEntityId))
    delete next.lastThreatEntityId;
  if (typeof value.actionId === "string" && retiredActionIds.has(value.actionId)) delete next.actionId;
  return next;
};
var classicRetiredActorsMigration = Object.freeze({
  predecessors: classicGameplaySnapshotPredecessors,
  migrate(raw, context) {
    const snapshot = record6(raw);
    if (!snapshot || snapshot.version !== 1 && snapshot.version !== 2 && snapshot.version !== 3 && snapshot.version !== 4)
      return { snapshot: raw, reports: [] };
    if (snapshot.version === 4) {
      if (!context.targetComposition) return { snapshot: raw, reports: [] };
      if (!matchesGameplaySnapshotPredecessorV1(classicGameplaySnapshotPredecessors, 4, snapshot.composition) && !isPreMediaClassicSource(snapshot, context.targetComposition))
        return { snapshot: raw, reports: [] };
    }
    const entityStore = snapshot.version === 4 ? record6(snapshot.entityStore) : null;
    const entities = rows(snapshot.version === 4 ? entityStore?.entities : snapshot.entities);
    const simulation = record6(snapshot.simulation);
    const autonomous = rows(simulation?.actors);
    const retiredIds = /* @__PURE__ */ new Set();
    entities?.forEach((entity) => {
      const id2 = idOf(entity);
      if (id2 && isRetiredEntity(entity)) retiredIds.add(id2);
    });
    autonomous?.forEach((actor) => {
      const id2 = actorIdOf(actor);
      if (id2 && typeof actor.archetype === "string" && RETIRED_ARCHETYPES.has(actor.archetype)) retiredIds.add(id2);
    });
    if (snapshot.version === 4) snapshot.composition = context.targetComposition;
    if (entities) {
      const retained = entities.filter((entity) => !retiredIds.has(idOf(entity) ?? ""));
      if (snapshot.version === 4 && entityStore) entityStore.entities = retained;
      else snapshot.entities = retained;
    }
    if (entityStore) {
      const identities = rows(entityStore.identities);
      if (identities)
        entityStore.identities = identities.filter((identity5) => !retiredIds.has(String(identity5.entityId)));
      const components = rows(entityStore.actors);
      if (components) {
        entityStore.actors = components.filter((actor) => !retiredIds.has(String(actor.entityId))).map((actor) => ({
          ...actor,
          ...record6(actor.character) ? { character: cleanCharacter(record6(actor.character), retiredIds, /* @__PURE__ */ new Set()) } : {}
        }));
      }
    }
    if (simulation) {
      if (autonomous) {
        simulation.actors = autonomous.filter((actor) => !retiredIds.has(String(actor.entityId))).map(
          (actor) => typeof actor.targetEntityId === "string" && retiredIds.has(actor.targetEntityId) ? { ...actor, targetEntityId: null } : actor
        );
      }
      const actions = record6(simulation.actions);
      const actionRows = rows(actions?.actions);
      const retiredActionIds = /* @__PURE__ */ new Set();
      if (actions && actionRows) {
        for (const action of actionRows)
          if (referencesRetiredActor(action, retiredIds) && typeof action.id === "string")
            retiredActionIds.add(action.id);
        actions.actions = actionRows.filter((action) => !retiredActionIds.has(String(action.id)));
      }
      const combat = record6(simulation.combat);
      const combatants = rows(combat?.combatants);
      if (combat && combatants) {
        combat.combatants = combatants.filter((entry) => {
          if (referencesRetiredActor(entry, retiredIds)) return false;
          const state = record6(entry.combat);
          const active = record6(state?.active);
          const result = record6(state?.lastResult);
          return !(active && (retiredIds.has(String(active.targetId)) || RETIRED_MELEE_DEFINITIONS.has(String(active.definitionId))) || result && (retiredIds.has(String(result.targetId)) || RETIRED_MELEE_DEFINITIONS.has(String(result.definitionId))));
        });
      }
      for (const key2 of ["characters", "characterTombstones"]) {
        const characters = record6(simulation[key2]);
        const characterRows = rows(characters?.characters);
        if (characters && characterRows)
          characters.characters = characterRows.filter((character2) => !retiredIds.has(String(character2.entityId))).map((character2) => cleanCharacter(character2, retiredIds, retiredActionIds));
      }
      if (entityStore) {
        const components = rows(entityStore.actors);
        if (components)
          entityStore.actors = components.map((actor) => ({
            ...actor,
            ...record6(actor.character) ? { character: cleanCharacter(record6(actor.character), retiredIds, retiredActionIds) } : {}
          }));
      }
    }
    return {
      snapshot,
      reports: retiredIds.size === 0 ? [] : [{ id: REPORT_ID, removedActorIds: [...retiredIds].sort() }]
    };
  }
});

// playbooks/classic/src/item-interactions.ts
var classicFluidContainerOperationId = "seedlands:fluid-container-interact";
var classicItemInteractionModules = [
  defineFluidContainerInteractionModule({
    moduleId: "seedlands:fluid-container-handler",
    operationId: classicFluidContainerOperationId,
    emptyItemId: "bucket",
    emptyVoxel: Voxel.Air,
    filled: [
      { itemId: "water-bucket", voxel: Voxel.Water },
      { itemId: "lava-bucket", voxel: Voxel.Lava }
    ],
    replaceableVoxels: [Voxel.Air, Voxel.Fire]
  }),
  defineItemInteractionModule({
    moduleId: "seedlands:overworld-item-interactions",
    permissions: [{ resource: "seedlands.block-voxel", operations: ["execute"] }],
    definitions: ["bucket", "water-bucket", "lava-bucket"].map((itemId) => ({
      id: `seedlands:${itemId}-voxel-interaction`,
      selector: { itemId: `seedlands:${itemId}` },
      trigger: "voxel",
      operationId: classicFluidContainerOperationId,
      presentationKey: `seedlands:${itemId}`
    }))
  })
];

// playbooks/classic/src/structure-descriptors.ts
var THICKNESS = 3 / 16;
var openedToward = Object.freeze({
  north: "west",
  east: "north",
  south: "east",
  west: "south"
});
var boxFor = (orientation) => {
  switch (orientation) {
    case "north":
      return { min: [0, 0, 0], max: [1, 1, THICKNESS] };
    case "east":
      return { min: [1 - THICKNESS, 0, 0], max: [1, 1, 1] };
    case "south":
      return { min: [0, 0, 1 - THICKNESS], max: [1, 1, 1] };
    case "west":
      return { min: [0, 0, 0], max: [THICKNESS, 1, 1] };
  }
};
var definitions2 = classicWoodenDoorVariants.map((variant) => {
  const shape = boxFor(variant.open ? openedToward[variant.orientation] : variant.orientation);
  return {
    version: 1,
    voxel: variant.storageId,
    boxes: [{ ...shape, material: FaceMaterial.WoodenDoor }],
    collision: variant.open ? [] : [shape],
    occludesFullFace: false
  };
});
var classicWoodenDoorGeometryDescriptors = createVoxelGeometryRegistryV1(definitions2).list();

// playbooks/classic/src/structure-actions.ts
var replaceable = new Set(overworldBlocks.filter((block) => block.replaceable).map((block) => block.voxel));
var durableMiningTools = new Set(
  overworldItems.filter((item) => item.durability && item.capabilities.some((capability) => capability.type === "mine")).map((item) => item.id)
);
var classicStructureActionPolicy = Object.freeze({
  placementState: (_definition, bearing) => classicWoodenDoorClosedStateForBearing(bearing),
  toggleTransitionId: () => "toggle",
  isReplaceable: (voxel2) => replaceable.has(voxel2),
  breakToolWear: (_definition, selected) => selected?.instance && durableMiningTools.has(selected.itemId) ? 1 : 0
});
var classicStructureActionsModule = defineStructureActionsModuleV1({
  moduleId: "seedlands:overworld-structure-actions",
  policy: classicStructureActionPolicy
});

// playbooks/classic/src/media.ts
var classicMedia = {
  version: 1,
  tracks: [
    {
      id: "seedlands:to-far-shores",
      resource: {
        packId: "seedlands:overworld",
        path: "playbooks/classic/assets/audio/to-far-shores.mp3"
      }
    }
  ],
  devices: [
    {
      id: "seedlands:jukebox",
      target: { kind: "voxel", voxelId: "seedlands:classic/jukebox" },
      tracks: [{ itemId: "seedlands:record-13", trackId: "seedlands:to-far-shores" }],
      playOnInsert: true
    }
  ]
};

// playbooks/classic/src/pack.ts
var namespaceId2 = (id2) => `seedlands:${id2}`;
var namespaceStack = (stack2) => ({
  ...stack2,
  itemId: namespaceId2(stack2.itemId)
});
var pack = definePack({
  id: "seedlands:overworld",
  version: "1.0.0",
  kind: "playbook",
  entry: "overworld.mjs",
  resources: ["playbooks/classic/presentation.json", "playbooks/classic/assets/audio/to-far-shores.mp3"],
  presentation: { path: "playbooks/classic/presentation.json" },
  modules: [
    defineStandardWorldgenModule({
      moduleId: "seedlands:overworld-worldgen",
      provider: classicWorldgenProvider
    }),
    defineContentModule({
      moduleId: "seedlands:overworld-content",
      craftingProvider: true,
      items: overworldItems.map((item) => ({ ...item, id: namespaceId2(item.id), storageId: item.id })),
      voxels: overworldVoxelSemantics,
      recipes: overworldRecipes.map((recipe) => ({
        ...recipe,
        id: namespaceId2(recipe.id),
        storageId: recipe.id,
        inputs: recipe.inputs.map((stack2) => ({ ...stack2, itemId: namespaceId2(stack2.itemId) })),
        outputs: recipe.outputs.map((stack2) => ({ ...stack2, itemId: namespaceId2(stack2.itemId) }))
      })),
      meleeDefinitions: overworldMeleeDefinitions,
      actorProfiles: overworldActorProfiles.map((profile) => ({
        ...profile,
        ...profile.deathDrop ? { deathDrop: namespaceStack(profile.deathDrop) } : {}
      })),
      defaultPlayerMeleeDefinitionId: overworldDefaultPlayerMeleeDefinitionId,
      snapshotMigration: classicRetiredActorsMigration,
      stations: {
        ...overworldStations,
        recipes: overworldStations.recipes.map(
          (recipe) => recipe.kind === "shaped" ? {
            ...recipe,
            pattern: recipe.pattern.map(
              (stack2) => stack2 ? { ...stack2, itemId: namespaceId2(stack2.itemId) } : null
            ),
            outputs: recipe.outputs.map((stack2) => ({ ...stack2, itemId: namespaceId2(stack2.itemId) }))
          } : {
            ...recipe,
            inputs: recipe.inputs.map((stack2) => ({ ...stack2, itemId: namespaceId2(stack2.itemId) })),
            outputs: recipe.outputs.map((stack2) => ({ ...stack2, itemId: namespaceId2(stack2.itemId) }))
          }
        ),
        furnaceRecipes: overworldStations.furnaceRecipes.map((recipe) => ({
          ...recipe,
          input: { ...recipe.input, itemId: namespaceId2(recipe.input.itemId) },
          output: { ...recipe.output, itemId: namespaceId2(recipe.output.itemId) }
        })),
        fuels: overworldStations.fuels.map((fuel) => ({ ...fuel, itemId: namespaceId2(fuel.itemId) }))
      }
    }),
    defineVoxelGeometryModule({
      moduleId: "seedlands:overworld-voxel-geometry",
      descriptors: classicWoodenDoorGeometryDescriptors
    }),
    classicStructureDefinitionModule,
    classicStructureActionsModule,
    defineMediaPlaybackModuleV1({ moduleId: "seedlands:overworld-media", definition: classicMedia }),
    defineRecipeCraftingModule(),
    defineRulesetModule({ id: "seedlands:overworld-rules", version: "1.0.0" }),
    defineInventoryModule({ playerLayout: { capacity: 36, hotbarSize: 9 } }),
    defineInventoryActionsModule(),
    defineBehaviorRegistryModule({
      permissions: [
        { resource: "seedlands.inventory", operations: ["execute"] },
        { resource: "seedlands.inventory-item", operations: ["execute"] },
        { resource: "seedlands.combat", operations: ["execute"] },
        { resource: "seedlands.structure", operations: ["execute"] }
      ]
    }),
    defineStationActionsModule(),
    defineForageModule({ sourceVoxel: 5, drop: { itemId: "berry", count: 1 }, intervalSeconds: 120 }),
    defineBlockActionsModule({ stations: true, media: true }),
    ...classicItemInteractionModules,
    defineBlockRulesModule({ moduleId: "seedlands:overworld-block-rules", voxelDefinitions: overworldBlocks }),
    defineModeModule(),
    defineCombatModule(),
    defineCombatRulesModule({
      moduleId: "seedlands:overworld-combat-rules",
      profile: { damageMultiplier: 1, immuneTargetModes: ["creative"] }
    }),
    defineNeedsModule(),
    defineNeedsRulesModule({
      moduleId: "seedlands:overworld-needs-rules",
      profiles: {
        satiety: {
          enabledModes: [],
          hungerEverySeconds: 120,
          hungerDelta: 0
        },
        deficit: { enabledModes: ["survival"], hungerEverySeconds: 5, hungerDelta: 1 }
      }
    })
  ]
});
export {
  pack
};
