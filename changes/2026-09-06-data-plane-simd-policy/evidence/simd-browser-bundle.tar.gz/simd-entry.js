const B = /* @__PURE__ */ new Map(), V = (t, n, r) => Math.min(r, Math.max(n, t)), Z = (t, n) => Math.floor(t / n), ft = (t) => t * t * (3 - 2 * t);
function $(t, n, r) {
  let o = (t ^ Math.imul(n, 374761393) ^ Math.imul(r, 668265263)) >>> 0;
  return o = Math.imul(o ^ o >>> 13, 1274126177) >>> 0, ((o ^ o >>> 16) >>> 0) / 4294967296;
}
function T(t, n, r, o) {
  const a = n / o, e = r / o, s = Math.floor(a), i = Math.floor(e), l = ft(a - s), y = ft(e - i), L = $(t, s, i), m = $(t, s + 1, i), f = $(t, s, i + 1), p = $(t, s + 1, i + 1);
  return L + (m - L) * l + (f + (p - f) * l - (L + (m - L) * l)) * y;
}
function j(t, n, r) {
  const o = T(t ^ 5370206, n, r, 1800) * 2 - 1, a = 14 + o * 6 + (T(t ^ 72846, n, r, 640) * 2 - 1) * 2, e = V(
    T(t ^ 2135587861, n, r, 440) * 0.72 + T(t ^ 455385, n, r, 920) * 0.28,
    0,
    1
  ), s = T(t ^ 3373489, n, r, 720), i = Math.max(0, e - 0.38) / 0.62, l = Math.round(
    a + i * (7 + (1 - s) * 12) + (T(t ^ 270441, n, r, 84) * 2 - 1) * (1 + e * 2)
  );
  return { continentalness: o, baseElevation: a, relief: e, erosion: s, terrainHeight: l };
}
function yt(t, n, r, o, a, e) {
  const s = a - r, i = e - o, l = s * s + i * i, y = l === 0 ? 0 : V(((t - r) * s + (n - o) * i) / l, 0, 1), L = r + s * y, m = o + i * y;
  return { distance: Math.hypot(t - L, n - m), tangent: [s, i] };
}
function Lt(t, n, r, o) {
  const a = `${t}:${o}:${n},${r}`;
  if (B.has(a)) return B.get(a) ?? null;
  if ($(t ^ 4479629, n, r) < 0.76)
    return B.set(a, null), null;
  const s = [
    Math.round((n + 0.12 + $(t ^ 1979815, n, r) * 0.76) * 768),
    Math.round((r + 0.12 + $(t ^ 810657, n, r) * 0.76) * 768)
  ];
  let i = [1, 0], l = 1 / 0;
  for (let R = 0; R < 8; R += 1) {
    const F = R / 8 * Math.PI * 2, E = s[0] + Math.cos(F) * 640, u = s[1] + Math.sin(F) * 640, h = j(t, E, u).terrainHeight;
    h < l && (l = h, i = [Math.cos(F), Math.sin(F)]);
  }
  const y = [-i[1], i[0]], L = ($(t ^ 1150299, n, r) * 2 - 1) * 34, m = [s];
  for (let R = 1; R <= 6; R += 1) {
    const F = R * 112, E = Math.sin(R * 1.17 + $(t ^ 490004, n, r) * Math.PI * 2) * L;
    m.push([
      Math.round(s[0] + i[0] * F + y[0] * E),
      Math.round(s[1] + i[1] * F + y[1] * E)
    ]);
  }
  const f = 4 + Math.floor($(t ^ 679649, n, r) * 5), p = m.at(-1);
  let g = V(
    Math.round(
      Math.min(j(t, ...s).terrainHeight, j(t, ...p).terrainHeight) + 1
    ),
    10,
    24
  );
  if (o >= 3) {
    let R = 1 / 0;
    for (let F = 1; F < m.length; F += 1) {
      const E = m[F - 1], u = m[F], h = u[0] - E[0], w = u[1] - E[1], d = Math.hypot(h, w) || 1, A = [-w / d, h / d], b = Math.max(8, Math.ceil(d / 14));
      for (let O = 0; O <= b; O += 1) {
        const W = O / b, N = E[0] + h * W, v = E[1] + w * W;
        for (const k of [0, f + 1, -(f + 1), f + 4, -(f + 4)])
          R = Math.min(
            R,
            j(t, Math.round(N + A[0] * k), Math.round(v + A[1] * k)).terrainHeight
          );
      }
    }
    g = V(Math.floor(R) - 1, 8, 24);
  }
  const C = {
    id: `river:${n},${r}`,
    source: s,
    path: m,
    width: f,
    waterLevel: g,
    direction: i
  };
  return B.size >= 2048 && B.clear(), B.set(a, C), C;
}
function gt(t, n, r, o = 3) {
  const a = Z(n, 768), e = Z(r, 768), s = [];
  for (let i = -1; i <= 1; i += 1)
    for (let l = -1; l <= 1; l += 1) {
      const y = Lt(t, a + l, e + i, o);
      y && s.push(y);
    }
  return s;
}
function Ct(t, n, r) {
  const o = Z(n, 1024), a = Z(r, 1024);
  let e = null;
  for (let s = -1; s <= 1; s += 1)
    for (let i = -1; i <= 1; i += 1) {
      const l = o + i, y = a + s;
      if ($(t ^ 376493, l, y) < 0.84) continue;
      const L = Math.round((l + 0.18 + $(t ^ 529314, l, y) * 0.64) * 1024), m = Math.round((y + 0.18 + $(t ^ 327066, l, y) * 0.64) * 1024), f = j(t, L, m);
      if (f.terrainHeight > 23 || f.continentalness > 0.42) continue;
      const p = 28 + $(t ^ 66205, l, y) * 34, g = 24 + $(t ^ 93985, l, y) * 30, C = Math.hypot((n - L) / p, (r - m) / g);
      if (C > 1.15) continue;
      const R = Math.max(0, C - 1) * Math.max(p, g);
      (!e || R < e.distance) && (e = {
        kind: "lake",
        id: `lake:${l},${y}`,
        distance: R,
        water: C <= 1,
        waterLevel: V(f.terrainHeight + 1, 10, 23),
        direction: null,
        shoreDistance: (C - 1) * Math.max(p, g)
      });
    }
  return e;
}
function Et(t, n, r, o) {
  const a = Ct(t, n, r);
  if (a?.water) return a;
  let e = a;
  for (const s of gt(t, n, r, o)) {
    let i = 1 / 0, l = s.direction;
    for (let f = 1; f < s.path.length; f += 1) {
      const p = s.path[f - 1], g = s.path[f], C = yt(n, r, p[0], p[1], g[0], g[1]);
      C.distance < i && (i = C.distance, l = C.tangent);
    }
    const y = s.width + 4;
    if (i > y) continue;
    const L = Math.hypot(l[0], l[1]) || 1, m = [l[0] / L, l[1] / L];
    (!e || i < e.distance) && (e = {
      kind: "river",
      id: s.id,
      distance: i,
      water: i <= s.width,
      waterLevel: s.waterLevel,
      direction: m,
      shoreDistance: i - s.width
    });
  }
  return e ?? {
    kind: "dry",
    id: null,
    distance: 1 / 0,
    water: !1,
    waterLevel: null,
    direction: null,
    shoreDistance: 1 / 0
  };
}
function X(t, n, r, o = 3) {
  const a = j(t, n, r), e = Et(t, n, r, o);
  let s = a.terrainHeight;
  if (e.kind !== "dry" && e.waterLevel !== null)
    if (o < 3)
      s = Math.min(a.terrainHeight, e.waterLevel - (e.water ? 2 : 1));
    else if (e.water) s = Math.min(a.terrainHeight, e.waterLevel - 2);
    else {
      const f = Math.max(0, e.shoreDistance), p = e.waterLevel + Math.floor(Math.min(3, f) * 0.75);
      s = Math.max(e.waterLevel, Math.min(a.terrainHeight, p));
    }
  const i = Math.sin((r + (t & 65535) * 0.17) / 2600) * 0.18, l = V(
    0.62 + i + (T(t ^ 183017, n, r, 1300) * 2 - 1) * 0.24 - Math.max(0, s - 18) * 0.018,
    0,
    1
  ), y = e.kind === "dry" ? 0 : e.water ? 0.26 : 0.12, L = V(
    T(t ^ 560291, n, r, 960) * 0.72 + T(t ^ 109015, n, r, 300) * 0.28 + y,
    0,
    1
  );
  let m = "plains";
  return e.water || e.kind !== "dry" && L > 0.58 ? m = "wet" : l < 0.27 ? m = "cold" : L < 0.31 ? m = "dry" : a.relief > 0.66 || s > 29 ? m = "mountain" : L > 0.58 && (m = "forest"), {
    region: [Z(n, 256), Z(r, 256)],
    ...a,
    terrainHeight: s,
    temperature: l,
    humidity: L,
    biome: m,
    hydrology: e
  };
}
const c = 32, z = 3, M = {
  Air: 0,
  Grass: 1,
  Dirt: 2,
  Stone: 3,
  Wood: 4,
  Leaves: 5,
  Sand: 6,
  Snow: 7,
  Water: 8,
  Glowstone: 9,
  Lantern: 10
}, S = {
  GrassTop: 1,
  GrassSide: 2,
  Dirt: 3,
  Stone: 4,
  Sand: 5,
  WoodSide: 6,
  WoodEnd: 7,
  Leaves: 8,
  Snow: 9,
  Water: 10,
  Glowstone: 11,
  LanternFrame: 12,
  LanternGlow: 13
}, At = (t) => t !== M.Air && t !== M.Water, st = (t, n) => (t % n + n) % n, K = (t, n, r) => `${t},${n},${r}`, G = (t, n, r) => t + c * (r + c * n);
function bt(t, n, r) {
  return t === M.Grass ? n === 1 ? r ? S.GrassTop : S.Dirt : S.GrassSide : t === M.Wood ? n === 1 ? S.WoodEnd : S.WoodSide : {
    [M.Dirt]: S.Dirt,
    [M.Stone]: S.Stone,
    [M.Leaves]: S.Leaves,
    [M.Sand]: S.Sand,
    [M.Snow]: S.Snow,
    [M.Water]: S.Water,
    [M.Glowstone]: S.Glowstone,
    [M.Lantern]: S.LanternFrame
  }[t];
}
function Rt(t, n, r) {
  let o = (t ^ Math.imul(n, 374761393) ^ Math.imul(r, 668265263)) >>> 0;
  return o = Math.imul(o ^ o >>> 13, 1274126177) >>> 0, ((o ^ o >>> 16) >>> 0) / 4294967296;
}
function St(t, n, r, o) {
  const a = { forest: 0.968, plains: 0.987, wet: 0.981, mountain: 0.995 };
  return !o.hydrology.water && o.terrainHeight >= 15 && Rt(t ^ 17583, n, r) > (a[o.biome] ?? 1);
}
function it(t, n, r, o, a = X(t, n, o, z), e = (s, i) => X(t, s, i, z)) {
  const s = a.terrainHeight, i = a.biome;
  if (a.hydrology.water && a.hydrology.waterLevel !== null && r > s && r <= a.hydrology.waterLevel)
    return M.Water;
  if (r <= s)
    return r === s ? i === "dry" ? M.Sand : i === "cold" ? M.Snow : i === "mountain" ? M.Stone : M.Grass : r > s - 4 ? i === "dry" ? M.Sand : i === "mountain" ? M.Stone : M.Dirt : M.Stone;
  for (let l = n - 3; l <= n + 3; l += 1)
    for (let y = o - 3; y <= o + 3; y += 1) {
      const L = e(l, y);
      if (!St(t, l, y, L)) continue;
      const m = L.terrainHeight;
      if (n === l && o === y && r > m && r <= m + 4) return M.Wood;
      const f = Math.abs(n - l), p = Math.abs(o - y);
      if (f <= 2 && p <= 2 && r >= m + 3 && r <= m + 6 && (f + p < 4 || r >= m + 5)) return M.Leaves;
    }
  return M.Air;
}
const ht = (t, n) => t?.material === n.material && t.renderCategory === n.renderCategory && t.back === n.back && t.ao.every((r, o) => r === n.ao[o]) && t.fluidLevel === n.fluidLevel && t.fluidFloorHeight === n.fluidFloorHeight, kt = (t, n) => {
  if (n) return 1;
  const r = Math.max(1, Math.min(8, t));
  return r === 8 ? 7 / 8 : r / 8;
};
function _t(t, n, r, o, a) {
  return t === 1 || n !== M.Water || r !== M.Water || o === a ? null : {
    forward: o > a,
    back: a > o,
    high: Math.max(o, a),
    low: Math.min(o, a)
  };
}
function Wt(t, n, r, o, a, e) {
  if (t !== S.Water || n === 1 && r) return;
  const s = Math.max(e[1], e[4], e[7], e[10]), i = Math.min(e[1], e[4], e[7], e[10]);
  for (let l = 1; l < e.length; l += 3)
    e[l] === s ? e[l] = s + o - 1 : n !== 1 && e[l] === i && (e[l] = i + a);
}
function pt(t, n, r, o, a, e = z) {
  const s = new Uint16Array(c ** 3), i = n * c, l = r * c, y = o * c, L = /* @__PURE__ */ new Map(), m = (f, p) => {
    const g = K(f, 0, p);
    let C = L.get(g);
    return C || (C = X(t, f, p, e), L.set(g, C)), C;
  };
  for (let f = 0; f < c; f += 1)
    for (let p = 0; p < c; p += 1) {
      const g = m(i + p, y + f);
      for (let C = 0; C < c; C += 1)
        s[G(p, C, f)] = it(t, i + p, l + C, y + f, g, m);
    }
  for (const [f, p, g, C] of a)
    if (Math.floor(f / c) === n && Math.floor(p / c) === r && Math.floor(g / c) === o) {
      const R = (f % c + c) % c, F = (p % c + c) % c, E = (g % c + c) % c;
      s[G(R, F, E)] = C;
    }
  return s;
}
const Ft = [
  { min: [0.22, 0, 0.22], max: [0.78, 0.12, 0.78], material: S.LanternFrame },
  { min: [0.24, 0.68, 0.24], max: [0.76, 0.78, 0.76], material: S.LanternFrame },
  { min: [0.3, 0.14, 0.3], max: [0.7, 0.68, 0.7], material: S.LanternGlow },
  { min: [0.22, 0.1, 0.22], max: [0.29, 0.72, 0.29], material: S.LanternFrame },
  { min: [0.71, 0.1, 0.22], max: [0.78, 0.72, 0.29], material: S.LanternFrame },
  { min: [0.22, 0.1, 0.71], max: [0.29, 0.72, 0.78], material: S.LanternFrame },
  { min: [0.71, 0.1, 0.71], max: [0.78, 0.72, 0.78], material: S.LanternFrame },
  { min: [0.34, 0.76, 0.47], max: [0.4, 0.9, 0.53], material: S.LanternFrame },
  { min: [0.6, 0.76, 0.47], max: [0.66, 0.9, 0.53], material: S.LanternFrame },
  { min: [0.34, 0.88, 0.47], max: [0.66, 0.94, 0.53], material: S.LanternFrame }
];
function wt(t) {
  return t === M.Lantern ? Ft : [];
}
function Q(t) {
  return At(t) && t !== M.Lantern;
}
const mt = (t) => t === S.Water ? "transparent" : t === S.Leaves ? "cutout" : t === S.LanternGlow ? "emissive" : "opaque";
function Ot(t, n) {
  const r = (o, a) => {
    for (const e of wt(a))
      for (let s = 0; s < 3; s += 1) {
        const i = (s + 1) % 3, l = (s + 2) % 3, y = e.max[i] - e.min[i], L = e.max[l] - e.min[l];
        for (const m of [!0, !1]) {
          const f = [o[0] + e.min[0], o[1] + e.min[1], o[2] + e.min[2]];
          f[s] = o[s] + (m ? e.min[s] : e.max[s]);
          const p = [...f];
          p[i] += y;
          const g = [...p];
          g[l] += L;
          const C = [...f];
          C[l] += L;
          const R = [0, 0, 0];
          R[s] = m ? -1 : 1, n({
            material: e.material,
            positions: m ? [...f, ...C, ...g, ...p] : [...f, ...p, ...g, ...C],
            normal: R,
            dimension: s,
            width: y,
            height: L,
            back: m
          });
        }
      }
  };
  for (let o = 0; o < c; o += 1)
    for (let a = 0; a < c; a += 1)
      for (let e = 0; e < c; e += 1) r([e, o, a], t[G(e, o, a)]);
}
const ot = c + 2, et = (t, n, r) => t + 1 + ot * (r + 1 + ot * (n + 1)), vt = [255, 220, 190, 160], It = [
  [-1, -1],
  [1, -1],
  [1, 1],
  [-1, 1]
], Nt = [
  [-1, -1],
  [-1, 1],
  [1, 1],
  [1, -1]
];
function $t({
  seed: t,
  cx: n,
  cy: r,
  cz: o,
  generatorVersion: a = z,
  canonical: e = pt(t, n, r, o, [], a),
  overlays: s = [],
  fluid: i
}) {
  const l = new Map(
    s.map((E) => [K(E.cx, E.cy, E.cz), E.voxels])
  ), y = new Map(
    s.map((E) => [K(E.cx, E.cy, E.cz), E.fluid])
  ), L = /* @__PURE__ */ new Map();
  let m = 0;
  const f = (E, u) => {
    const h = `${E},${u}`;
    let w = L.get(h);
    return w || (w = X(t, E, u, a), L.set(h, w)), w;
  }, p = (E, u, h) => {
    const w = Math.floor(E / c), d = Math.floor(u / c), A = Math.floor(h / c);
    if (w === n && d === r && A === o)
      return e[G(E - n * c, u - r * c, h - o * c)];
    const b = l.get(K(w, d, A));
    return b ? b[G(
      (E % c + c) % c,
      (u % c + c) % c,
      (h % c + c) % c
    )] : (m += 1, it(t, E, u, h, f(E, h), f));
  }, g = new Uint16Array(ot ** 3), C = i?.slice() ?? Uint8Array.from(e, (E) => E === M.Water ? 136 : 0), R = new Uint8Array(ot ** 3);
  let F = 2166136261;
  for (let E = -1; E <= c; E += 1)
    for (let u = -1; u <= c; u += 1)
      for (let h = -1; h <= c; h += 1) {
        const w = p(n * c + h, r * c + E, o * c + u);
        g[et(h, E, u)] = w;
        const d = n * c + h, A = r * c + E, b = o * c + u, O = Math.floor(d / c), W = Math.floor(A / c), N = Math.floor(b / c), v = G(st(d, c), st(A, c), st(b, c)), k = O === n && W === r && N === o ? C[v] : y.get(K(O, W, N))?.[v];
        R[et(h, E, u)] = k ?? (w === M.Water ? 136 : 0), F = Math.imul(F ^ w, 16777619);
      }
  return {
    canonical: e,
    halo: g,
    fluid: C,
    fluidHalo: R,
    haloRevision: `${F >>> 0}`,
    proceduralVoxelSamples: m,
    macroContextCount: L.size
  };
}
const Gt = (t) => t !== M.Air && wt(t).length === 0, dt = (t, n) => Gt(t) && (t === M.Water ? n === M.Air || n !== M.Water && !Q(n) : n === M.Air || n === M.Water || !Q(n));
function Ut(t, n, r, o, a, e) {
  const s = a ? -1 : 1, i = [...t];
  return i[n] += s, (a ? Nt : It).map(([L, m]) => {
    const f = [...i];
    f[r] += L;
    const p = [...i];
    p[o] += m;
    const g = [...i];
    g[r] += L, g[o] += m;
    const C = Q(e(f[0], f[1], f[2])), R = Q(e(p[0], p[1], p[2]));
    return C && R ? 3 : Number(C) + Number(R) + Number(Q(e(g[0], g[1], g[2])));
  });
}
function Mt({
  seed: t,
  cx: n,
  cy: r,
  cz: o,
  data: a,
  changes: e,
  outside: s,
  halo: i,
  fluid: l,
  fluidHalo: y,
  generatorVersion: L = z
}) {
  const m = {}, f = new Map(e.map(([u, h, w, d]) => [`${u},${h},${w}`, d])), p = /* @__PURE__ */ new Map(), g = (u, h) => {
    const w = K(u, 0, h);
    let d = p.get(w);
    return d || (d = X(t, u, h, L), p.set(w, d)), d;
  }, C = (u, h, w) => {
    if (u >= 0 && h >= 0 && w >= 0 && u < c && h < c && w < c)
      return a[G(u, h, w)];
    const d = n * c + u, A = r * c + h, b = o * c + w;
    return i && u >= -1 && h >= -1 && w >= -1 && u <= c && h <= c && w <= c ? i[et(u, h, w)] : f.get(`${d},${A},${b}`) ?? s?.(d, A, b) ?? it(t, d, A, b, g(d, b), g);
  }, R = (u, h, w) => u >= 0 && h >= 0 && w >= 0 && u < c && h < c && w < c ? l?.[G(u, h, w)] ?? (a[G(u, h, w)] === M.Water ? 136 : 0) : y && u >= -1 && h >= -1 && w >= -1 && u <= c && h <= c && w <= c ? y[et(u, h, w)] : C(u, h, w) === M.Water ? 136 : 0, F = (u, h, w) => kt(Math.max(1, R(u, h, w) & 15), C(u, h + 1, w) === M.Water), E = (u, h, w, d, A, b, O, W, N, v) => {
    const k = m[u] ??= { p: [], n: [], uv: [], c: [], i: [] }, _ = k.p.length / 3;
    Wt(u, d, O, N, v, h), k.p.push(...h), k.n.push(...w, ...w, ...w, ...w), d === 0 ? k.uv.push(...O ? [0, 0, b, 0, b, A, 0, A] : [0, 0, 0, A, b, A, b, 0]) : k.uv.push(...O ? [0, 0, 0, b, A, b, A, 0] : [0, 0, A, 0, A, b, 0, b]);
    for (const H of W) {
      const I = vt[H];
      k.c.push(I, I, I, 255);
    }
    W[0] + W[2] > W[1] + W[3] ? k.i.push(_, _ + 1, _ + 3, _ + 1, _ + 2, _ + 3) : k.i.push(_, _ + 1, _ + 2, _, _ + 2, _ + 3);
  };
  for (let u = 0; u < 3; u += 1) {
    const h = (u + 1) % 3, w = (u + 2) % 3, d = [0, 0, 0], A = [0, 0, 0];
    A[u] = 1;
    const b = new Array(c * c);
    for (d[u] = -1; d[u] < c; ) {
      let O = 0;
      for (d[w] = 0; d[w] < c; d[w] += 1)
        for (d[h] = 0; d[h] < c; d[h] += 1) {
          const W = C(d[0], d[1], d[2]), N = C(d[0] + A[0], d[1] + A[1], d[2] + A[2]), v = W === M.Water ? F(d[0], d[1], d[2]) : 0, k = N === M.Water ? F(d[0] + A[0], d[1] + A[1], d[2] + A[2]) : 0, _ = _t(u, W, N, v, k), H = _?.forward ?? dt(W, N), I = _?.back ?? (!H && dt(N, W));
          if (!H && !I) {
            b[O++] = null;
            continue;
          }
          const x = I ? N : W, Y = [...d];
          I && (Y[u] += 1);
          const J = bt(x, u, !I);
          b[O++] = {
            material: J,
            renderCategory: mt(J),
            back: I,
            ao: x === M.Water ? [0, 0, 0, 0] : Ut(Y, u, h, w, I, C),
            fluidLevel: x === M.Water ? _?.high ?? (I ? k : v) : 0,
            fluidFloorHeight: _?.low ?? 0
          };
        }
      d[u] += 1, O = 0;
      for (let W = 0; W < c; W += 1)
        for (let N = 0; N < c; ) {
          const v = b[O];
          if (!v) {
            N += 1, O += 1;
            continue;
          }
          let k = 1;
          for (; N + k < c && ht(b[O + k], v); ) k += 1;
          let _ = 1;
          t: for (; W + _ < c; _ += 1)
            for (let D = 0; D < k; D += 1)
              if (!ht(b[O + D + _ * c], v)) break t;
          d[h] = N, d[w] = W;
          const H = [0, 0, 0], I = [0, 0, 0];
          H[h] = k, I[w] = _;
          const x = [d[0], d[1], d[2]], Y = [d[0] + H[0], d[1] + H[1], d[2] + H[2]], J = [d[0] + H[0] + I[0], d[1] + H[1] + I[1], d[2] + H[2] + I[2]], lt = [d[0] + I[0], d[1] + I[1], d[2] + I[2]], ut = [0, 0, 0];
          ut[u] = v.back ? -1 : 1, E(
            v.material,
            v.back ? [...x, ...lt, ...J, ...Y] : [...x, ...Y, ...J, ...lt],
            ut,
            u,
            k,
            _,
            v.back,
            v.ao,
            v.fluidLevel,
            v.fluidFloorHeight
          );
          for (let D = 0; D < _; D += 1)
            for (let at = 0; at < k; at += 1) b[O + at + D * c] = null;
          N += k, O += k;
        }
    }
  }
  return Ot(
    a,
    (u) => E(
      u.material,
      u.positions,
      u.normal,
      u.dimension,
      u.width,
      u.height,
      u.back,
      [0, 0, 0, 0],
      0,
      0
    )
  ), Object.fromEntries(
    Object.entries(m).map(([u, h]) => {
      const w = Number(u);
      return [
        w,
        {
          material: w,
          renderCategory: mt(w),
          layout: "float32",
          positions: new Float32Array(h.p),
          normals: new Float32Array(h.n),
          uvs: new Float32Array(h.uv),
          colors: new Uint8Array(h.c),
          indices: new Uint32Array(h.i)
        }
      ];
    })
  );
}
const Ht = c ** 3, Tt = (t) => t % 3 === 0 ? 2 : 3;
function Dt(t, n, r, o) {
  const a = [0, 0, 1, 8, 64][t % 5], e = [M.Air, M.Stone, M.Water, M.Lantern];
  return Array.from({ length: a }, (s, i) => {
    const l = (t * 977 + i * 509) % Ht, y = l % c, L = Math.floor(l / c) % c, m = Math.floor(l / (c * c));
    return [
      n * c + y,
      r * c + m,
      o * c + L,
      e[(t + i) % e.length]
    ];
  });
}
const Vt = (t, n, r, o, a) => {
  for (const [e, s, i, l] of n)
    t[G(e - r * c, s - o * c, i - a * c)] = l;
};
function xt(t, n, r, o, a, e, s) {
  const i = pt(n, r, o, a, [], s);
  let l = Uint8Array.from(i, (m) => m === M.Water ? 136 : 0);
  if (e % 5 === 0) {
    const m = 18 + e % 7;
    for (let f = 5; f < 27; f += 1)
      for (let p = 5; p < 27; p += 1) {
        const g = G(p, m, f);
        if (i[g] = M.Water, l[g] = 128 | (p + f + e) % 8 | 1, e % 3 === 0 && (p + f) % 5 === 0) {
          const C = G(p, m + 1, f);
          i[C] = M.Water, l[C] = 136;
        }
      }
    i[G(16, m + 2, 16)] = M.Lantern;
  } else {
    const m = e % 15;
    if (m === 0) i.fill(M.Air);
    else if (m === 1) i.fill(M.Stone);
    else if (m === 2)
      for (let f = 0; f < c; f += 1)
        for (let p = 0; p < c; p += 1)
          for (let g = 0; g < c; g += 1)
            i[G(g, f, p)] = (g + f + p + e) % 2 ? M.Stone : M.Air;
    else m >= 3 && m <= 5 && Vt(i, Dt(e + 1, r, o, a), r, o, a);
    l = Uint8Array.from(i, (f) => f === M.Water ? 136 : 0);
  }
  const L = $t({ seed: n, cx: r, cy: o, cz: a, canonical: i, fluid: l, generatorVersion: s });
  return {
    seed: n,
    cx: r,
    cy: o,
    cz: a,
    data: i,
    changes: [],
    halo: L.halo,
    fluid: L.fluid,
    fluidHalo: L.fluidHalo,
    generatorVersion: s
  };
}
function Bt(t, n = 30) {
  return Array.from({ length: n }, (r, o) => {
    const a = 18374655 + o % 10 * 1009 >>> 0, e = o % 5 - 2, s = o % 3 === 0 ? 1 : 0, i = o % 7 - 3, l = Tt(o), y = xt(t, a, e, s, i, o, l);
    return { kind: "w06", parts: Object.values(Mt(y)) };
  });
}
const rt = new Worker(new URL(
  /* @vite-ignore */
  "" + new URL("assets/simd-worker-BbCba1MD.js", import.meta.url).href,
  import.meta.url
), { type: "module" });
let jt = 0;
const tt = /* @__PURE__ */ new Map();
rt.onmessage = (t) => {
  const n = tt.get(t.data.id);
  tt.delete(t.data.id), t.data.error ? n?.reject(new Error(t.data.error)) : n?.resolve(t.data);
};
rt.onerror = (t) => {
  for (const n of tt.values()) n.reject(new Error(t.message));
  tt.clear();
};
function ct(t, n = /* @__PURE__ */ new Set()) {
  if (ArrayBuffer.isView(t) && t.buffer instanceof ArrayBuffer) n.add(t.buffer);
  else if (t && typeof t == "object") for (const r of Object.values(t)) ct(r, n);
  return [...n];
}
function q(t, n, r = !1) {
  return new Promise((o, a) => {
    const e = ++jt;
    tt.set(e, { resolve: o, reject: a }), rt.postMessage({ id: e, input: t, mode: n, micro: r }, ct(t));
  });
}
function nt(t) {
  let n = 2166136261;
  const r = new TextEncoder();
  function o(a) {
    if (ArrayBuffer.isView(a))
      for (const e of new Uint8Array(a.buffer, a.byteOffset, a.byteLength))
        n = Math.imul(n ^ e, 16777619);
    else if (a && typeof a == "object")
      for (const e of Object.keys(a).sort())
        o(e), o(a[e]);
    else for (const e of r.encode(String(a))) n = Math.imul(n ^ e, 16777619);
  }
  return o(t), n >>> 0;
}
let U = [], P = [];
async function Kt(t) {
  const n = await q();
  if (t === "mesh-natural")
    U = Bt("w06").filter((o) => o.kind === "w06").map((o) => ({ kind: "mesh", parts: o.parts }));
  else if (t === "mesh-stress") {
    const o = new Uint16Array(32768);
    for (let e = 5; e < 11; e++)
      for (let s = 0; s < 32; s++) for (let i = 0; i < 32; i++) (i + e + s) % 2 && (o[i + 32 * (s + 32 * e)] = 1);
    U = [{ kind: "mesh", parts: Object.values(Mt({ seed: 1, cx: 0, cy: 0, cz: 0, data: o, changes: [], outside: () => 0 })) }];
  } else {
    const [o, a] = t.split("-"), e = Number(a);
    U = Array.from({ length: 10 }, (s, i) => ({
      kind: o,
      values: o === "occupancy" ? Uint16Array.from({ length: e }, (l, y) => (y * 17 + i) % 11) : Uint32Array.from(
        { length: e },
        (l, y) => o === "uv" ? y * 65537 + i * 191 >>> 0 : o === "indices" ? y % 65536 : y * 33554467 + i >>> 0
      )
    }));
  }
  P = [];
  const r = [];
  for (const [o, a] of U.entries()) {
    const e = a.kind === "mesh" ? "staged" : "ts";
    if (P.push(nt((await q(structuredClone(a), e)).result)), a.kind === "mesh")
      try {
        if (nt((await q(structuredClone(a), "ts")).result) !== P[o])
          throw new Error("legacy mismatch");
      } catch (s) {
        r.push(`${o}: ${s}`);
      }
  }
  for (const o of ["scalar", "simd"])
    for (let a = 0; a < U.length; a++)
      if (nt((await q(structuredClone(U[a]), o)).result) !== P[a])
        throw new Error(`${t}/${o} correctness mismatch ${a}`);
  return {
    initialization: n,
    legacyFailures: r,
    tsControl: U[0].kind === "mesh" ? "same-layout TS arena control; legacy results separately validated where executable" : "numeric TS loop",
    corpusCount: U.length,
    inputBytes: U.map((o) => ct(o).reduce((a, e) => a + e.byteLength, 0)),
    crossOriginIsolated,
    hardwareConcurrency: navigator.hardwareConcurrency
  };
}
async function qt(t, n = 5e3, r = 1e3) {
  async function o(l) {
    const y = U[l % U.length], L = performance.now(), m = structuredClone(y), f = performance.now(), p = await q(m, t), g = performance.now();
    if (nt(p.result) !== P[l % P.length]) throw new Error("sample mismatch");
    return {
      prepareMs: f - L,
      roundtripMs: g - f,
      endToEndMs: g - L,
      computeMs: p.computeMs ?? 0,
      memoryBytes: p.memoryBytes,
      outputBytes: p.outputBytes ?? 0
    };
  }
  let a = 0;
  const e = performance.now();
  for (; a < 20 || performance.now() - e < n; ) await o(a++);
  const s = [];
  for (let l = 0; l < r; l++) s.push(await o(l));
  const i = [];
  if (U[0].kind !== "mesh" && t !== "ts")
    for (const l of U) i.push(await q(structuredClone(l), t, !0));
  return { samples: s, cores: i, warmed: a, visibility: document.visibilityState };
}
function Pt() {
  rt.terminate();
}
export {
  Pt as dispose,
  Kt as prepare,
  qt as sample
};
//# sourceMappingURL=simd-entry.js.map
