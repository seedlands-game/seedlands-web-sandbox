# Change — 当前主线 Change 基线冻结归档

> 状态：Delivered（本地基线归档完成；PR 交接以最终远端读回为准）/ Agile；冻结来源为 `main` 的 `5a5f0a5ea7e4a8e59597cb9c575b37997f4a933d`（PR #33 合并提交）。

## 目标与边界

将该提交中仍留在 `changes/` 的历史 change 作为**原样基线快照**批量归档，而不是把每份原始合同改写成 `Delivered`。原有状态、批准 hash、失败、未执行与延期证据逐字保留。归档是本地可恢复的仓库整理，不声明 Classic、NPC、浏览器、性能或人工验收补齐，也不改变生产代码、测试集合、CI 门禁或分支保护。PR #36 继续承接 Classic 延期验证。

## 可验证行为与实施前 RED

- Given 干净的冻结提交及多个 `changes/` 目录（即使旧状态为 Active/Proposed），When 明确以该提交执行 `freeze`，Then 工具收集该提交中的全部 change 目录，逐文件生成 SHA-256 manifest，先验证 ZIP 再移走原目录；新增归档任务目录不属于该旧提交，保留原位。现有工具不认识 `freeze`，先取得可执行 RED。
- Given HEAD 不等于冻结 SHA、目标文件与 Git tree 不一致、额外文件、符号链接、活跃运行引用或已存在目标 ZIP，When 执行 `freeze`，Then 拒绝并保留原目录。既有 `archive` 仍只接受明确 `Delivered`，不被此模式放宽。
- Given 长期文档或活跃测试仍链接将移走的 change，When 准备归档，Then 将当前规范迁到长期 docs，历史证据改用冻结 SHA 的不可变源码链接，或明确保留依赖目录；完成后不存在断开的本地 change 链接。

## 交付门禁

- [x] `freeze` 正反例 RED→GREEN，原 `archive` 安全回归通过。
- [x] 104 个基线 change 的来源树、文件数、manifest、ZIP SHA-256 与恢复操作读回；旧目录清空，不修改旧 spec 原字节。
- [x] 长期 docs、AGENTS、README 与测试引用收口；`docs/change-archive.md` 登记冻结 SHA、归档状态语义及恢复方式。
- [x] 本 change 的本地交付记录完成，归档后 `changes/` 无剩余目录。
- [ ] 功能分支提交、推送、创建 PR，读回远端 SHA、source/target、URL 与当前 gate 快照；这是归档之后的 Git 交接，不外推为产品验收。

长期 docs baseline 更新归档索引和当前规范链接；这项整理不提供新的产品行为验收证据。未知耗时和成本不填零。

## Delivery Snapshot（本地）

- 冻结源 `5a5f0a5ea7e4a8e59597cb9c575b37997f4a933d`，合并 PR #33 已读回 `MERGED`；三个当前检查 Architecture static checks、Deterministic module tests、Static verification 均为 SUCCESS。延期验证 [Draft PR #36](https://github.com/seedlands-game/seedlands-web-sandbox/pull/36) 仍 OPEN，不在本批验收。
- 初始 104 个 Git 跟踪的 change 目录无源修改；`freeze` 生成 `2026-09-16-main-architecture-baseline.zip`，SHA-256 `d7ec12a5b3f85e984892079a8cbbb99a262ca982823197046151d1dcbff49b8e`。manifest 标记 `baseline-freeze`、来源 SHA、104 个目录和 1351 个文件；独立 `verify` exit 0。实际 `extract` 到一次性目录后读回 104/1351，完成后清理该临时恢复目录。
- #33 的原批准 `spec.md` 在 ZIP 和恢复目录中的 SHA-256 均为 `c1d8ef071a3a48db32ee4750b7771df0dc934baada55567fb880da9e56f8041e`。历史状态和未执行项未改写；本归档不证明 Classic、NPC、浏览器、性能或使用者体验。
- 归档工具合成 fixture 首先因未知 `freeze` 命令取得 RED；实现后定向 8/8 PASS，含原 Delivered 入口、符号链接、越界、ZIP 与覆盖拒绝。`pnpm verify:static:ci` exit 0；`pnpm test:deterministic:ci` exit 0，Kernel 28/28、stdlib 530/530。`packages/eslint-plugin` 66/66 通过。以上为本地仓库静态和确定性证据，不是远端当前 SHA 的 CI 结果。
- 长期 docs baseline 更新：归档索引新增现状快照及未闭合入口，当前规则从历史 change 改指长期文档，历史链接固定到来源提交；仅静态归档工具和测试夹具改变。实际独占 Agent 工时、credits/API 等价费用与订阅消耗不可可信归因，记为 unknown。
