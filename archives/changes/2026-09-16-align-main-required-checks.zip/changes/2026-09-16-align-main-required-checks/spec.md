# 对齐 main 的 required checks 与架构冻结阶段 CI

状态：Delivered（Agile）

## 目标与范围

解除 PR #39 因过时 required check 名称造成的永久 pending，同时保留 `main` 的真实静态和确定性测试门禁。只修改 GitHub 仓库 ruleset `Protect main`（ID `22265662`）中的 `required_status_checks` 列表，并同步长期 CI 文档；不修改 CI job、其他规则、bypass actor、branch target，不恢复生产构建或 Chromium 回归，也不合并 PR。

## 决定与行为

当前架构冻结阶段的汇总 check 为 `Static verification`，它依赖 `Architecture static checks` 和 `Deterministic module tests` 成功。`Production build` 与 `Chromium regression` 在本阶段不运行，不能以空 job 代替。

- Given `Protect main` 当前要求 `Static verification`、`Production build`、`Chromium regression`，When 读取 PR #39 的 head 检查，Then 仅前者有真实成功结果，PR 因后两项 pending 而 BLOCKED（实施前 RED）。
- Given 上述状态，When 更新 ruleset，Then required 列表仅为 `Static verification`，其余规则、条件、执行状态与 bypass actor 不变。
- Given PR #39 当前 head 的 `Static verification` 成功，When GitHub 重新计算保护规则，Then 不再因缺失 `Production build` / `Chromium regression` 阻塞；其他 review 或合并门禁仍独立生效。

## 实施前测试设计与验收

1. 读取 live ruleset、PR head SHA 与各 check 结果，记录 RED；写入前断言 ruleset 精确匹配预期旧列表，避免并发改动被覆盖。
2. 用 GitHub ruleset 更新接口只替换 required status checks，保留其余可写字段；更新后重新 GET，并比较所有非目标字段。
3. 重新读取 PR #39 的 check 与 merge state，检查 pending 是否消失；不以 mergeable 或 CI 绿色声称产品 E2E 已通过。
4. 更新 `docs/ci-testing.md`，运行文档/归档校验；把本 change 以普通 Delivered 模式冻结归档，确保活跃 `changes/` 无残留。

## 证据与任务

- [x] RED：PR #39 head `ff68b0722e1fdae64f5ec5156806ff516bc5f63e` 的三个真实检查均 SUCCESS，但 `Protect main` 仍要求两个不存在的 check，`mergeStateStatus=BLOCKED`。
- [x] ruleset 写入与逐字段读回：ID `22265662` 的 required 列表只剩 `Static verification`；name、target、enforcement、conditions、bypass actors 及其他 rules 与更新前逐字段一致。
- [x] PR 门禁读回：`gh pr checks 39 --required` 仅显示成功的 `Static verification`，两个缺失 check 不再列为 required。PR 总体仍为 `BLOCKED`：GraphQL 返回 1 个未解决 review thread，且规则仍要求 thread resolution；没有绕过该门禁。
- [x] 文档同步；归档验证结果见下方快照。

## Delivery Snapshot

2026-09-16 live ruleset 更新完成，规则集仍为 active，required 列表从三项收敛为 `Static verification` 一项，其他配置读回一致。PR #39 的真实 `Static verification` 成功，过时 required check 阻塞已解除；总体 `BLOCKED` 另由未解决 review thread 造成，仍需人类处理。长期 docs baseline 已更新 `docs/ci-testing.md`，因为这条门禁口径跨 change 生效。未执行生产构建、Chromium、Classic 行为或产品验收；本次不声称这些验证通过。归档包与校验将在本 change 归档时记录到 `docs/change-archive.md`。
