# 对象外观与统一资产生产

状态：Delivered（实现与本地证据已交付；远端准出见PR实时检查）。类型：Breaking。用户已明确批准收拢此前方案、按设计与优化边界实施，并要求灯笼MVP通过后直接推广全部现有素材；本合同记录该明确授权，不重复要求hash确认。基线68bf592，既有PR #16尚未合并，本change在其上叠加独立分支交付，不自动合并。

## 目标与决定

统一入口 → 对象外观引用 → 可编辑模型/材质/图像源 → 可重建运行网格/纹理数组/图集/缩略图 → 版本化资源包 → 按需GPU资源。先验证灯笼，再覆盖当前全部108项内置资产、原生草稿和导入模型。用户导航不再暴露九种内部适配类型；底层保留必要的表示方式与能力限制。

每个资源只有一个编辑源；引用复用、显式覆盖、草稿与应用快照分离。世界/碰撞/方块ID仍由原owner管理；普通方块保持Chunk Mesh。GLB仅静态支持，不因导入自动注册玩法。GPU对象不持久化、不跨Application复用。

## Scope

- 对象外观/资源库工作区：同页材质槽、纹理编辑、预览和用途信息，保持模型视角；全量目录覆盖，来源与类型筛选分离。
- 灯笼纯几何同源，放置/手持/掉落/图标复用；普通方块物品使用同源面材质；兼容静态部件合并、共享缓存和引用释放。
- 统一外观项目覆盖：模型材质与像素源可编辑、共享与对象专用覆盖明确；预览、保存、应用、恢复分别可见。像素源保持16默认，不降采样旧32/64；高清缩略图独立生成。
- 项目包导出恢复包含必要源、引用和GLB；校验失败/版本冲突不留下部分应用。旧库保留读取能力，不覆盖用户无关世界。
- GLB稳定ID重导入，revision变化，失败保留原模型；不支持的材质槽/用途有明确反馈。
- 同引擎缩略图与模型预览/运行使用相同资源；全部内置对象进入统一工作流，能力不支持的操作说明边界。
- Blender已有CLI配方和导出验证纳入可复现项目脚本/说明；不新增MCP/Blender/Blockbench依赖安装。
- noa优化：共享几何、兼容材质分组、派生失效与释放纳入主线；灯笼实例化为有界A/B，若收益不足或占用验收缓冲则不启用并记录结论。

## 非目标

骨骼动画、完整DCC/Prefab/玩法编辑、任意GLB替换地形、服务器同步、空块/同质层mesher优化、halo与大坐标重定位、GPU后端迁移。统一管理不等于所有源在浏览器内都能编辑任意几何。

## Behaviour / Test Design

1. Given灯笼，When编辑材质并预览/保存/应用/刷新/恢复，Then放置、手持、掉落和图标引用正确，失败保留最后可用快照；真实浏览器与运行截图验收。
2. Given共享材质，When修改共享或复制专用覆盖，Then影响范围正确，专用覆盖不污染其他对象；确定性引用/版本与浏览器编辑验收。
3. Given全量内置目录，When进入对象与资源库，Then旧ID全部可定位、内部来源类型不占主筛选、模型关联编辑不丢选择与视角。
4. Given项目包，When空库恢复，Then源、绑定与导入GLB一致；缺引用、超限、无效GLB和版本冲突拒绝写入；应用快照完整切换。
5. GivenGLB重导入，ThenID稳定、revision递增、预览失效重载，非法输入不覆盖旧文件。
6. Given模型复用和反复切换/卸载，Then兼容网格缓存共享、资源最终释放、异步陈旧结果不提交。
7. Given同源灯笼，When对照Chunk合批与实例化，Then固定模型/材质/镜头比较draw call、bytes、CPU帧耗时、编辑延迟和释放；不以算法名称冒充收益，不降低AO/画质来通过。

## RED与验收

实施前观察：灯笼两份几何；九类型菜单；材质不可编辑且沿依赖跳页；GLB只能新ID导入；无完整外观项目包。新增测试先获得RED。灯笼MVP须经确定性测试+浏览器保存应用恢复，再推广全素材；全量阶段重复相同合同并验证地形、工具、角色/手臂和图像能力。

最终运行pnpm verify:static与pnpm build，显式运行本change Playwright；视觉使用seedlands-evidence。所有结果按静态/浏览器/视觉/性能分别报告。性能不承诺改善，无收益保留原路径。预算保留验证缓冲，不以花完配额或耗尽时间为目标；本次起始共享周用量2%，账户变化非本任务精确成本。

## Tasks

- [x] 灯笼同源与共享模型RED/GREEN
- [x] 外观项目、编辑应用与灯笼浏览器MVP
- [x] 全量素材纳管与能力验收
- [x] 包恢复/GLB重导入/高清缩略图
- [x] noa有界实验与采用结论
- [x] static/build/浏览器/文档/语义commit/PR

## Delivery Snapshot

实现与本地验收已完成。生产实现提交`ed61d4a`，Blender配方提交`4494cd1`；[PR #18](https://github.com/seedlands-game/seedlands-web-sandbox/pull/18)已创建且为ready for review，远端CI以PR最新HEAD的实时检查为准，人类审核和合并仍待完成。独立分支`codex/asset-appearance-center`，目标base为仍打开的PR #16分支`codex/unified-visual-assets`。长期docs baseline已更新：`docs/asset-workbench.md`记录分层、能力、快照/项目包与GPU所有权，`docs/code-map.md`更新入口，`docs/blender-asset-production.md`及`ASSETS.md`记录可复现源和许可。世界、协议及Chunk实现没有扩展。

主任务请求Astra/high；方案固定Sol/xhigh只读复核沿用此前结论，边界清晰的实现由Terra/high子任务参与，主任务完成集成与最终浏览器验证。账户共享周用量从起始2%到收尾5%，变化3个百分点包含其他任务，不能视为本任务精确消耗；未以花完30%为目标。

| 验收层  | 结果与证据                                                                                                                                                                                        |
| ------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| 静态    | `pnpm verify:static`通过：196文件通过、2跳过；912测试通过、4跳过；world行覆盖96.89%；Svelte/TypeScript无错误                                                                                      |
| 构建    | `pnpm build`及`SEEDLANDS_BASE_PATH=/seedlands-web-sandbox/ pnpm build`均通过；已有大chunk提示不影响构建                                                                                           |
| 浏览器  | 本change 6项Playwright通过；追加64px实际游戏与GLB截图复验2项通过；长期核心Chromium回归8项通过。19对象均有渲染网格，资源分类合计108                                                                |
| 存储    | 空浏览器上下文导入后GLB字节和ID/revision一致；并发CAS只成功一个；注入模型写入失败时整个应用快照回滚；重导入使陈旧项目保存失败                                                                     |
| 视觉    | [实际游戏](evidence/lantern-game.png)、[同页专用材质](evidence/actor-private-material.png)、[Blender导入](evidence/blender-lantern.png)、[生产入口](evidence/appearance-production.png)已逐张检视 |
| 清晰度  | 64×64像素源进入实际地形纹理数组后仍为64×64，贴图首像素与物品/世界gloss一致；10张图标均512×512；生产子路径加载无404或页面错误                                                                      |
| Blender | 5.2.1 LTS后台重新生成14452B/168三角形GLB，SHA与仓库样例完全相同；[生成报告](evidence/blender-generation.json)                                                                                     |
| Noa实验 | 16组合采集成功，64盏两图SHA一致；实例化未减少draw call，无整帧收益证据，生产不启用；[详细口径](lantern-instancing-report.md)                                                                      |

复现当前需求：`SEEDLANDS_E2E_PORT=4185 pnpm exec playwright test changes/2026-09-08-asset-appearance-center/e2e --project=chromium --workers=1 --output=test-results/appearance-center`。需求测试继续留在本change，不未经独立长期价值评审晋升核心回归。正式Pages发布和人类审核不属于本地验收。

补充部署观察：子路径构建必须以相同`SEEDLANDS_BASE_PATH`运行Vite preview；首次使用默认base预览子路径导致入口回退，纠正预览参数后实际页面、19对象与10张512图标均通过。该环境配置失配未通过修改产品路径规避。

## 灯笼MVP检查点（2026-09-08）

定向几何/UV测试先RED后GREEN，物品UV逐面严格等于单灯笼meshChunk的Float32输出；浏览器渲染检查通过。`e2e/lantern-mvp.spec.ts`在真实WebGL2中经UI改像素与粗糙度、保存草稿（applied不变）、应用、刷新四上下文、恢复上一版均通过，并进入实际Harness世界读回放置纹理数组与手持/掉落模型材质：首像素[209,167,106,255]，双方gloss=0.75，快捷栏512px。10张派生缩略图均为512×512。该检查点后推进全量素材。

已明确的能力边界：方块/灯笼材质与放置批次共享，编辑同步所有引用；其专用绑定暂不开放且包验证拒绝，避免编辑器表现与地形不一致。角色、手臂、浆果和木板支持专用副本。运行材质源限16/32/64像素源，PNG/JPEG作为独立图像管理；静态GLB的内嵌材质由外部重导入维护。
