# 三包迁移实施记录

## M0：迁移前 RED

- 合同检查点：`b1c8d06`；实现合同 SHA-256：`7c29f9f57b2e908dc6253b8e149b207a63ec3ceaedb0060a83cc73b5d9652bf5`。
- 环境：macOS arm64，Node `v22.23.2`，pnpm `11.25.0`。
- 命令：`pnpm exec vitest run tests/governance/monorepo-package-boundaries.test.ts --no-file-parallelism --maxWorkers=1`。
- 结果：预期 RED，1 个文件中 4/4 用例失败。工作区尚未声明 `apps/*`、`packages/*`，三个 package manifest 与 core 专用 tsconfig 均不存在。
- 原始日志：`/tmp/seedlands-monorepo/m0-red.log`。

后续阶段只在新增事实形成后追加，不覆盖本次 RED。

## M0：合入最新 main

- 合入：以普通 merge 将 `origin/main@5557f34` 合入本分支；冲突文件为 `package.json`、`eslint.config.mjs`、`docs/collaboration-routing.md`、`src/client/compute/compute-worker-pool.ts`、`src/worker/world-compute-task.ts`。
- 语义整合：保留 Node `logic` lane、running byte 账本与 `failLane`；浏览器池拒绝 logic lane，并同时保留 Worker ready/失败回退诊断。终止与故障回调前先物理摘除 slot/Worker，避免回调再入恢复旧资源。完整 Authority mesh 输入继续严格校验并直接消费 canonical/fluid，不调用生成回退；普通输入仍可使用 main 注入的 TS/Wasm kernels。
- 自动合并复核：`authority-runtime` 同时保留无快照实体更新、宿主激活/输入清理提交和不可用 action 的提交前副本；task queue 同时保留上述 Node 资源合同与 main 的 lane 失效传播。
- 定向单元：8 文件、45 项通过；日志 `/tmp/seedlands-monorepo/m0-focused.log`。
- 生产源码静态：Svelte 0 error/0 warning、生产 `tsc --noEmit` 与冲突相关 ESLint 通过；日志 `/tmp/seedlands-monorepo/m0-static-focused.log`。
- Web 兼容构建：Rust artifact 指纹、预渲染检查及 Vite production build 通过。Node 五入口构建通过；日志 `/tmp/seedlands-monorepo/m0-builds.log`。
- 浏览器回归：当前 14 项 Chromium regression 全部通过，覆盖预加载/预渲染和 8 项长期游戏旅程；日志 `/tmp/seedlands-monorepo/m0-browser-regression.log`。
- Node 产物：五入口真实启动/关停/恢复与 SIGKILL durable 恢复 4/4 通过；日志 `/tmp/seedlands-monorepo/m0-node-artifact.log`。
- `pnpm typecheck` 的生产检查通过，但历史 Delivered 数据平面对照源码中的绝对 `/tmp/seedlands-adoption-baseline` 在本机仍存在，使 8 个 `@ts-expect-error` 变为 unused；原始日志 `/tmp/seedlands-monorepo/m0-typecheck.log`。这不是合入行为错误；M1 以包级类型入口排除冻结实验的临时绝对路径依赖。

## M1：三包源码、依赖与平台边界

- 建立 `apps/web`、`apps/node-server`、`packages/game-core` 三个 workspace 包。浏览器源码、Vite 入口与资产归 Web；Node CLI、线程、子进程、文件与锁适配归 Node；世界、物理、运行时、权威规则和纯计算任务归 core。Web 与 Node 仅经 `@seedlands/game-core` 的分域 subpath exports 消费共享逻辑。
- core 的 TypeScript 环境仅含 `ES2022`，不含 DOM、WebWorker 或 Node ambient types。需要克隆、UTF-8 fatal 解码、取消、单调计时、timeout 与 yield 的纯逻辑通过只读实例端口获得能力；浏览器、Node、测试入口分别注入真实 `structuredClone`、复用的 `TextEncoder`/fatal `TextDecoder`、`AbortController` 与 `performance.now`，没有可重配共享全局或算法降级。
- Web 源码类型检查使用 `vite/client`，Vite/SSG 工具配置由独立 `tsconfig.tools.json` 获得 Node 类型。Node 构建的 metafile 明确拒绝 `apps/web`、PlayCanvas、Svelte、Tone 与 Vite 产品依赖。
- 三包类型检查和构建通过；Web production build 保留 Rust 指纹、预渲染和默认/TS 回退代码路径，Node 构建生成五个独立 ESM 入口。日志：`/tmp/seedlands-monorepo/m1-typecheck.log`、`m1-build-core.log`、`m1-build-web.log`、`m1-build-node.log`。
- 包级测试按职责通过：core 90 个文件、595 项通过且 4 项既有 skip；Web 107 个文件、409 项通过；Node 21 个文件、124 项通过。引用浏览器 Wasm wrapper 的 world/server 等价测试归 Web，根级完整回归入口未缩减。日志：`/tmp/seedlands-monorepo/m1-core-test.log`、`m1-web-test.log`、`m1-node-test.log`。
- 包边界及 world/runtime/Node 静态定向检查 4 个文件、22 项通过；ESLint 与路径 lint 通过。全仓 coverage、临时目录隔离安装、浏览器回归和真实 Node 产物恢复将在 M2 冻结验收，不以本检查点替代。

## M2：审阅修复与隔离检查点

- 独立审阅指出 M1 只有 manifest 正向断言，未普遍拒绝跨包文件路径和未声明依赖。新增 `seedlands/package-boundary` 规则：按 importer 的真实绝对路径解析 workspace 所有权，拒绝跨包相对/file 路径、core 反向依赖、Web/Node 互依、未声明 workspace/外部产品依赖和未导出的 core subpath。9 项 manifest/正反例通过，规则纳入根 ESLint。
- 修复异步 restore/bootstrap 期间的 Authority 启动时钟漂移：独立可选 `startClock` 只在 Web 与 Dedicated 显式传入，bootstrap 完成后重锚；Headless 保持从 0 开始的虚拟时钟。延迟 restore 5 秒的测试先得到 `physicsTick=4` 的 RED，修复后首次增加 20ms 只推进 1 tick；日志 `/tmp/seedlands-monorepo/m2-bootstrap-clock-red.log`、`m2-bootstrap-clock-green.log`。同时恢复 Headless 纯计算 checkpoint 的微任务 yield，仅等待在途事务时保留平台宏任务 yield。
- Active Node 的 20 个测试源码由 `tsconfig.active-node-tests.json` 全部类型检查；外部 `/tmp` 语料用例仍保持原 fail-closed 合同，不宣称本轮执行。4 个无需外部冻结语料的关键链路组成 `test:active-node:critical`，覆盖完整 Authority baseline 零生成回退、调度失效与资源结算、reference 消费和 worker input settlement，35/35 通过；日志 `/tmp/seedlands-monorepo/m2-active-node-typecheck.log`、`m2-active-node-critical.log`。
- `verify:node-isolation` 在 `/tmp/seedlands-monorepo/node-isolation` 只复制 core、Node manifests/源码和基础配置，以 Node `v22.23.2` 重新安装、类型检查并生成五入口产物，再把 `dist` 单独复制后运行 CLI。隔离目录没有 Web 源码、没有复用根 `node_modules`，且未安装 PlayCanvas/Svelte/Tone；Vitest 的 Vite 传递依赖单独记为共享测试工具。日志 `/tmp/seedlands-monorepo/m2-node-isolation.log`，结构化报告 `/tmp/seedlands-monorepo/node-isolation-report.json`。
- CI 已分别构建 core、Web、Node，上传路径改为 `apps/web/dist`，并加入 Node 隔离检查与 portable Active Node 关键链路。此检查点的全量类型、格式、ESLint/路径 lint 和 5 个定向文件 39 项通过；全仓 coverage、浏览器 regression 与 Node 产物恢复仍待本地冻结验收。
- Node 22 下 `verify:static:ci` 全量通过：236 个 Vitest 文件中 234 通过、2 个既有 skip，1211 项通过、4 项 skip；core world 覆盖率 lines 96.89%，Active Node 全量类型检查、Svelte、格式、ESLint 与路径 lint 均通过。日志 `/tmp/seedlands-monorepo/m2-verify-static.log`。
- 迁移后首次真实浏览器 regression 得到可执行 RED：静态加载与预渲染通过，进入世界后首批 mesh 全部因 Web Worker kernel adapter 未注入 core 要求的显式单调时钟而失败，loading 不结束。补入真实 `performance.now` 端口并加 adapter 回归断言后，原失败用例 1/1 通过，完整 14/14 Chromium regression 通过（20.1 秒）；日志 `/tmp/seedlands-monorepo/m2-browser-regression.log`、`m2-browser-clock-port-green.log`、`m2-browser-regression-green.log`。当次截图已复制到 `/tmp/seedlands-monorepo/m2-world-loading.png`，历史 Delivered 图片恢复且未提交。

## M2：冻结行为与产物验收

- Web adapter 回归升级为经真实 `worldKernelAdapter` 运行最小 `generate-mesh`，直接证明显式时钟端口可完成此前被拒绝的 mesh；1/1 通过，日志 `/tmp/seedlands-monorepo/m3-web-clock-adapter.log`。
- 新增本 change Playwright 用例显式以 `wasm=off&simd=off` 进入世界，断言 general Worker 的 `status=off/effectiveArtifact=off` 以及首块加载、渲染；定向 1/1 通过。最终 regression 同时覆盖默认 Wasm、TS fallback、预加载/预渲染和长期游戏旅程，15/15 通过（22.3 秒）。日志 `/tmp/seedlands-monorepo/m3-browser-ts-fallback.log`、`m3-browser-regression.log`；截图另存 `/tmp/seedlands-monorepo/m3-world-loading.png` 后恢复历史 Delivered 图片。
- Node 22 重新构建五个 ESM 入口；无源码/依赖目录的产物校验、worker-thread 与 child-process 两种启停恢复、真实 SIGKILL 后只恢复最后 durable 检查点共 4/4 通过。日志 `/tmp/seedlands-monorepo/m3-node-build.log`、`m3-node-artifact-recovery.log`。
- portable Active Node 完整 Authority baseline、调度失效、零生成回退、reference 接收与 Worker 输入结算 4 文件 35/35 通过，日志 `/tmp/seedlands-monorepo/m3-complete-baseline.log`。迁移前冻结清单的 20 个 Active Node 测试源码仍全部受专用 TypeScript 配置检查；依赖外部 `/tmp` 语料的其余用例保持 fail closed，未宣称执行。
- 最终 `verify:static:ci` 在 Node 22 通过：236 文件中 234 通过、2 个既有 skip，1211 项通过、4 项 skip；world lines 96.89%，其后全部 package/root 类型检查通过。日志 `/tmp/seedlands-monorepo/m3-verify-static.log`。
- 最终 `verify:node-isolation` 在 `/tmp/seedlands-monorepo/node-isolation` 全新安装并再次通过 core typecheck、Node 五入口 build 与独立 runtime `--help`。目录无 Web 源码、未复用根 `node_modules`、无 PlayCanvas/Svelte/Tone；Vitest→Vite 仅作为共享测试工具传递依赖单列。日志 `/tmp/seedlands-monorepo/m3-node-isolation.log`，报告 `/tmp/seedlands-monorepo/node-isolation-report.json`。

## M3：路径、文档与交接

- README 中英文版、代码地图、目录规范、AGENTS 与治理文档更新为三包实际路径、依赖方向、运行产物和验证入口。根级 PlayCanvas/Svelte/Tone 只为根整合测试解析而保留；Web 包声明其产品依赖，Node 隔离构建不消费它们。
- 性能冻结工具同时识别当前 monorepo 的 `apps/web/dist` 和旧冻结对照的 `dist`；源码 hash 覆盖 Web/core/workspace 构建输入。对应 build identity 读取相同布局并跳过 `.vite` 等目录。当前与旧对照均成功写入 stamp；当前 identity 校验 39 个文件并包含 stamp。日志 `/tmp/seedlands-monorepo/m3-adoption-freeze.log`、`m3-adoption-identity-check.log`。Harness bundle 统计也同时验证两种布局，日志 `/tmp/seedlands-monorepo/m3-harness-dist-path.log`。
- 迁移前清单 `/tmp/seedlands-monorepo/pre-migration-inventory.json` 绑定 `0380926`：239 个 `tests/` 文件、101 个 change-local 测试文件。最终路径盘点为 239 与 102，本 change 仅新增 1 个 TS fallback Playwright 文件，没有删除冻结清单中的测试。
- 逐项命令、退出码、日志 SHA-256 与源码/工作树绑定见 `evidence/validation-manifest.json`。draft PR 为 #15；不主动合并或部署，冻结 HEAD 与最新 CI/独立验收状态由 root 最终回填。
