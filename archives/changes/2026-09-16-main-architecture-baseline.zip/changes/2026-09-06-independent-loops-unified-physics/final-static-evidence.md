# 最终静态检查与构建证据

## 固定源码与父链

本轮在 detached 临时工作树 `/tmp/seedlands-final-static-74a8ed2` 中固定并核对源码：

```text
74a8ed288b3f92d10dae961ef45288c9bcfdbfcc
└─ b0c0d89e2d79bc8d42f7d8caa2aecd423da0c213
   └─ a5157ca77a3a0dda47f493dc8c65d47c3dff06dc
      └─ 88d0d741d256dff36e10a4f09990f69d48a83119
```

因此 `74a8ed2` 已包含 `a5157ca` 的受控负载目标隔离，以及 `b0c0d89` 的受控负载角色稳定修订；二者不是本轮静态检查之后才出现的提交。后续 `1c30d2b`、`c139cb5` 仅为证据文档，不属于本次固定源码。

## 完整静态检查

执行 `pnpm verify:static`，退出码为 0：

- Prettier、ESLint 与路径命名检查全部通过。
- Vitest 共发现 137 个文件，其中 135 个通过、2 个跳过；共 692 项，其中 688 项通过、4 项跳过。
- `src/world/**` 行覆盖率为 96.37%（718/745），statement 为 94.65%（832/879），branch 为 87.25%（438/502），function 为 96.8%（91/94）。
- Svelte 检查为 0 error、0 warning；源码与测试 TypeScript 检查全部通过。

实际覆盖率产物：

- `/tmp/seedlands-final-static-74a8ed2/coverage/coverage-summary.json`
- `/tmp/seedlands-final-static-74a8ed2/coverage/lcov.info`

## 生产构建

执行 `pnpm build`，退出码为 0。类型检查再次通过，Vite 完成 2432 个模块转换并产出 Authority、Logic、Persistence、Fluid 与 General Worker bundle。构建仅报告既有的单个主 bundle 超过 500 kB 警告，没有构建错误。

实际构建产物入口：`/tmp/seedlands-final-static-74a8ed2/dist/index.html`。

## 日志边界

本轮命令通过 Codex 工具直接捕获标准输出，运行时没有使用 `tee`，因此不存在可声称为逐行原始 stdout 的文件。根据已捕获输出整理的本地摘要位于 `/tmp/seedlands-final-static-74a8ed2/final-static-captured-output.txt`；覆盖率 JSON、LCOV 和生产 `dist` 是命令直接生成的实际产物。本文件保留可提交的完整结果与精确源码身份，不把整理摘要描述成原始日志。

## 最终候选复验：`c432753`

在 A9 的受控 20×2 与自然 A/A/B 均于同一源码通过并释放 CPU/Chrome 后，建立 detached 临时工作树 `/tmp/seedlands-final-static-c4327530aac6`。实际固定源码为：

```text
c4327530aac6bd5027c7c10ea5265cea9d0c13a4
└─ bbbc88f30c5c1ae691306c758664e373d0d0ff57
   └─ 87776f6bd4806134901e33e3fbc52e0aa45b9afc
```

`pnpm verify:static` 通过，原始合并 stdout/stderr 与管道真实退出码保存在 `evidence/final-verify-static-c4327530aac6.log`，SHA-256 为 `34e2dc27d147501877469e97d6d758bad7de0aa36b8c9a5e70f72d7dcba9d826`。实际结果：

- Prettier、ESLint、路径命名检查全部通过。
- 146 个测试文件中 144 个通过、2 个跳过；732 项中 728 项通过、4 项跳过。
- `src/world/**` 行覆盖率 96.37%（718/745），statement 94.65%（832/879），branch 87.25%（438/502），function 96.8%（91/94）。
- Svelte 检查 0 error、0 warning；源码与测试 TypeScript 检查通过；`COMMAND_EXIT=0`。

`pnpm build` 通过，原始合并 stdout/stderr 与管道真实退出码保存在 `evidence/final-build-c4327530aac6.log`，SHA-256 为 `e4213ecbf1ecb088375881f91a5e832461a9a9b45db9cfcc6cc08d005a435a22`。类型检查再次通过，Vite 转换 2438 个模块并产出五类生产 Worker bundle，`COMMAND_EXIT=0`；仅保留既有的主 bundle 大于 500 kB 警告。

命令直接生成的产物位于：

- `/tmp/seedlands-final-static-c4327530aac6/coverage/coverage-summary.json`
- `/tmp/seedlands-final-static-c4327530aac6/coverage/lcov.info`
- `/tmp/seedlands-final-static-c4327530aac6/dist/index.html`

本次最终复验在运行时使用 `bash -o pipefail`，并通过 `tee` 将完整输出直接写入上述日志；日志末行由同一 shell 追加实际 `COMMAND_EXIT`。这两份日志是原始命令输出，不是事后整理摘要。前述 `74a8ed2` 历史证据继续保留，用于说明更早一次检查及其日志边界，不作为最终候选的替代。

## 最终统一生产候选：`2257aff`

A7 最终真实浏览器与长期 Harness 在 `2257affb830046e638a99b9502e77d0866eb1bf1` 完成后，主任务明确释放重型窗口。本轮另建 detached 工作树 `/tmp/seedlands-final-static-2257affb8300`，没有复用或修改供后续 A9 使用的既有不可变 `dist`。固定源码父链为：

```text
2257affb830046e638a99b9502e77d0866eb1bf1
└─ e4b2ad7b308855005f97217ee4cb369d52be2981
   └─ 00210cb7eb949754da161b6f71f4af6a2059b89f
      └─ 01d183e97bf34375a29dbe8ca07f92da19b4cc5a
         └─ 3b35829906cbae02659538ebd920beb25630e16f
```

这条父链已经包含最终传输恢复 E2E 加固以及预测与 Authority 重同步分离的生产修复。后继仅证据文档的提交不改变本轮生产源码身份。

`pnpm verify:static` 通过，原始合并 stdout/stderr 与管道真实退出码保存在 `evidence/final-verify-static-2257affb8300.log`，SHA-256 为 `67750dc84a472466a38e27c52c98fc98553c0002756d6487f3e412107503ceb0`。实际结果：

- Prettier、ESLint 与路径命名检查全部通过。
- 147 个测试文件中 145 个通过、2 个跳过；738 项中 734 项通过、4 项跳过。
- `src/world/**` 行覆盖率 96.37%（718/745），statement 94.65%（832/879），branch 87.25%（438/502），function 96.8%（91/94）。
- Svelte 检查 0 error、0 warning；源码与测试 TypeScript 检查通过；`COMMAND_EXIT=0`。

`pnpm build` 通过，原始合并 stdout/stderr 与管道真实退出码保存在 `evidence/final-build-2257affb8300.log`，SHA-256 为 `d42b22c9253f85caae5ca675a72edcdc7b5c4953862f7c441bd4320007f2263b`。类型检查再次通过，Vite 转换 2438 个模块并产出 Authority、Logic、Persistence、Fluid 与 General Worker bundle，`COMMAND_EXIT=0`；仅保留既有的主 bundle 大于 500 kB 警告。

命令直接生成的产物位于：

- `/tmp/seedlands-final-static-2257affb8300/coverage/coverage-summary.json`
- `/tmp/seedlands-final-static-2257affb8300/coverage/lcov.info`
- `/tmp/seedlands-final-static-2257affb8300/dist/index.html`

本轮同样使用 `bash -o pipefail` 与 `tee`，日志末行的 `COMMAND_EXIT` 来自对应命令管道的真实首段退出码。本节取代 `c432753` 作为最终统一生产候选的 Static 与 Build 证据；较早两轮继续作为实现过程历史保留。
